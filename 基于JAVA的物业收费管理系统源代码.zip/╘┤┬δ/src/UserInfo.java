import javax.swing.table.AbstractTableModel;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.sql.*;
import java.util.*;



public class UserInfo extends JFrame
{
	
	
	private JPanel buttonPanel,tablePanel,fieldPanel,fieldPanel1,fieldPanel2,fieldPanel3;

	private JLabel label1 = new JLabel();
	private JTextField districtid = new JTextField(6);
	private JLabel label2 = new JLabel();
	private JTextField buildingid = new JTextField(3);
	private JLabel label3 = new JLabel();
	private JTextField roomid = new JTextField(4);
	private JLabel label4 = new JLabel();
	private JTextField area = new JTextField(5);
	private JLabel label5 = new JLabel();
	private JTextField stac = new JTextField();
	private JLabel label6 = new JLabel();
	private JTextField func = new JTextField();
	private JLabel label7 = new JLabel();
	private JTextField ownername = new JTextField(6);
	private JLabel label8 = new JLabel();
	private JTextField sex = new JTextField(4);
	private JLabel label9 = new JLabel();
	private JTextField idnum = new JTextField(13);
	private JLabel label10 = new JLabel();
	private JTextField addr = new JTextField(15);
	private JLabel label11 = new JLabel();
	private JTextField tetel = new JTextField(8);
	
	
	private JButton searchButton = new JButton("������ѯ");
	private JButton addButton = new JButton("����");
	private JButton changeButton = new JButton("�޸�");
	private JButton deleteButton = new JButton("ɾ��");
	private JButton renewButton = new JButton("����");
	private JButton updateButton= new JButton("����");
	
	String title[]= {"С����","¥��","����","��Ȩ���","����״̬","��;",
					 "ҵ������","�Ա�","����֤","��ϵ��ַ","��ϵ�绰"};

	Vector vector=new Vector();
	

	Connection connection = null;
	ResultSet rSet = null;
	Statement statement = null;
	AbstractTableModel tm;
	
	public UserInfo()
	{
		
		
		enableEvents(AWTEvent.WINDOW_EVENT_MASK);
		try
		{
			jbInit();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		setSize(480,600);
		setResizable(false);
		setVisible(true);
	}
	
	private void jbInit() throws Exception
	{
		Container con = getContentPane();
		con.setLayout(new BorderLayout());
		
		label1.setText("С��");
		label2.setText("¥��");
		label3.setText("����");
		label4.setText("��Ȩ���");
		label5.setText("����״̬");
		label6.setText("��;");
		label7.setText("����");
		label8.setText("�Ա�");
		label9.setText("����֤");
		label10.setText("��ϵ��ַ");
		label11.setText("��ϵ�绰");
				
		searchButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				searchButton_actionPerformed(e);
			}
		});
		
		addButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				addButton_actionPerformed(e);
			}
		});
		
		changeButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				changeButton_actionPerformed(e);
			}
		});
		
		deleteButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				deleteButton_actionPerformed(e);
			}
		});
		
		renewButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				renewButton_actionPerformed(e);
			}
		});
		
		updateButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				updateButton_actionPerformed(e);
			}
		});
		
		fieldPanel1=new JPanel();
		fieldPanel1.setLayout(new FlowLayout());
		
		fieldPanel1.add(label1);
		fieldPanel1.add(districtid);
		fieldPanel1.add(label2);
		fieldPanel1.add(buildingid);
		fieldPanel1.add(label3);
		fieldPanel1.add(roomid);
		fieldPanel1.add(label4);
		fieldPanel1.add(area);

		
		fieldPanel2=new JPanel();
		fieldPanel2.setLayout(new FlowLayout());
		
		fieldPanel2.add(label7);
		fieldPanel2.add(ownername);
		fieldPanel2.add(label8);
		fieldPanel2.add(sex);
		fieldPanel2.add(label9);
		fieldPanel2.add(idnum);
		
		fieldPanel3=new JPanel();
		fieldPanel3.setLayout(new FlowLayout());
		
		fieldPanel3.add(label10);
		fieldPanel3.add(addr);
		fieldPanel3.add(label11);
		fieldPanel3.add(tetel);
		
		fieldPanel = new JPanel();
		fieldPanel.setLayout(new BorderLayout());
	
		fieldPanel.add(fieldPanel1,BorderLayout.NORTH);
		fieldPanel.add(fieldPanel2,BorderLayout.CENTER);
		fieldPanel.add(fieldPanel3,BorderLayout.SOUTH);
		
		buttonPanel=new JPanel();
		buttonPanel.setLayout(new FlowLayout());
		
		buttonPanel.add(searchButton);
		buttonPanel.add(addButton);
		buttonPanel.add(changeButton);
		buttonPanel.add(deleteButton);
		buttonPanel.add(renewButton);
		buttonPanel.add(updateButton);
		
		tablePanel=new JPanel();
		
		createtable();
		con.add(tablePanel,BorderLayout.NORTH);
		con.add(fieldPanel,BorderLayout.CENTER);
		con.add(buttonPanel,BorderLayout.SOUTH);
		updated();
		
	}
	
/*	public static void main(String[] args) 
	{
		UserInfo userInformation=new UserInfo();
		userInformation.setSize(480,600);
		userInformation.setResizable(false);
		userInformation.setVisible(true);
		userInformation.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE );
	}*/
	
	private void createtable()
	{
		JTable table;
		JScrollPane scroll;
	//	vector = new Vector();
		tm = new AbstractTableModel()
		{
			public int getColumnCount()
			{
				return title.length;
			}
			public int getRowCount()
			{
				return vector.size();
			}
			public String getColumnName(int col) 
			{
				return title[col];
			}
			
			public Object getValueAt(int row, int column)
			{
				if(!vector.isEmpty())
				{
					return ((Vector)vector.elementAt(row)).elementAt(column);
				}
				else
				{
					return null;
				}
	
			}
			public void setValueAt(Object value, int row, int column)
			{
				
			}
		
			public Class getColumnClass(int c)
			{
				return getValueAt(0,c).getClass();
			}
			public boolean isCellEditable(int row, int column)
			{
				return false;
			}
		};
		
		table = new JTable(tm);
		table.setToolTipText("Display Query Result");
		table.setAutoResizeMode(table.AUTO_RESIZE_OFF);
		table.setCellSelectionEnabled(false);
		table.setShowHorizontalLines(true);
		table.setShowVerticalLines(true);
		scroll = new JScrollPane(table);
		scroll.setBounds(6,20,540,250);
		tablePanel.add(scroll);
		
		
	}

	
	void addButton_actionPerformed(ActionEvent e)
	{
		try{
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://47.101.198.61:3306/swing_wuye";
			connection = DriverManager.getConnection(url,"swing_wuye","swing_wuye");
			statement = connection.createStatement();
			String sql1= "insert into room_info(district_id,building_id,room_id,area,oname,sex,id_num,address,phone) values("+Integer.parseInt(districtid.getText())+","+Integer.parseInt(buildingid.getText())+","+Integer.parseInt(roomid.getText())+","+Integer.parseInt(area.getText())+",'"+ownername.getText()+"','"+sex.getText()+"','"+idnum.getText()+"','"+addr.getText()+"',"+Integer.parseInt(tetel.getText())+")";
			statement.executeUpdate(sql1);
			
		}
		catch(Exception ex){
			JOptionPane.showMessageDialog(UserInfo.this,"������ݳ���","����",JOptionPane.ERROR_MESSAGE);
			ex.printStackTrace();
		}
		finally{
			try{
				if(statement != null){
					statement.close();
				}
				if(connection != null){
					connection.close();
				}
			}
			catch(SQLException ex){
				System.out.println("\nERROR:---------SQLException--------\n");
				System.out.println("Message: "+ ex.getMessage());
				System.out.println("SQLState: "+ ex.getSQLState());
				System.out.println("ErrorCode: "+ ex.getErrorCode());
			}
		}
		updated();			
	}
	
	void changeButton_actionPerformed(ActionEvent e)
	{
		try{
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://47.101.198.61:3306/swing_wuye";
			connection = DriverManager.getConnection(url,"swing_wuye","swing_wuye");
			statement = connection.createStatement();
			String sql1= "update room_info set area="+Integer.parseInt(area.getText())+",oname='"+ownername.getText()+"',sex='"+sex.getText()+"',id_num='"+idnum.getText()+"',address='"+addr.getText()+"',phone="+Integer.parseInt(tetel.getText())+" WHERE district_id="+Integer.parseInt(districtid.getText())+" AND building_id="+Integer.parseInt(buildingid.getText())+" AND room_id="+Integer.parseInt(roomid.getText());
			statement.executeUpdate(sql1);
			
		}
		catch(Exception ex){
			JOptionPane.showMessageDialog(UserInfo.this,"�޸����ݳ�����ע������д�������Ƿ���ȷ��","����",JOptionPane.ERROR_MESSAGE);
			ex.printStackTrace();
		}
		finally{
			try{
				if(statement != null){
					statement.close();
				}
				if(connection != null){
					connection.close();
				}
			}
			catch(SQLException ex){
				System.out.println("\nERROR:---------SQLException--------\n");
				System.out.println("Message: "+ ex.getMessage());
				System.out.println("SQLState: "+ ex.getSQLState());
				System.out.println("ErrorCode: "+ ex.getErrorCode());
			}
		}
		updated();			
	}
	
	void deleteButton_actionPerformed(ActionEvent e)
	{
		try{
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://47.101.198.61:3306/swing_wuye";
			connection = DriverManager.getConnection(url,"swing_wuye","swing_wuye");
			statement = connection.createStatement();
			String sql2= "delete from room_info where district_id="+Integer.parseInt(districtid.getText())+"AND building_id="+Integer.parseInt(buildingid.getText())+"AND room_id="+Integer.parseInt(roomid.getText());//+"area="+Integer.parseInt(area.getText())+"||oname="+ownername.getText()+"||sex="+sex.getText()+"||id_num="+idnum.getText()+"||address="+addr.getText()+"||phone="+Integer.parseInt(tetel.getText());
			statement.executeUpdate(sql2);
			
			}
		catch(Exception ex){
			JOptionPane.showMessageDialog(UserInfo.this,"ɾ�����ݳ�����ע��С���ţ�¥�ţ�������Ƿ���ȷ��","����",JOptionPane.ERROR_MESSAGE);
			ex.printStackTrace();
		}
		finally{
			try{
				if(statement != null){
					statement.close();
				}
				if(connection != null){
					connection.close();
				}
			}
			catch(SQLException ex){
				System.out.println("\nERROR:---------SQLException--------\n");
				System.out.println("Message: "+ ex.getMessage());
				System.out.println("SQLState: "+ ex.getSQLState());
				System.out.println("ErrorCode: "+ ex.getErrorCode());
			}
		}
		updated();
	}
	
	void updateButton_actionPerformed(ActionEvent e)
	{
			try{
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://47.101.198.61:3306/swing_wuye";
			connection = DriverManager.getConnection(url,"swing_wuye","swing_wuye");
			statement = connection.createStatement();
			String sql3= "select * from room_info";
			rSet=statement.executeQuery(sql3);
			if(rSet.next()==false)
			{
				//JOptionPane msg= new JOptionPane();
				JOptionPane.showMessageDialog(UserInfo.this,"���ݿ�����Ӧ����","����",JOptionPane.ERROR_MESSAGE);
			}
			else
			{
				String sql= "select * from room_info";
				ResultSet rs=statement.executeQuery(sql);
				
				districtid.setText("");
				buildingid.setText("");
				roomid.setText("");
				area.setText("");
				ownername.setText("");
				sex.setText("");
				idnum.setText("");
				addr.setText("");
				tetel.setText("");
						
				vector.removeAllElements();
				tm.fireTableStructureChanged();
			
				while(rs.next())
				{
					Vector rec_vector=new Vector();
					rec_vector.addElement(String.valueOf(rs.getInt(1)));
					rec_vector.addElement(String.valueOf(rs.getInt(2)));
					rec_vector.addElement(String.valueOf(rs.getInt(3)));
					rec_vector.addElement(String.valueOf(rs.getInt(4)));
					rec_vector.addElement(rs.getString(5));
					rec_vector.addElement(rs.getString(6));
					rec_vector.addElement(rs.getString(7));
					rec_vector.addElement(rs.getString(8));
					rec_vector.addElement(rs.getString(9));
					rec_vector.addElement(rs.getString(10));
					rec_vector.addElement(String.valueOf(rs.getInt(11)));
					vector.addElement(rec_vector);
				}
				tm.fireTableStructureChanged();
			}
			
			
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		finally{
			try{
				if(statement != null){
					statement.close();
				}
				if(connection != null){
					connection.close();
				}
			}
			catch(SQLException ex){
				System.out.println("\nERROR:---------SQLException--------\n");
				System.out.println("Message: "+ ex.getMessage());
				System.out.println("SQLState: "+ ex.getSQLState());
				System.out.println("ErrorCode: "+ ex.getErrorCode());
			}
		}
	}
	
	void searchButton_actionPerformed(ActionEvent e)
	{
		try{
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://47.101.198.61:3306/swing_wuye";
			connection = DriverManager.getConnection(url,"swing_wuye","swing_wuye");
			statement = connection.createStatement();
		//	String sql4= "select * from room_info where district_id="+Integer.parseInt(districtid.getText())+"||building_id="+Integer.parseInt(buildingid.getText())+"||room_id="+Integer.parseInt(roomid.getText())+"area="+Integer.parseInt(area.getText())+"||oname='"+ownername.getText()+"'||sex='"+sex.getText()+"'||id_num="+idnum.getText()+"||address="+addr.getText()+"||phone="+Integer.parseInt(tetel.getText());
			String sql4= "select * from room_info where oname='"+ownername.getText()+"'";
			rSet=statement.executeQuery(sql4);
			if(rSet.next()==false)
			{
				JOptionPane msg= new JOptionPane();
				JOptionPane.showMessageDialog(UserInfo.this,"���ݿ�����Ӧ����","����",JOptionPane.ERROR_MESSAGE);
				vector.removeAllElements();
				tm.fireTableStructureChanged();
			}
			else
			{
		//		String sqll= "select * from room_info where district_id="+Integer.parseInt(districtid.getText())+"||building_id="+Integer.parseInt(buildingid.getText())+"||room_id="+Integer.parseInt(roomid.getText())+"area="+Integer.parseInt(area.getText())+"||oname='"+ownername.getText()+"'||sex='"+sex.getText()+"'||id_num="+idnum.getText()+"||address="+addr.getText()+"||phone="+Integer.parseInt(tetel.getText());
				String sqll="select * from room_info where oname='"+ownername.getText()+"'";
				ResultSet rs=statement.executeQuery(sqll);
					
					
				vector.removeAllElements();
				tm.fireTableStructureChanged();
			
				while(rs.next())
				{
					Vector rec_vector=new Vector();
					rec_vector.addElement(String.valueOf(rs.getInt(1)));
					rec_vector.addElement(String.valueOf(rs.getInt(2)));
					rec_vector.addElement(String.valueOf(rs.getInt(3)));
					rec_vector.addElement(String.valueOf(rs.getInt(4)));
					rec_vector.addElement(rs.getString(5));
					rec_vector.addElement(rs.getString(6));
					rec_vector.addElement(rs.getString(7));
					rec_vector.addElement(rs.getString(8));
					rec_vector.addElement(rs.getString(9));
					rec_vector.addElement(rs.getString(10));
					rec_vector.addElement(String.valueOf(rs.getInt(11)));
					vector.addElement(rec_vector);
				}
				tm.fireTableStructureChanged();
			}	
		}	
		
		catch(Exception ex){
			ex.printStackTrace();
		}
		finally{
			try{
				if(statement != null){
					statement.close();
				}
				if(connection != null){
					connection.close();
				}
			}
			catch(SQLException ex){
				System.out.println("\nERROR:---------SQLException--------\n");
				System.out.println("Message: "+ ex.getMessage());
				System.out.println("SQLState: "+ ex.getSQLState());
				System.out.println("ErrorCode: "+ ex.getErrorCode());
			}
		}
	
		
	
	}
	
	void updated()
	{
			try{
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://47.101.198.61:3306/swing_wuye";
			connection = DriverManager.getConnection(url,"swing_wuye","swing_wuye");
			statement = connection.createStatement();
			String sql3= "select * from room_info";
			rSet=statement.executeQuery(sql3);
			if(rSet.next()== true)
			{
				String sql= "select * from room_info";
				ResultSet rs=statement.executeQuery(sql);
								
				
				vector.removeAllElements();
				tm.fireTableStructureChanged();
			
				while(rs.next())
				{
					Vector rec_vector=new Vector();
					rec_vector.addElement(String.valueOf(rs.getInt(1)));
					rec_vector.addElement(String.valueOf(rs.getInt(2)));
					rec_vector.addElement(String.valueOf(rs.getInt(3)));
					rec_vector.addElement(String.valueOf(rs.getInt(4)));
					rec_vector.addElement(rs.getString(5));
					rec_vector.addElement(rs.getString(6));
					rec_vector.addElement(rs.getString(7));
					rec_vector.addElement(rs.getString(8));
					rec_vector.addElement(rs.getString(9));
					rec_vector.addElement(rs.getString(10));
					rec_vector.addElement(String.valueOf(rs.getInt(11)));
					vector.addElement(rec_vector);
				}
				tm.fireTableStructureChanged();
			}
			
			
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		finally{
			try{
				if(statement != null){
					statement.close();
				}
				if(connection != null){
					connection.close();
				}
			}
			catch(SQLException ex){
				System.out.println("\nERROR:---------SQLException--------\n");
				System.out.println("Message: "+ ex.getMessage());
				System.out.println("SQLState: "+ ex.getSQLState());
				System.out.println("ErrorCode: "+ ex.getErrorCode());
			}
		}
	}
	
	
	void renewButton_actionPerformed(ActionEvent e)
	{		
				districtid.setText("");
				buildingid.setText("");
				roomid.setText("");
				area.setText("");
				ownername.setText("");
				sex.setText("");
				idnum.setText("");
				addr.setText("");
				tetel.setText("");
	}
}





