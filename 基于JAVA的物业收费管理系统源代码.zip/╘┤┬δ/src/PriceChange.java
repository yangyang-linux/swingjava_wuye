import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.*;
import java.applet.*;
import javax.swing.event.*;

public class PriceChange extends JFrame {
	
	private Connection c1;
	private String Mouaction;
	private JTable display;
	private JButton comm_1,comm_2,comm_3;
	private Statement stmt1;
	private ResultSet rsl1;
	private ResultSetMetaData rsmd1; 
	private TextField text_1,text_2,text_3;
	
	public PriceChange(){
		try{
				Class.forName("com.mysql.jdbc.Driver");
				c1 = DriverManager.getConnection("jdbc:mysql://47.101.198.61:3306/swing_wuye","swing_wuye","swing_wuye");
				String sql="SELECT * FROM unit_price_info";
				stmt1  = c1.createStatement();
				rsl1 = stmt1.executeQuery(sql);
				rsmd1 = rsl1.getMetaData();//��ȡ�����ֶ�����
			}
		catch(Exception err)
		{
			err.printStackTrace();
		}//�������ݿ����ӣ�
		
		
		
		JPanel button_con = new JPanel();
		button_con.setLayout(new FlowLayout());
		comm_1 = new JButton("����");
		comm_1.addActionListener(
			new ActionListener(){
				public void actionPerformed(ActionEvent e){
					addPrice();
				}
			}
		);
				
		comm_2 = new JButton("�޸�");
		comm_2.addActionListener(
			new ActionListener(){
				public void actionPerformed(ActionEvent e){
					changePrice();
				}
			}
		);
		
		comm_3 = new JButton("ɾ��");
		comm_3.addActionListener(
			new ActionListener(){
				public void actionPerformed(ActionEvent e){
					deletePrice();
				}
			}
		);
		
		button_con.add(comm_1);
		button_con.add(comm_2);
		button_con.add(comm_3);
		JPanel label_con = new JPanel();
		label_con.setLayout(new GridLayout(1,3));
		JLabel lab_1 = new JLabel("�շ���Ŀ���");
		JLabel lab_2 = new JLabel("�շ���Ŀ����");
		JLabel lab_3 = new JLabel("����");
		label_con.add(lab_1);
		label_con.add(lab_2);
		label_con.add(lab_3);
		JPanel inputText_con = new JPanel();
		inputText_con.setLayout(new GridLayout(1,3));
		text_1 = new TextField();
		text_2 = new TextField();
		text_3 = new TextField();
		inputText_con.add(text_1);
		inputText_con.add(text_2);
		inputText_con.add(text_3);
		JPanel update_con = new JPanel();
		update_con.setLayout(new BorderLayout());
		update_con.add(label_con,BorderLayout.NORTH);
		update_con.add(inputText_con,BorderLayout.CENTER);
		update_con.add(button_con,BorderLayout.SOUTH);
		display = new JTable();
		Container temp = getContentPane();
        temp.setLayout(new BorderLayout());
      	temp.add(update_con,BorderLayout.SOUTH);
      	temp.add(display,BorderLayout.CENTER);
      	getpriceTable();
      	setSize(500,300);
      	show();
	}
		
	
	/*public void actionPerformed(ActionEvent e){
		Mouaction = e.getActionCommand();
		try{
				Class.forName("com.mysql.jdbc.Driver");
				c1 = DriverManager.getConnection("jdbc:mysql://47.101.198.61:3306/swing_wuye");
			}
		catch(Exception err)
		{
			err.printStackTrace();
		}//�������ݿ����ӣ�
		
		getpriceTable();
		
	}*/
	
	public void getpriceTable(){
		try
			{
				Vector columnName = new Vector();
				Vector rows = new Vector();//�����������������ݿ����ݲ���
				
				columnName.addElement("�շ���Ŀ���");
				columnName.addElement("�շ���Ŀ����");
				columnName.addElement("����(��λ��Ԫ��");
				
				while(rsl1.next())
				{                                              // ��ȡ��¼��
            		Vector currentRow = new Vector();
            		for ( int i = 1; i <= rsmd1.getColumnCount(); ++i )
            		{
         				currentRow.addElement( rsl1.getString( i ) );
      				}
            		rows.addElement( currentRow);
            	}
            	
            	display = new JTable(rows,columnName);
            	JScrollPane scroller = new JScrollPane(display);
            	Container temp = getContentPane();
            	
            	temp.add(scroller,BorderLayout.CENTER);
            	temp.validate();				
			}
			catch(Exception sqlex)
			{
				sqlex.printStackTrace();
			}
		}
		
		private void addPrice(){
			try{
					String add_sql = "insert into unit_price_info values ("+Integer.parseInt(text_1.getText())+",'"+text_2.getText()+"',"+Float.parseFloat(text_3.getText())+")";
					stmt1.executeUpdate(add_sql);
					text_1.setText("");
					text_2.setText("");
					text_3.setText("");
					
				}
			catch(Exception ex){
				JOptionPane.showMessageDialog(PriceChange.this,"�������ݳ�����ע�����������Ƿ���ȷ��","����",JOptionPane.ERROR_MESSAGE);
				ex.printStackTrace();
			}
		}
		
		private void changePrice(){
			try{
					String change_sql ="update unit_price_info set charge_id="+Integer.parseInt(text_1.getText())+",charge_name='"+text_2.getText()+"',unit_price="+Float.parseFloat(text_3.getText())+" where charge_id="+Integer.parseInt(text_1.getText());
					stmt1.executeUpdate(change_sql);
					text_1.setText("");
					text_2.setText("");
					text_3.setText("");
				}
			catch(Exception ex_1){
				JOptionPane.showMessageDialog(PriceChange.this,"�޸����ݳ�����ע�����������Ƿ���ȷ��","����",JOptionPane.ERROR_MESSAGE);
				ex_1.printStackTrace();
			}
		}
			
		private void deletePrice(){
			try{
					String delete_sql ="delete from unit_price_info where charge_id="+Integer.parseInt(text_1.getText()); ;
					stmt1.executeUpdate(delete_sql);
					text_1.setText("");
					text_2.setText("");
					text_3.setText("");
				}
			catch(Exception ex_2){
				JOptionPane.showMessageDialog(PriceChange.this,"�������ݳ�����ע�������շ���ĿID�Ƿ���ȷ��","����",JOptionPane.ERROR_MESSAGE);
				ex_2.printStackTrace();
			}
		}		
				
		public static void main(String args[]){
			PriceChange s1 = new PriceChange();
			s1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		}
		
		
			
	}