import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.*;
import javax.swing.event.*;

public class PublicDataInputFrame extends JFrame
{
	private String uptown_name[], uptown_id[], building_id[];
	private JLabel uptownselectLabel;
	private JComboBox uptownselect;
	private JLabel uptownwaterLabel, uptowneleLabel, uptownsecwaterLabel, dateLabel, uptownLabel;
	private JTextField uptownwaterField, uptowneleField, uptownsecwaterField, dateField;
	private JLabel buildinglifteleLabel[], buildinglighteleLabel[], buildingidLabel[];
	private JTextField buildinglifteleField[], buildinglighteleField[];
	private String uptownname, uptownid;
	private JButton button1, button2, button3, button4;
	
	private GridBagConstraints c;
	private Insets inset;
	private GridBagLayout gridbag;
	
	private String in_name, in_id,message2;
	private int count, nullvalue;
	private String uptownwater,uptownele,uptownsecwater,buildingele1[],buildingele2[],date;
	private int t_type;
	//private Container panelin;
	
	public PublicDataInputFrame(int tt)
	{
		super("ѡ��С��");
		Container panelin = getContentPane();
		panelin.removeAll();
		gridbag=new GridBagLayout();
		panelin.setLayout(gridbag);
		
		t_type=tt;
		uptown_id = new String[100];
		uptown_name = new String[100];
		uptown_name[0]=new String("��ѡ��С��");
		
		getuptown();
		
		uptownselectLabel = new JLabel( "ѡ��С��" );
		uptownselectLabel.setToolTipText("�������˵���ѡ��С��" );
		inset = new Insets(5,5,5,5);
		c = new GridBagConstraints(2,1,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownselectLabel,c);
		panelin.add(uptownselectLabel);
		
		uptownselect = new JComboBox( uptown_name );
		uptownselect.setMaximumRowCount( 5 );
		System.out.println("the out");
		uptownselect.addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = uptownselect.getSelectedIndex();
					//t++;
					System.out.println("the 01");
					uptownid = new String(uptown_id[i]);
					uptownname = new String( uptown_name[i]);
					//setVisible(true);
				}
			}
		);
		c = new GridBagConstraints(4,1,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownselect,c);
		panelin.add(uptownselect);
		
		button1 = new JButton( "ȷ��" );
		button1.setEnabled( true );
		button1.addActionListener(
			new ActionListener()
			{
				public void actionPerformed( ActionEvent event){
					if(uptownid!=null)
					{
						if(t_type==2)
						{
							PublicDataInputFrame rdif = new PublicDataInputFrame( uptownid,uptownname);
						}
					}
					else
					{
						JOptionPane.showMessageDialog(null,"��ѡ��С��","Error",JOptionPane.PLAIN_MESSAGE);
					}
				}
			}
			);
		c = new GridBagConstraints(3,3,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button1,c);
		panelin.add(button1);
		
		button2 = new JButton( "����" );
		button2.addActionListener(
			new ActionListener(){
				public void actionPerformed( ActionEvent event){
					PublicDataInputFrame.this.setVisible(false);
				}
			}
			);
		c = new GridBagConstraints(5,3,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button2,c);
		panelin.add(button2);
		
		
		setSize(350,300);
		setVisible(true);
	}
	
	public PublicDataInputFrame( String id, String name)
	{
		super("С��������������");
		in_name = new String(name);
		in_id = new String(id );
		building_id = new String[100];
		
		getbuilding( in_id );
		
		buildinglighteleLabel = new JLabel[count];
		buildinglifteleLabel = new JLabel[count];
		buildingidLabel = new JLabel[count];
		buildinglighteleField = new JTextField[count];
		buildinglifteleField = new JTextField[count];
		
		Container panelin =getContentPane();
		panelin.removeAll();
		gridbag=new GridBagLayout();
		panelin.setLayout(gridbag);
		
		dateLabel = new JLabel("�������ڣ���ʽYYYYMM��");
		inset = new Insets(5,5,5,5);
		c = new GridBagConstraints(2,1,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateLabel,c);
		panelin.add(dateLabel);
		
		dateField = new JTextField(10);
		c = new GridBagConstraints(4,1,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateField,c);
		panelin.add(dateField);
		
		uptownLabel = new JLabel( in_name);
		c = new GridBagConstraints(2,2,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints( uptownLabel, c);
		panelin.add( uptownLabel );
		
		uptownwaterLabel = new JLabel( "��ˮ��");
		c = new GridBagConstraints(4,2,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints( uptownwaterLabel, c );
		panelin.add( uptownwaterLabel );
		
		uptownwaterField = new JTextField(10);
		c = new GridBagConstraints(6,2,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints( uptownwaterField, c );
		panelin.add( uptownwaterField );
		
		uptowneleLabel = new JLabel( "�ܵ��" );
		c = new GridBagConstraints(8,2,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints( uptowneleLabel, c );
		panelin.add( uptowneleLabel );
		
		uptowneleField = new JTextField(10);
		c = new GridBagConstraints(10,2,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints( uptowneleField, c );
		panelin.add( uptowneleField );
		
		uptownsecwaterLabel = new JLabel( "���ι�ˮ���" );
		c = new GridBagConstraints(12,2,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints( uptownsecwaterLabel, c );
		panelin.add( uptownsecwaterLabel );
		
		uptownsecwaterField = new JTextField(10);
		c = new GridBagConstraints(14,2,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints( uptownsecwaterField, c );
		panelin.add( uptownsecwaterField );
		
		int y=4;
		for(int i=0 ; i<count; i++)
		{
			y=y+i;
			buildingidLabel[i] = new JLabel(building_id[i]);
			c = new GridBagConstraints(2,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(buildingidLabel[i],c);
			panelin.add(buildingidLabel[i]);
			
			buildinglifteleLabel[i] = new JLabel("���ݵ��");
			c = new GridBagConstraints(4,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(buildinglifteleLabel[i],c );
			panelin.add(buildinglifteleLabel[i]);
			
			buildinglifteleField[i] = new JTextField(10);
			c = new GridBagConstraints(6,y,2,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints( buildinglifteleField[i],c);
			panelin.add(buildinglifteleField[i]);
			
			buildinglighteleLabel[i] = new JLabel("¥���������");
			c = new GridBagConstraints(8,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(buildinglighteleLabel[i],c );
			panelin.add(buildinglighteleLabel[i]);
			
			buildinglighteleField[i] = new JTextField(10);
			c = new GridBagConstraints(10,y,2,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(buildinglighteleField[i],c);
			panelin.add(buildinglighteleField[i]);
		}
		
		y+=9;
		button3 = new JButton( "ȷ��" );
		button3.setEnabled( true );
		button3.addActionListener(//ִ�б��������ݿ���룬������ǰ������ɾ��
			new ActionListener() {
				public void actionPerformed( ActionEvent event)
				{
					uptownwater = uptownwaterField.getText();
					uptownele = uptowneleField.getText();
					uptownsecwater = uptownsecwaterField.getText();
					date = dateField.getText();
					buildingele1 = new String[count];
					buildingele2 = new String[count];
					for( int k=0; k<count; k++)
					{
						buildingele1[k] = buildinglifteleField[k].getText();
						buildingele2[k] = buildinglighteleField[k].getText();
						
					}
					
					nullvalue=judgenull(uptownwater,uptownele,uptownsecwater,buildingele1,buildingele2,date);
					if(nullvalue==0)
					{
						PublicMonthDataOperate operate = new PublicMonthDataOperate( in_id, building_id,  uptownwater, uptownele, uptownsecwater, buildingele1, buildingele2, date, count);
					}
					else
					{
						message2="�п�ֵ,����������";
						JOptionPane.showMessageDialog(null,message2,"Error",JOptionPane.PLAIN_MESSAGE);
					}
					
					System.out.println("action end");
				}
			}
			);
		c = new GridBagConstraints(9,y,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button3,c);
		panelin.add(button3);
		
		System.out.println("the 03-6");
		button4 = new JButton( "����" );
		button4.addActionListener(
			new ActionListener(){
				public void actionPerformed( ActionEvent event){
				PublicDataInputFrame.this.setVisible(false);
			}
			}
			);
		c = new GridBagConstraints(10,y,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button4,c);
		panelin.add(button4);
		
		setSize(1000,600);
		setVisible(true);
	}
	
	
	
	public void getuptown()//��ȡС����Ϣ
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			String url1 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection1 = DriverManager.getConnection(url1,"swing_wuye","swing_wuye");
			Statement stmt1 = connection1.createStatement(); 
			String sqlUptown = "SELECT district_id,district_name FROM district_info ORDER BY district_id";
			ResultSet rs1 = stmt1.executeQuery(sqlUptown);
			
			System.out.println("the 00");
		
			int i= 1;
			while( rs1.next() )
			{
				uptown_id[i] = rs1.getString( "district_id" );
				uptown_name[i] = rs1.getString( "district_name" );
				i++;
			}
			
			//System.out.println("the 01");
			
			rs1.close();
			connection1.close();
		}
		
		catch( Exception ex ) {
			System.out.println(ex);
			//System.exit(0);
		}//���ȡС����Ϣ
	}
	
	public void getbuilding(String uptown)//��ȡС���ڵ�¥����Ϣ
	{
		
		System.out.println("the 04");
		try{
			Class.forName("com.mysql.jdbc.Driver");
			String url2 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection2 = DriverManager.getConnection(url2,"swing_wuye","swing_wuye");
			Statement stmt2 = connection2.createStatement();
			String sqlBuilding = "SELECT building_id FROM building_info WHERE district_id="+uptown+" ORDER BY building_id";
			System.out.println("the 041");
			ResultSet rs2 = stmt2.executeQuery(sqlBuilding);
						
			int i = 0;
			while( rs2.next() )
			{
				building_id[i] = rs2.getString( "building_id" );
				i++;
			}
			count = i;
			//System.out.println("the 11");
			//panelin.repaint();
			rs2.close();
			connection2.close();
		}
					
		catch( Exception ex )
		{
			System.out.println( ex );
			//System.exit(0);
		}
	}
	
	public int judgenull(String value1, String value2, String value3, String value4[], String value5[], String value6)
	{
		int type=0;
		for( int i=0;i<count;i++)
		{
			if(value4[i].equals(""))
			{
				type=1;
			}
			if(value5[i].equals(""))
			{
				type=1;
			}
		}
		
		if(value1.equals(""))
		{
			type=1;
		}
		if(value2.equals(""))
		{
			type=1;
		}
		if(value3.equals(""))
		{
			type=1;
		}
		if(value6.equals(""))
		{
			type=1;
		}
		return(type);
	}
	
	public static void main(String args[])
	{
		PublicDataInputFrame ap = new PublicDataInputFrame(2);
		ap.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
}