import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;


public class Login extends JFrame
{
	private JLabel nameLabel,passwordLabel,pictureLabel;
	private JButton okButton,cancelButton,helpButton;
	private JTextField nameText,passText;
	private static JPasswordField passField;
	private JPanel buttonPanel,fieldPanel1,fieldPanel2,fieldPanel;
	private static Connection connection;
	private PreparedStatement statement;
	private String user,pwd;
	private static boolean found = false;
	private static Login login;

	
	public Login()
	{		
		super("��ӭʹ����ҵС���շѹ���ϵͳV1.0");
		Container con = getContentPane();
		con.setLayout(new BorderLayout());
	
		nameLabel=new JLabel("�û�����");
		nameText=new JTextField("",10);
		fieldPanel1=new JPanel();
		fieldPanel1.setLayout(new FlowLayout());
		fieldPanel1.add(nameLabel);
		fieldPanel1.add(nameText);
		
		
		passwordLabel = new JLabel(" �� �룺");
		passField=new JPasswordField(10);		
		fieldPanel2=new JPanel();
		fieldPanel2.setLayout(new FlowLayout());
		fieldPanel2.add(passwordLabel);
		fieldPanel2.add(passField);
		
		fieldPanel = new JPanel();
		fieldPanel.setLayout(new BorderLayout());
		fieldPanel.add(fieldPanel1,BorderLayout.NORTH);
		fieldPanel.add(fieldPanel2,BorderLayout.SOUTH);
		
		okButton=new JButton("ȷ��");		
		okButton.addActionListener(new LoginCheck());
		cancelButton = new JButton("ȡ��");
		cancelButton.addActionListener(
			new ActionListener()
			{
				public void actionPerformed(ActionEvent event)
				{
					System.exit(0);
				}
			}
		);
		helpButton=new JButton("����");
		buttonPanel=new JPanel();
		buttonPanel.setLayout(new FlowLayout());
		buttonPanel.add(okButton);
		buttonPanel.add(cancelButton);
		buttonPanel.add(helpButton);
		
		Icon bug = new ImageIcon("1.gif");
		pictureLabel=new JLabel(bug);
		
		con.add(pictureLabel);
		con.add(fieldPanel,BorderLayout.NORTH);
		con.add(buttonPanel,BorderLayout.SOUTH);
		
		
	}
	
	public static void changeUser()
	{
		login.setVisible(true);
		passField.setText("");
		found = false;
	}
	
	public static Connection getConn()
	{
		return connection;
	}
	
	public static void main(String args[])
	{
		login = new Login();
		login.setSize(300,125);
		login.setResizable(false);
		login.setVisible(true);
		login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	private class LoginCheck implements ActionListener
	{	
		public void actionPerformed(ActionEvent event)
		{
			user = nameText.getText();
			pwd = new String( passField.getPassword() );
			
			try{
				Class.forName("com.mysql.jdbc.Driver");
				connection = DriverManager.getConnection("jdbc:mysql://47.101.198.61:3306/swing_wuye","swing_wuye","swing_wuye");
				String sql = "select * from login_info";
				statement = connection.prepareStatement(sql);
				ResultSet result = statement.executeQuery();
				while(result.next())
				{
					if( user.compareTo(result.getString("uname")) == 0 && pwd.compareTo(result.getString("paswrd")) == 0 )
					{
						InterfaceStyle.setCurtentuser(user);
						System.out.println(user+":"+pwd);
						found = true;
						InterfaceStyle.mainFrame(user,result.getInt("purview"));
						Login.this.setVisible(false);
						
					}
				}
				if( !found ){
					JOptionPane.showMessageDialog(null,"�û������������������","����",JOptionPane.ERROR_MESSAGE);
					nameText.setText("");
					passField.setText("");
				}
				result.close();
				statement.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}
}

