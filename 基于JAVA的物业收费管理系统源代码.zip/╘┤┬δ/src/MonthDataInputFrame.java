import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.*;
import javax.swing.event.*;

public class MonthDataInputFrame extends JFrame //implements ActionListener
{
	private JButton button1, button2, button3;
	private JLabel uptownlabel, buildinglabel, roomlabel[], waterlabel[], elelabel[], gaslabel[], datelabel;
	private JTextField waterfield[], elefield[], gasfield[], datefield;
	private JComboBox uptownselect, buildingselect;
	private String uptownname[], uptownid[], buildingid[], roomid[], building_select, selectuptown, selectbuilding, sqlinsert[], uptownid_select;
	private String water[], ele[], gas[], delsql, date_in;
	//private Box boxes[], subboxes[];
	private int roomcount,lastwater[],lastele[],lastgas[],checktime,inputdate,lastdate,deldate,lastyear,lastmonth,delyear,delmonth,uptowncount,buildingcount;
	private String lastroomid[], uptown, building, inputbuilding, in_uptown, in_building, message2;
	//private JPanel panelin;
	//private int state;
	private GridBagConstraints c;
	private Insets inset;
	private GridBagLayout gridbag;
	private int time,t,type,nullvalue;
	
	//final Container panelin;
	
	/*public MonthDataInputFrame(JPanel p)
	{
		this.panelin=p;
		panelin.removeAll();
		mainperform();
		
		setSize(350,300);
		setVisible(true);
		
	}*/
	
	public void setVisble(boolean flag) {
		MonthDataInputFrame.this.setVisible(false);
	}
	
	public MonthDataInputFrame(int tt)
	{
		super("ѡ��С����¥��");
		type=tt;
		mainperform(type);
		//mainperform("qwqw");
		time = 0;
		t=0;
	}
	
	public MonthDataInputFrame(String uptown, String uptown_id, int tt)
	{
		super("ѡ��С����¥��");
		type = tt;
		mainperform(uptown,uptown_id,type);
		//mainperform("qwqw");
		time = 0;
		
		
	}
	
	public MonthDataInputFrame(String uptown,String building,String uptown_id)
	{
		super("��������");
		mainperform(uptown,building,uptown_id);
		//mainperform("qwqw");
		time = 0;
	}
	/*public void actionPerformed(ActionEvent e)
	{
		mainperform();	
	}*/
	
	public void mainperform(int tt)//�޲�������
	{
		Container panelin = getContentPane();
		
		panelin.removeAll();
		gridbag=new GridBagLayout();
		panelin.setLayout(gridbag);
		buildingid=new String[150];
		buildingid[0]=new String("ѡ��¥��");
		uptownid = new String[100];
		uptownname = new String[100];
		uptownname[0]=new String("ѡ��С��");
		roomid = new String[150];
		type = tt;
		getuptown();
		
		uptownlabel = new JLabel( "ѡ��С��" );
		uptownlabel.setToolTipText("�������˵���ѡ��С��" );
		inset = new Insets(5,5,5,5);
		c = new GridBagConstraints(2,1,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownlabel,c);
		panelin.add(uptownlabel);
		
		uptownselect = new JComboBox( uptownname );
		uptownselect.setMaximumRowCount( 5 );
		uptownselect.addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = uptownselect.getSelectedIndex();
					t++;
					getbuilding(uptownid[i]);
					
					if(t<2) {
						MonthDataInputFrame mdif2 = new MonthDataInputFrame(uptownname[i],uptownid[i], type);
						}
					MonthDataInputFrame.this.setVisible(false);
				}
			}
		);
		c = new GridBagConstraints(4,1,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownselect,c);
		panelin.add(uptownselect);
		
		buildinglabel = new JLabel( "ѡ��¥��" );
		buildinglabel.setToolTipText( "�������˵���ѡ��¥��" );
		c = new GridBagConstraints(2,2,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(buildinglabel,c);
		panelin.add(buildinglabel);
		
		buildingselect = new JComboBox( buildingid );
		buildingselect.setMaximumRowCount(5);
		c = new GridBagConstraints(4,2,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(buildingselect,c);
		panelin.add(buildingselect);
		
		button1 = new JButton( "ȷ��" );
		button1.setEnabled( false );
		c = new GridBagConstraints(3,4,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button1,c);
		panelin.add(button1);
		
		button2 = new JButton( "����" );
		button2.addActionListener(
			new ActionListener(){
				public void actionPerformed( ActionEvent event){
					MonthDataInputFrame.this.setVisible(false);
					//MonthDataInputFrame mdif1 = new MonthDataInputFrame();
				}
			}
			);
		c = new GridBagConstraints(5,4,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button2,c);
		panelin.add(button2);
		
		/*button3 = new JButton( "����" );
		button3.setEnabled( false );
		button3.setToolTipText( "�����������ݣ�����������" );
		c = new GridBagConstraints(7,4,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button3,c);
		panelin.add(button3);*/
		
		panelin.setVisible(true);
		
		
		setSize(350,300);
		setVisible(true);
	}
	
	
	
	public void mainperform( String inuptown, String inuptownid, int tt)//�������С����
	{
		time++;
		
		Container panelin = getContentPane();
		
		gridbag=new GridBagLayout();
		panelin.setLayout(gridbag);
		//buildingid=new String[150];
		
		uptownid = new String[100];
		uptownname = new String[100];
		uptownname[0] = new String(inuptown);
		getuptown();
		
		type=tt;
		
		int i=0;
		do{
			i++;
		}while(!uptownname[i].equals(inuptown));
		buildingid=new String[150]; 
		getbuilding(inuptownid);
		buildingid[0] = new String("ѡ��¥��");
		roomid = new String[150];
		
		uptown = new String(inuptown);
		uptownid_select = new String(inuptownid);
		
		
		uptownlabel = new JLabel( "ѡ��С��" );
		uptownlabel.setToolTipText("���ѡ��С��" );
		inset = new Insets(5,5,5,5);
		c = new GridBagConstraints(2,1,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownlabel,c);
		panelin.add(uptownlabel);
		//panelin.remove(uptownselect);
		
		uptownselect = new JComboBox( uptownname );
		
		uptownselect.setSelectedIndex(i);
		uptownselect.setMaximumRowCount( 5 );
		uptownselect.addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = uptownselect.getSelectedIndex();
					t++;
					getbuilding(uptownid[i]);
						//while(i==0)JOptionPane.showMessageDialog(null,"��ѡ����ȷ��С������");
					
					//getbuilding(uptownid[i]);
					//System.out.println(uptown[i]);
					if(t<2) {
						MonthDataInputFrame mdif2 = new MonthDataInputFrame(uptownname[i],uptownid[i], type);
						}
					//panelin.repaint();
					MonthDataInputFrame.this.setVisible(false);
				}
			}
		);
		c = new GridBagConstraints(4,1,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownselect,c);
		panelin.add(uptownselect);
		
		buildinglabel = new JLabel( "ѡ��¥��" );
		buildinglabel.setToolTipText( "���ѡ��¥��" );
		c = new GridBagConstraints(2,2,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(buildinglabel,c);
		panelin.add(buildinglabel);
		
		buildingselect = new JComboBox( buildingid );
		buildingselect.setMaximumRowCount(5);
		buildingselect.addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = buildingselect.getSelectedIndex();
					inputbuilding = buildingid[i];
					//MonthDataInputFrame mdif3 = new MonthDataInputFrame(uptown,buildingid[i]);
				}
			}
		);
		c = new GridBagConstraints(4,2,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(buildingselect,c);
		panelin.add(buildingselect);
		
		button1 = new JButton( "ȷ��" );
		button1.addActionListener( 
			new ActionListener(){
				public void actionPerformed( ActionEvent event) {
					if(type==1) {
						MonthDataInputFrame mdif3 = new MonthDataInputFrame( uptown, inputbuilding, uptownid_select);
						MonthDataInputFrame.this.setVisible(false);
						}
					else if(type==2){
						ChargeReport elecReport = new ChargeReport("����շѱ���",Integer.parseInt(uptownid_select),Integer.parseInt(inputbuilding));
					}
					else if(type==3){
						ChargeReport waterReport = new ChargeReport("ˮ���շѱ���",Integer.parseInt(uptownid_select),Integer.parseInt(inputbuilding));
					}
					else if(type==4){
						ChargeReport gasReport = new ChargeReport("ú�����շѱ���",Integer.parseInt(uptownid_select),Integer.parseInt(inputbuilding));
					}
						
					MonthDataInputFrame.this.setVisible(false);
				}
			}
			 );
		c = new GridBagConstraints(3,4,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button1,c);
		panelin.add(button1);
		
		button2 = new JButton( "����" );
		button2.addActionListener(
			new ActionListener(){
				public void actionPerformed( ActionEvent event){
				MonthDataInputFrame.this.setVisible(false);
				}
			}
			);
		c = new GridBagConstraints(5,4,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button2,c);
		panelin.add(button2);
		
		/*button3 = new JButton( "����" );
		button3.setEnabled( false );
		button3.setToolTipText( "�����������ݣ�����������" );
		button3.setToolTipText( "�����������ݣ�����������" );
		c = new GridBagConstraints(7,4,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button3,c);
		panelin.add(button3);*/
		
		panelin.repaint();
		panelin.setVisible(true);
		
		
		setSize(350,300);
		setVisible(true);
	}
	
	
	
	public void mainperform( String inuptown,String inbuilding, String id)//�������¥���ź�С����
	{
		
		Container panelin = getContentPane();
		
		//panelin.removeAll();
		gridbag=new GridBagLayout();
		panelin.setLayout(gridbag);
		System.out.println(inuptown);
		System.out.println(inbuilding);
		roomid = new String[150];
		/*int i=0;
		do{
			System.out.println(i);
			i++;
		}while(!uptownname[i].equals(inuptown));*/
		System.out.println("the 03-2");
		getroom( id, inbuilding);
		System.out.println("the 03-3");
		water = new String[roomcount];
		ele = new String[roomcount];
		gas = new String[roomcount];
		
		in_uptown = new String( id);
		in_building = new String( inbuilding );
		System.out.println("the 1000");
		
		datelabel = new JLabel("�������ڣ���ʽYYYYMM��");
		inset = new Insets(5,5,5,5);
		c = new GridBagConstraints(2,1,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(datelabel,c);
		panelin.add(datelabel);
		
		datefield = new JTextField(10);
		c = new GridBagConstraints(4,1,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(datefield,c);
		panelin.add(datefield);
		System.out.println("the 03-4");
		int x=4;
		
		for( int f=0;f<roomcount; f++)
		{
			System.out.println("the room id test"+roomid[f]);
		}
		waterlabel = new JLabel[roomcount];
		elelabel = new JLabel[roomcount];
		gaslabel = new JLabel[roomcount];
		roomlabel = new JLabel[roomcount];
		elefield = new JTextField[roomcount];
		waterfield = new JTextField[roomcount];
		gasfield = new JTextField[roomcount];
		for( int j = 0; j<roomcount; j++)
		{
			System.out.println("the 03--"+j);
			roomlabel[j] = new JLabel( roomid[j] );
			//System.out.println("the 03--"+j);
			waterfield[j] = new JTextField( 10 );
			elefield[j] = new JTextField( 10 );
			gasfield[j] = new JTextField( 10 );
			waterlabel[j] = new JLabel("ˮ������");
			elelabel[j] = new JLabel("�������");
			gaslabel[j] = new JLabel("ú��������");
			//System.out.println("the 03--"+j);
			x=j+4;
			c = new GridBagConstraints(2,x,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(roomlabel[j],c);
			panelin.add(roomlabel[j]);
			
			c = new GridBagConstraints(3,x,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(waterlabel[j],c);
			panelin.add(waterlabel[j]);
			
			c = new GridBagConstraints(4,x,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(waterfield[j],c);
			panelin.add(waterfield[j]);
			
			c = new GridBagConstraints(5,x,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(elelabel[j],c);
			panelin.add(elelabel[j]);
			
			c = new GridBagConstraints(6,x,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(elefield[j],c);
			panelin.add(elefield[j]);
			
			c = new GridBagConstraints(7,x,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(gaslabel[j],c);
			panelin.add(gaslabel[j]);
			
			c = new GridBagConstraints(8,x,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(gasfield[j],c);
			panelin.add(gasfield[j]);
		}
		x+=9;
		
		System.out.println("the 03-5");
		button1 = new JButton( "ȷ��" );
		button1.setEnabled( true );
		button1.addActionListener(//ִ�б��������ݿ���룬������ǰ������ɾ��
			new ActionListener() {
				public void actionPerformed( ActionEvent event)
				{
					
					date_in = datefield.getText();
					for( int k=0; k<roomcount; k++)
					{
						water[k] = waterfield[k].getText();
						ele[k] = elefield[k].getText();
						gas[k] = gasfield[k].getText();
						
					}
					for( int i=0; i<roomcount;i++)
					{
						System.out.println(water[i]);
						System.out.println(ele[i]);
						System.out.println(gas[i]);
						System.out.println(roomid[i]);
					}
					nullvalue=judgenull(water,ele,gas,date_in);
					if(nullvalue==0)
					{
						MonthDataOperate operate = new MonthDataOperate( in_uptown, in_building, roomid, water, ele, gas, date_in, roomcount);
						
					}
					else
					{
						message2="�п�ֵ,����������";
						JOptionPane.showMessageDialog(null,message2,"Error",JOptionPane.PLAIN_MESSAGE);
					}
					
				}
			}
			);
		c = new GridBagConstraints(6,x,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button1,c);
		panelin.add(button1);
		
		System.out.println("the 03-6");
		button2 = new JButton( "����" );
		button2.addActionListener(
			new ActionListener(){
				public void actionPerformed( ActionEvent event){
					//mainperform();
					MonthDataInputFrame.this.setVisible(false);
				}
			}
			);
		c = new GridBagConstraints(7,x,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button2,c);
		panelin.add(button2);
		
		System.out.println("the 03-7");
		/*button3 = new JButton( "����" );
		button3.setEnabled( true );
		button3.setToolTipText( "�����������ݣ�����������" );
			button3.addActionListener(
			new ActionListener() {
				public void actionPerformed( ActionEvent event )
				{
					for( int i = 0; i<roomcount; i++)
					{
						///waterfield[i] = new JTextField();
						waterfield[i].setText(""); 
						//elefield[i]  = new JTextField();
						elefield[i].setText("");
						//gasfield[i]  = new JTextField();
						gasfield[i].setText("");
						
					}
				}
			}
			);
		c = new GridBagConstraints(7,x,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button3,c);
		panelin.add(button3);*/
		
		panelin.setVisible(true);
		System.out.println("the 03-8");
		
		
		setSize(800,550);
		setVisible(true);
		
	}
	
	
	
	public void getuptown()//��ȡС����Ϣ
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			String url1 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection1 = DriverManager.getConnection(url1,"swing_wuye","swing_wuye");
			Statement stmt1 = connection1.createStatement(); 
			String sqlUptown = "SELECT district_id,district_name FROM district_info ORDER BY district_id";
			ResultSet rs1 = stmt1.executeQuery(sqlUptown);
			
			System.out.println("the 00");
		
			int i= 1;
			while( rs1.next() )
			{
				uptownid[i] = rs1.getString( "district_id" );
				uptownname[i] = rs1.getString( "district_name" );
				i++;
			}
			
			//System.out.println("the 01");
			
			rs1.close();
			connection1.close();
		}
		
		catch( Exception ex ) {
			System.out.println(ex);
			MonthDataInputFrame.this.setVisible(false);
		}//���ȡС����Ϣ
	}
	
	public void getbuilding(String uptown)//��ȡС���ڵ�¥����Ϣ
	{
		
		System.out.println("the 04");
		try{
			Class.forName("com.mysql.jdbc.Driver");
			String url2 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection2 = DriverManager.getConnection(url2,"swing_wuye","swing_wuye");
			Statement stmt2 = connection2.createStatement();
			String sqlBuilding = "SELECT building_id FROM building_info WHERE district_id="+uptown+" ORDER BY building_id";
			System.out.println("the 041");
			ResultSet rs2 = stmt2.executeQuery(sqlBuilding);
						
			int i = 1;
			while( rs2.next() )
			{
				buildingid[i] = rs2.getString( "building_id" );
				i++;
			}
			//System.out.println("the 11");
			//panelin.repaint();
			rs2.close();
			connection2.close();
		}
					
		catch( Exception ex )
		{
			System.out.println( ex );
			//MonthDataInputFrame.this.setVisible(false);
		}
	}
	
	public void getroom( String uptown,String building)//��ȡ¥���з�����Ϣ
	{
		System.out.println("getroom begin");
		try{
			Class.forName( "com.mysql.jdbc.Driver" );
			String url3 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection3 = DriverManager.getConnection( url3,"swing_wuye","swing_wuye" );
			Statement stmt3 = connection3.createStatement();
			String sqlRoom = "SELECT room_id FROM room_info WHERE district_id="+uptown+" AND building_id="+building+" ORDER BY room_id";
			ResultSet rs3 = stmt3.executeQuery( sqlRoom );
						
			int i=0;
			while( rs3.next() )
			{
				roomid[i] = rs3.getString( "room_id" );
				i++;
			}
						
			roomcount = i;
			rs3.close();
			connection3.close();
		}
					
		catch( Exception ex )
		{
			System.out.println( ex );
			
		}
		System.out.println("getroom out");
	}
	
	public int judgenull(String string1[], String string2[], String string3[], String value)
	{
		int type=0;
		System.out.println("type="+type);
		for( int i=0;i<roomcount;i++)
		{
			if(string1[i].equals(""))
			{
				type=1;
			}
			if(string2[i].equals(""))
			{
				type=1;
			}
			if(string3[i].equals(""))
			{
				type=1;
			}
		}
		
		if(value.equals(""))
		{
			type=1;
		}
		System.out.println("value"+value+"end");
		System.out.println("type="+type);
		return(type);
	}
	
	public static void main(String args[])
	{
		MonthDataInputFrame ap = new MonthDataInputFrame(1);
		//ap.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}