import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.*;
import javax.swing.event.*;

public class UptownShow extends JFrame
{
	private String uptownname[], uptownid[], water[], ele[], sec[];
	private String indate;
	private JLabel waterlabel[], elelabel[], seclabel[], namelabel[];
	private JTextField waterfield[], elefield[], secfield[];
	private int count,y;
	private GridBagConstraints c;
	private Insets inset;
	private GridBagLayout gridbag;
	
	public UptownShow(String date)
	{
		super("����С����"+date+"�ļ�¼");
		Container panelin = getContentPane();
		gridbag=new GridBagLayout();
		panelin.setLayout(gridbag);
		inset = new Insets(5,5,5,5);
		
		indate=new String(date);
		getdata(indate);
		
		waterlabel=new JLabel[count];
		elelabel=new JLabel[count];
		seclabel=new JLabel[count];
		namelabel=new JLabel[count];
		waterfield=new JTextField[count];
		elefield=new JTextField[count];
		secfield=new JTextField[count];
		
		y=2;
		for(int i=0;i<count;i++)
		{
			namelabel[i]=new JLabel(uptownname[i]);
			c = new GridBagConstraints(2,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(namelabel[i],c);
			panelin.add(namelabel[i]);
			
			waterlabel[i]=new JLabel("ˮ������");
			c = new GridBagConstraints(4,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(waterlabel[i],c);
			panelin.add(waterlabel[i]);
			
			waterfield[i]=new JTextField(water[i], 7);
			waterfield[i].setEditable(false);
			c = new GridBagConstraints(5,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(waterfield[i],c);
			panelin.add(waterfield[i]);
			
			elelabel[i]=new JLabel("�������");
			c = new GridBagConstraints(6,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(elelabel[i],c);
			panelin.add(elelabel[i]);
			
			elefield[i]=new JTextField(ele[i], 7);
			elefield[i].setEditable(false);
			c = new GridBagConstraints(7,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(elefield[i],c);
			panelin.add(elefield[i]);
			
			seclabel[i]=new JLabel("���ι�ˮ�õ�");
			c = new GridBagConstraints(8,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(seclabel[i],c);
			panelin.add(seclabel[i]);
			
			secfield[i]=new JTextField(sec[i], 7);
			secfield[i].setEditable(false);
			c = new GridBagConstraints(9,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(secfield[i],c);
			panelin.add(secfield[i]);
			
			y+=4;
		}
		
		setSize(800,600);
		setVisible(true);
	}
	
	public void getdata(String date)
	{
		water=new String[100];
		ele=new String[100];
		sec=new String[100];
		uptownname=new String[100];
		uptownid=new String[100];
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			String url1 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection1 = DriverManager.getConnection(url1,"swing_wuye","swing_wuye");
			Statement stmt1 = connection1.createStatement(); 
			String sqlUptown = "SELECT district_id,tot_water_reading,tot_elec_reading,sec_supply_reading FROM district_reading WHERE date="+date;
			ResultSet rs1 = stmt1.executeQuery(sqlUptown);
			
			System.out.println("the 00");
			
			int i=0;
			while( rs1.next() )
			{
				uptownid[i] = rs1.getString( "district_id" );
				water[i] = rs1.getString( "tot_water_reading" );
				ele[i] = rs1.getString( "tot_elec_reading" );
				sec[i] = rs1.getString( "sec_supply_reading" );
				i++;
			}
			count=i;
			//System.out.println("the 01");
			
			rs1.close();
			connection1.close();
		}
		
		catch( Exception ex ) {
			System.out.println(ex);
			//System.exit(0);
		}
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			String url1 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection1 = DriverManager.getConnection(url1,"swing_wuye","swing_wuye");
			Statement stmt1 = connection1.createStatement();
			for(int i=0;i<count;i++) 
			{
				String sqlUptown = "SELECT district_name FROM district_info WHERE district_id="+uptownid[i];
				ResultSet rs1 = stmt1.executeQuery(sqlUptown);
				while( rs1.next() )
				{
					uptownname[i] = rs1.getString( "district_name" );
				}
				rs1.close();
			}
			
			
			connection1.close();
		}
		
		catch( Exception ex ) {
			System.out.println(ex);
			//System.exit(0);
		}
	}
}