import javax.swing.table.AbstractTableModel;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.sql.*;
import java.util.*;



public class ChargeReport extends JFrame
{
	
	
	private JPanel buttonPanel,tablePanel,fieldPanel,fieldPanel1,fieldPanel2,fieldPanel3;
		
	String title[]= {"С����","¥��","����","ҵ������","��;","���¶���","���¶���","����","Ӧ���ܶ�"};

	Vector vector=new Vector();
	

	Connection connection = null;
	ResultSet rSet = null;
	Statement statement = null;
	AbstractTableModel tm;
	
	private int tt,did,bid,time;
	private double uPrice;
	
	public ChargeReport(String type,int district_id,int building_id)
	{
		super(type);
		if(type.compareTo("����շѱ���")==0)
			tt=1;
		else if(type.compareTo("ˮ���շѱ���")==0)
			tt=2;
		else if(type.compareTo("ú�����շѱ���")==0)
			tt=3;
			
		did=district_id;
		bid=building_id;
		time=GetSystime.getSystime();
		
		enableEvents(AWTEvent.WINDOW_EVENT_MASK);
		try
		{
			jbInit();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		setSize(480,480);
		setResizable(false);
		setVisible(true);
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE );		
	}
	
	private void jbInit() throws SQLException
	{
		Container con = getContentPane();
		//con.setLayout(new BorderLayout());
						
		tablePanel=new JPanel();
		
		createtable();
		con.add(tablePanel);
		updated();
		
	}
	
/*	public void static void main(String[] args)
	{
		ChargeReport chargeReport=new ChargeReport("����շѱ���",1,1);
		chargeReport.setSize(480,480);
		chargeReport.setResizable(false);
		chargeReport.setVisible(true);
		chargeReport.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE );
	}*/
	
	private void createtable()
	{
		JTable table;
		JScrollPane scroll;
	//	vector = new Vector();
		tm = new AbstractTableModel()
		{
			public int getColumnCount()
			{
				return title.length;
			}
			public int getRowCount()
			{
				return vector.size();
			}
			public String getColumnName(int col) 
			{
				return title[col];
			}
			
			public Object getValueAt(int row, int column)
			{
				if(!vector.isEmpty())
				{
					return ((Vector)vector.elementAt(row)).elementAt(column);
				}
				else
				{
					return null;
				}
	
			}
			public void setValueAt(Object value, int row, int column)
			{
				
			}
		
			public Class getColumnClass(int c)
			{
				return getValueAt(0,c).getClass();
			}
			public boolean isCellEditable(int row, int column)
			{
				return false;
			}
		};
		
		table = new JTable(tm);
		table.setToolTipText("Display Query Result");
		table.setAutoResizeMode(table.AUTO_RESIZE_OFF);
		table.setCellSelectionEnabled(false);
		table.setShowHorizontalLines(true);
		table.setShowVerticalLines(true);
		scroll = new JScrollPane(table);
		scroll.setBounds(6,20,540,250);
		tablePanel.add(scroll);
		
		
	}
	
	void updated()
	{
			getUnitPrice();
			try{
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://47.101.198.61:3306/swing_wuye";
			connection = DriverManager.getConnection(url,"swing_wuye","swing_wuye");
			statement = connection.createStatement();
			String sql3=null;
			sql3="select r.district_id,r.building_id,r.room_id,r.oname,r.purpose,ur1.water_reading,ur2.water_reading from room_info r,user_reading ur1,user_reading ur2 where r.district_id="+did+" and r.district_id=ur1.district_id and ur1.district_id=ur2.district_id and r.building_id="+bid+" and r.building_id=ur1.building_id and ur1.building_id=ur2.building_id and r.room_id=ur1.room_id and ur1.room_id=ur2.room_id and ur1.date="+(time-1)+" and ur2.date="+time;
			rSet=statement.executeQuery(sql3);
			
			if(rSet.next()== true)
			{
				String sql = sql3;
				ResultSet rs=statement.executeQuery(sql);
								
				vector.removeAllElements();
				tm.fireTableStructureChanged();
			
				while(rs.next())
				{
					Vector rec_vector=new Vector();
					rec_vector.addElement(String.valueOf(rs.getInt(1)));
					rec_vector.addElement(String.valueOf(rs.getInt(2)));
					rec_vector.addElement(String.valueOf(rs.getInt(3)));
					rec_vector.addElement(rs.getString(4));
					rec_vector.addElement(rs.getString(5));
			 		double last=rs.getDouble(6),current=rs.getDouble(7);
					rec_vector.addElement(String.valueOf(last));
					rec_vector.addElement(String.valueOf(current));
					rec_vector.addElement(String.valueOf(uPrice));
					rec_vector.addElement(String.valueOf((current-last)*uPrice));
					vector.addElement(rec_vector);
				}
				tm.fireTableStructureChanged();
			}else {
				JOptionPane.showMessageDialog(null,"û�����ݣ�","����뵱�º����µ����ݣ�",JOptionPane.PLAIN_MESSAGE);
			}
			
			
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		finally{
			try{
				if(statement != null){
					statement.close();
				}
				if(connection != null){
					connection.close();
				}
			}
			catch(SQLException ex){
				System.out.println("\nERROR:---------SQLSQLException--------\n");
				System.out.println("Message: "+ ex.getMessage());
				System.out.println("SQLState: "+ ex.getSQLState());
				System.out.println("ErrorCode: "+ ex.getErrorCode());
			}
		}
	}
	
	void getUnitPrice()
	{
			String sql=null;
			try{
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://47.101.198.61:3306/swing_wuye";
			connection = DriverManager.getConnection(url,"swing_wuye","swing_wuye");
			statement = connection.createStatement();
				sql="select * from unit_price_info where charge_id="+tt;
		/*	if(tt==1)
				sql="select * from unit_price_info where charge_id=1";
			if(tt==2)
				sql="select * from unit_price_info where charge_id=2";
			if(tt==3)
				sql="select * from unit_price_info where charge_id=3";*/
			rSet=statement.executeQuery(sql);
			if(rSet.next()== true)
				uPrice=rSet.getDouble("unit_price");
			}
		catch(Exception ex){
			ex.printStackTrace();
		}
		finally{
			try{
				if(statement != null){
					statement.close();
				}
				if(connection != null){
					connection.close();
				}
			}
			catch(SQLException ex){
				System.out.println("\nERROR:---------SQLSQLException--------\n");
				System.out.println("Message: "+ ex.getMessage());
				System.out.println("SQLState: "+ ex.getSQLState());
				System.out.println("ErrorCode: "+ ex.getErrorCode());
			}
		}
		
	}
}