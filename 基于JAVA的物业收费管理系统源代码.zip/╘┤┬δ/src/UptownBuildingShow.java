import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.*;
import javax.swing.event.*;

public class UptownBuildingShow extends JFrame
{
	private String inuptownid, inuptownname, indate;
	private String building[], lift[], light[];
	private JLabel buildinglabel[], liftlabel[], lightlabel[];
	private JTextField liftfield[], lightfield[];
	private int count,y;
	private GridBagConstraints c;
	private Insets inset;
	private GridBagLayout gridbag;
	
	public UptownBuildingShow(String date, String uptownid, String uptownname)
	{
		super(uptownname+"��"+date+"����¥��ļ�¼");
		Container panelin = getContentPane();
		gridbag=new GridBagLayout();
		panelin.setLayout(gridbag);
		inset = new Insets(5,5,5,5);
		
		indate=new String(date);
		inuptownid=new String(uptownid);
		inuptownname=new String(uptownname);
		
		getdata(indate, inuptownid);
		
		buildinglabel=new JLabel[count];
		liftlabel=new JLabel[count];
		lightlabel=new JLabel[count];
		liftfield=new JTextField[count];
		lightfield=new JTextField[count];
		
		y=2;
		for(int i=0;i<count;i++)
		{
			buildinglabel[i]=new JLabel(building[i]);
			c = new GridBagConstraints(2,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(buildinglabel[i],c);
			panelin.add(buildinglabel[i]);
			
			liftlabel[i]=new JLabel("���ݵ������");
			c = new GridBagConstraints(4,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(liftlabel[i],c);
			panelin.add(liftlabel[i]);
			
			liftfield[i]=new JTextField(lift[i], 7);
			liftfield[i].setEditable(false);
			c = new GridBagConstraints(5,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(liftfield[i],c);
			panelin.add(liftfield[i]);
			
			lightlabel[i]=new JLabel("�����������");
			c = new GridBagConstraints(6,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(lightlabel[i],c);
			panelin.add(lightlabel[i]);
			
			lightfield[i]=new JTextField(light[i], 7);
			lightfield[i].setEditable(false);
			c = new GridBagConstraints(7,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(lightfield[i],c);
			panelin.add(lightfield[i]);
			
			y+=4;
		}
		
		setSize(800,600);
		setVisible(true);
	}
	
	public void getdata(String date, String uptownid)
	{
		building=new String[100];
		lift=new String[100];
		light=new String[100];
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			String url1 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection1 = DriverManager.getConnection(url1,"swing_wuye","swing_wuye");
			Statement stmt1 = connection1.createStatement(); 
			String sqlUptown = "SELECT building_id,lift_ele_reading,lighting_reading FROM building_elec_reading WHERE date="+date+" AND district_id="+uptownid;
			ResultSet rs1 = stmt1.executeQuery(sqlUptown);
			
			System.out.println("the 00");
			
			int i=0;
			while( rs1.next() )
			{
				building[i] = rs1.getString( "building_id" );
				lift[i] = rs1.getString( "lift_ele_reading" );
				light[i] = rs1.getString( "lighting_reading" );
				i++;
			}
			count=i;
			//System.out.println("the 01");
			
			rs1.close();
			connection1.close();
		}
		
		catch( Exception ex ) {
			System.out.println(ex);
			//System.exit(0);
		}
	}
}