import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.*;
import java.applet.*;
import javax.swing.event.*;

public class InfoMaintain extends JFrame implements ActionListener{
	
	private Connection c;
	private JTable out;
	private JPanel out1,out2;
	private String Mouaction;
	private JButton button1,button2,button3;
	private JPanel pr;
	private String district_no,building_no;
	
	public InfoMaintain(JPanel p)
	{
		this.pr = p;
	}
		
	public void actionPerformed(ActionEvent e){
		Mouaction = e.getActionCommand();
		try
		{
				Class.forName("com.mysql.jdbc.Driver");
				c = DriverManager.getConnection("jdbc:mysql://47.101.198.61:3306/swing_wuye","swing_wuye","swing_wuye");
		}
		catch(Exception err)
		{
			err.printStackTrace();
		}//�������ݿ����ӣ�
		district_no = new String();
		getTable();
	}
	
	public void getTable()
	{
		if(Mouaction.equals("С����Ϣά��"))//����ѡ"С����Ϣά��"ʱ����Ϊ��	
		{
			try
			{
				Statement sql1 = c.createStatement();
				Vector columnName = new Vector();
				Vector rows = new Vector();
				Vector temp = new Vector();//�����������������ݿ����ݲ���
				ResultSet rsl1 = sql1.executeQuery("SELECT * FROM district_info");
				ResultSetMetaData rsmd1 = rsl1.getMetaData();//��ȡ�����ֶ�����
				for(int i = 1;i<rsmd1.getColumnCount();++i)//��ȡ����
					columnName.addElement(rsmd1.getColumnName(i));
				while(rsl1.next())//���ж�ȡ����
				{
					for(int j=1;j<=rsmd1.getColumnCount();j++)
					{
						temp.addElement(rsl1.getString(j));
					}
					rows.addElement(temp);
				}
				
				out = new JTable(rows,columnName);
				out1 = new JPanel();
				out1.setLayout(new FlowLayout());
				out2 = new JPanel();
				out2.setLayout(new BorderLayout());
				button1 = new JButton("�޸�");
				button2 = new JButton("����");
				button3 = new JButton("����");
				out1.add(button1);
				out1.add(button2);
				out1.add(button3);
				out2.add(out,BorderLayout.CENTER);
				out2.add(out1,BorderLayout.SOUTH);
		    	pr.removeAll();
				//pr.repaint();
				pr.add(out2);
				pr.repaint();
				
				sql1.close();
				rsl1.close();		    
				
			}
			catch(Exception sqlex)
			{
				sqlex.printStackTrace();
			}
		}
		
		else if(Mouaction.equals("¥����Ϣά��"))
		{
			//try
			//{
				SelectDistrict ss = new SelectDistrict(district_no);
				System.out.println(district_no);
			//}
			/*catch(Exception sqlex1)
			{
				sqlex1.printStackTrace();
			}*/
		}
		
		/*else if(Mouaction.equals("ҵ��/������Ϣά��"))
		{
			try
			{
			}
			catch(Exception sqlex2)
			{
				sqlex2.printStackTrace();
			}
		}*/
	}
	
	public class SelectDistrict extends JFrame
	{
			private Connection con1;
			private Container c1;
			private JList dist;
			private String rslt1[],rslt[],rslt2[];
			private String temp;
			
		public SelectDistrict(String dist_no)
		{
			super("ѡ��С��");
			this.temp = dist_no;
			
			c1 = getContentPane();
			c1.setLayout(new FlowLayout());
			
			rslt = new String[20]; 		 
			rslt1 = new String[20];
			rslt2 = new String[20];			
			try
			{
				Class.forName("com.mysql.jdbc.Driver");
				con1 = DriverManager.getConnection("jdbc:mysql://47.101.198.61:3306/swing_wuye","swing_wuye","swing_wuye");
			}
				catch(Exception err)
			{
					err.printStackTrace();
			}//�������ݿ����ӣ�
			
			try
			{				
				Statement sql2 = con1.createStatement();
				ResultSet rsl_2 = sql2.executeQuery("SELECT district_id,district_name FROM district_info");
				ResultSetMetaData rsmd1 = rsl_2.getMetaData();
				
				int s = 0;
				while(rsl_2.next())
				{
					for(int j =1;j<=rsmd1.getColumnCount();j++)
					{
						rslt2[s] = rsl_2.getString(j);
						s++;
					}
				}
												
				for(int i = 0;i<rslt2.length;i = i+2)
				{
					rslt1[i] = rslt2[i];
					rslt[i] = rslt2[i + 1];
				}
				
				dist = new JList(rslt);
				dist.setVisibleRowCount(5);
				
				dist.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
				c1.add(new JScrollPane(dist));
				
				dist.addListSelectionListener(
					new ListSelectionListener()
					{
						public void valueChanged(ListSelectionEvent event)
						{
							temp = rslt1[dist.getSelectedIndex()];
							setVisible(false);
						}		
					}
				);
				
				setSize(300,200);
				setVisible(true);
				
			}
			catch(Exception sqlex)
			{
				sqlex.printStackTrace();
			}
		}
	}			
}