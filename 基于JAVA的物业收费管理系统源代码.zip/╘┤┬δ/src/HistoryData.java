import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.*;
import javax.swing.event.*;

public class HistoryData extends JFrame
{
	private GridBagConstraints c;
	private Insets inset;
	private GridBagLayout gridbag;
	
	private String uptown_name[], uptown_id[], building_id[], room_id[], date[];
	private int indate;
	private JButton button3, button4;
	private JComboBox uptownbox, buildingbox, roombox, datebox;
	private JLabel uptownLabel, buildingLabel, roomLabel, dateLabel;
	private String inuptownid, inuptownname, inbuilding, inroom;
	private String water,gas,sec,ele,lift,light;
	private String waters[], gass[], eles[], lifts[], lights[], dates[], secs[];
	private int k, t;
	
	public HistoryData( int tt)
	{
		System.out.println("init 1");
		t=0;
		if(tt==1)
		{
			uptowndata();
		}
		if(tt==2)
		{
			buildingdata();
		}
		if(tt==3)
		{
			roomdata();
		}
	}
	
	public HistoryData( int tt, String uptown, String uptownname)
	{
		System.out.println("init 2");
		String id, name;
		t=0;
		id=new String(uptown);
		name=new String(uptownname);
		if(tt==1)
		{
			uptowndata(id,name);
		}
		if(tt==2)
		{
			buildingdata(id,name);
		}
		if(tt==3)
		{
			roomdata(id,name);
		}
	}
	
	public HistoryData(int tt, String uptown, String uptownname,String building)
	{
		System.out.println("init 3");
		String id1, id2, name;
		t=0;
		id1=new String(uptown);
		id2=new String(building);
		name=new String(uptownname);
		if(tt==2)
		{
			buildingdata(id1,id2,name);
		}
		if(tt==3)
		{
			roomdata(id1,id2,name);
		}
	}
	
	public HistoryData(int tt, String uptown, String uptownname, String building, String room)
	{
		System.out.println("init 4");
		String id1, id2, id3, name;
		id1=new String(uptown);
		id2=new String(building);
		id3=new String(room);
		name=new String(uptownname);
		
		System.out.println("id3 ="+id3);
		roomdata(id1,id2,id3,name);
	}
	
	public HistoryData(String id, String name)//��ѯС��ȫ����¼
	{
		super("��ѯС��");
		//String waters[], eles[], secs[], dates[];
		System.out.println("init 5");
		JLabel titleLabel, dateLabel[], waterLabel[], eleLabel[], secLabel[];
		JTextField  waterField[], eleField[], secField[];
		JButton button1, button2;
		int y;
		
		Container panelin = getContentPane();
		gridbag=new GridBagLayout();
		panelin.setLayout(gridbag);
		
		waters = new String[3];
		eles = new String[3];
		secs = new String[3];
		dates = new String[3];
		dateLabel = new JLabel[3];
		waterLabel = new JLabel[3];
		eleLabel = new JLabel[3];
		secLabel = new JLabel[3];
		waterField = new JTextField[3];
		eleField = new JTextField[3];
		secField = new JTextField[3];
		
		
		try{
			Class.forName( "com.mysql.jdbc.Driver" );
			String url4 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection4 = DriverManager.getConnection( url4 ,"swing_wuye","swing_wuye");
			Statement stmt4 = connection4.createStatement();
			String sqlLastData = "SELECT tot_water_reading, tot_elec_reading, sec_supply_reading, date FROM district_reading WHERE district_id="+id;
			ResultSet rsLastData = stmt4.executeQuery( sqlLastData );
			
			k=0;
			while(rsLastData.next())
			{
				waters[k] = rsLastData.getString( "tot_water_reading");
				eles[k] = rsLastData.getString( "tot_elec_reading");
				secs[k] = rsLastData.getString("sec_supply_reading");
				dates[k] = rsLastData.getString("date");
				k++;
			}
			
			rsLastData.close();
			connection4.close();
		}
		
		catch( Exception ex )
		{
			System.out.println(ex);
			
		}
		
		titleLabel = new JLabel(name+"��������µ�ˮ�����빩ˮ�õ����");
		inset = new Insets(5,5,5,5);
		c = new GridBagConstraints(2,1,3,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(titleLabel,c);
		panelin.add(titleLabel);
		
		System.out.println(dates[0]);
		System.out.println(dates[1]);
		System.out.println(dates[2]);
		System.out.println(k);
		
		y=4;
		for( int j=0;j<k;j++)
		{
			dateLabel[j]=new JLabel(dates[j]);
			c = new GridBagConstraints(2,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(dateLabel[j],c);
			panelin.add(dateLabel[j]);
			
			waterLabel[j]=new JLabel("��ˮ");
			c = new GridBagConstraints(4,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(waterLabel[j],c);
			panelin.add(waterLabel[j]);
			
			waterField[j]=new JTextField(waters[j], 7);
			waterField[j].setEditable(false);
			c = new GridBagConstraints(6,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(waterField[j],c);
			panelin.add(waterField[j]);
			
			eleLabel[j]=new JLabel("�õ�");
			c = new GridBagConstraints(8,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(eleLabel[j],c);
			panelin.add(eleLabel[j]);
			
			eleField[j]=new JTextField(eles[j], 7);
			eleField[j].setEditable(false);
			c = new GridBagConstraints(10,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(eleField[j],c);
			panelin.add(eleField[j]);
			
			secLabel[j]=new JLabel("���ι�ˮ�õ�");
			c = new GridBagConstraints(12,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(secLabel[j],c);
			panelin.add(secLabel[j]);
			
			secField[j]=new JTextField(secs[j], 7);
			secField[j].setEditable(false);
			c = new GridBagConstraints(14,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(secField[j],c);
			panelin.add(secField[j]);
			
			y+=5;
		}
		
		y+=4;
		
		button1=new JButton("������ѯ");
		button1.addActionListener(
			new ActionListener()
			{
				public void actionPerformed( ActionEvent event){
					HistoryData rdif = new HistoryData( 1 );
					HistoryData.this.setVisible(false);
				}
			}
			);
		c = new GridBagConstraints(7,y,2,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button1,c);
		panelin.add(button1);
		
		button2 = new JButton( "����" );
		button2.addActionListener(
			new ActionListener(){
				public void actionPerformed( ActionEvent event){
					HistoryData.this.setVisible(false);
				}
			}
			);
		c = new GridBagConstraints(10,y,2,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button2,c);
		panelin.add(button2);
		
		setSize(800,300);
		setVisible(true);
	}
	
	public HistoryData(String id,String name, int date)//��ѯ�ض�ʱ��С����¼
	{
		super("��ѯС��");
		//String water, ele, sec;
		System.out.println("init 6");
		JLabel titleLabel, dateLabel, waterLabel, eleLabel, secLabel;
		JTextField  waterField, eleField, secField;
		JButton button1, button2;
		
		Container panelin = getContentPane();
		gridbag=new GridBagLayout();
		panelin.setLayout(gridbag);
		
		try{
			Class.forName( "com.mysql.jdbc.Driver" );
			String url4 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection4 = DriverManager.getConnection( url4 ,"swing_wuye","swing_wuye");
			Statement stmt4 = connection4.createStatement();
			String sqlLastData = "SELECT tot_water_reading, tot_elec_reading, sec_supply_reading FROM district_reading WHERE district_id="+id+"AND date="+date;
			ResultSet rsLastData = stmt4.executeQuery( sqlLastData );
			
			while(rsLastData.next())
			{
				water = rsLastData.getString( "tot_water_reading");
				ele = rsLastData.getString( "tot_elec_reading");
				sec = rsLastData.getString("sec_supply_reading");
			}
			
			rsLastData.close();
			connection4.close();
		}
		
		catch( Exception ex )
		{
			System.out.println(ex);
			
		}
		
		titleLabel = new JLabel(name+"��"+date+"��ˮ����Ͷ��ι�ˮ�õ����");
		inset = new Insets(5,5,5,5);
		c = new GridBagConstraints(2,1,3,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(titleLabel,c);
		panelin.add(titleLabel);
		
		waterLabel=new JLabel("��ˮ");
		c = new GridBagConstraints(2,3,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(waterLabel,c);
		panelin.add(waterLabel);
			
		waterField=new JTextField(water, 7);
		waterField.setEditable(false);
		c = new GridBagConstraints(4,3,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(waterField,c);
		panelin.add(waterField);
		
		eleLabel=new JLabel("�õ�");
		c = new GridBagConstraints(6,3,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(eleLabel,c);
		panelin.add(eleLabel);
			
		eleField=new JTextField(ele, 7);
		eleField.setEditable(false);
		c = new GridBagConstraints(8,3,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(eleField,c);
		panelin.add(eleField);
			
		secLabel=new JLabel("���ι�ˮ�õ�");
		c = new GridBagConstraints(10,3,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(secLabel,c);
		panelin.add(secLabel);
			
		secField=new JTextField(sec, 7);
		secField.setEditable(false);
		c = new GridBagConstraints(12,3,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(secField,c);
		panelin.add(secField);
		
		button1=new JButton("������ѯ");
		button1.addActionListener(
			new ActionListener()
			{
				public void actionPerformed( ActionEvent event){
					HistoryData rdif = new HistoryData( 1 );
					HistoryData.this.setVisible(false);
				}
			}
			);
		c = new GridBagConstraints(5,5,2,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button1,c);
		panelin.add(button1);
		
		button2 = new JButton( "����" );
		button2.addActionListener(
			new ActionListener(){
				public void actionPerformed( ActionEvent event){
					HistoryData.this.setVisible(false);
				}
			}
			);
		c = new GridBagConstraints(8,5,2,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button2,c);
		panelin.add(button2);
		
		setSize(800,300);
		setVisible(true);
	}
	
	public HistoryData(String uptownid, String uptownname, String buildingid)//��ѯ¥��ȫ����¼
	{
		super("��ѯ¥��");
		System.out.println("init 7");
		JLabel dateLabel[], titleLabel, liftLabel[], lightLabel[];
		JTextField liftField[], lightField[];
		JButton button1, button2; 
		//String lifts[],lights[],dates[];
		int y;
		Container panelin = getContentPane();
		gridbag=new GridBagLayout();
		panelin.setLayout(gridbag);
		
		dateLabel = new JLabel[3];
		liftLabel = new JLabel[3];
		lightLabel = new JLabel[3];
		liftField = new JTextField[3];
		lightField = new JTextField[3];
		lifts=new String[3];
		lights=new String[3];
		dates=new String[3];
		
		try{
			Class.forName( "com.mysql.jdbc.Driver" );
			String url4 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection4 = DriverManager.getConnection( url4 ,"swing_wuye","swing_wuye");
			Statement stmt4 = connection4.createStatement();
			String sqlLastData = "SELECT lift_ele_reading, lighting_reading, date FROM building_elec_reading WHERE district_id="+uptownid+" AND building_id="+buildingid;
			ResultSet rsLastData = stmt4.executeQuery( sqlLastData );
			
			k=0;
			while(rsLastData.next())
			{
				lifts[k] = rsLastData.getString( "lift_ele_reading");
				lights[k] = rsLastData.getString( "lighting_reading");
				dates[k] = rsLastData.getString("date" );
				k++;
			}
			
			rsLastData.close();
			connection4.close(); 
		}
		
		catch( Exception ex )
		{
			System.out.println(ex);
			
		}
		
		titleLabel = new JLabel(uptownname+"��"+buildingid+"��������µ��ݺ������õ����");
		inset = new Insets(5,5,5,5);
		c = new GridBagConstraints(2,1,4,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(titleLabel,c);
		panelin.add(titleLabel);
		
		y=4;
		for( int j=0;j<k;j++)
		{
			dateLabel[j]=new JLabel(dates[j]);
			c = new GridBagConstraints(2,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(dateLabel[j],c);
			panelin.add(dateLabel[j]);
			
			liftLabel[j]=new JLabel("������ˮ");
			c = new GridBagConstraints(4,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(liftLabel[j],c);
			panelin.add(liftLabel[j]);
			
			liftField[j]=new JTextField(lifts[j], 7);
			liftField[j].setEditable(false);
			c = new GridBagConstraints(6,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(liftField[j],c);
			panelin.add(liftField[j]);
			
			lightLabel[j]=new JLabel("�����õ�");
			c = new GridBagConstraints(8,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(lightLabel[j],c);
			panelin.add(lightLabel[j]);
			
			lightField[j]=new JTextField(lights[j], 7);
			lightField[j].setEditable(false);
			c = new GridBagConstraints(10,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(lightField[j],c);
			panelin.add(lightField[j]);
			
			y+=4;
			
		}
		
		y+=4;
		
		button1=new JButton("������ѯ");
		button1.addActionListener(
			new ActionListener()
			{
				public void actionPerformed( ActionEvent event){
					HistoryData rdif = new HistoryData( 2 );
				}
			}
			);
		c = new GridBagConstraints(7,y,2,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button1,c);
		panelin.add(button1);
		
		button2 = new JButton( "����" );
		button2.addActionListener(
			new ActionListener(){
				public void actionPerformed( ActionEvent event){
					HistoryData.this.setVisible(false);
				}
			}
			);
		c = new GridBagConstraints(10,y,2,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button2,c);
		panelin.add(button2);
		
		setSize(800,300);
		setVisible(true);
	}
	
	public HistoryData(String uptownid, String uptownname, String buildingid, int date)//��ѯ¥��ȫ����¼
	{
		super("��ѯ¥��");
		System.out.println("init 8");
		JLabel  titleLabel, liftLabel, lightLabel;
		JTextField liftField, lightField;
		JButton button1, button2; 
		//String lift,light;
		Container panelin = getContentPane();
		gridbag=new GridBagLayout();
		panelin.setLayout(gridbag);
		
		try{
			Class.forName( "com.mysql.jdbc.Driver" );
			String url4 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection4 = DriverManager.getConnection( url4 ,"swing_wuye","swing_wuye");
			Statement stmt4 = connection4.createStatement();
			String sqlLastData = "SELECT lift_ele_reading, lighting_reading FROM building_elec_reading WHERE district_id="+uptownid+" AND building_id="+buildingid+" AND date="+date;
			ResultSet rsLastData = stmt4.executeQuery( sqlLastData );
			
			while(rsLastData.next())
			{
				lift = rsLastData.getString( "lift_ele_reading");
				light = rsLastData.getString( "lighting_reading");
			}
			
			rsLastData.close();
			connection4.close(); 
		}
		
		catch( Exception ex )
		{
			System.out.println(ex);
			
		}
		
		titleLabel = new JLabel(uptownname+"��"+buildingid+"��"+date+"�ĵ��ݺ������õ����");
		inset = new Insets(5,5,5,5);
		c = new GridBagConstraints(2,1,4,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(titleLabel,c);
		panelin.add(titleLabel);
		
		liftLabel=new JLabel("������ˮ");
		c = new GridBagConstraints(2,3,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(liftLabel,c);
		panelin.add(liftLabel);
			
		liftField=new JTextField(lift, 7);
		liftField.setEditable(false);
		c = new GridBagConstraints(4,3,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(liftField,c);
		panelin.add(liftField);
			
		lightLabel=new JLabel("�����õ�");
		c = new GridBagConstraints(6,3,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(lightLabel,c);
		panelin.add(lightLabel);
			
		lightField=new JTextField(light, 7);
		lightField.setEditable(false);
		c = new GridBagConstraints(8,3,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(lightField,c);
		panelin.add(lightField);
		
		button1=new JButton("������ѯ");
		button1.addActionListener(
			new ActionListener()
			{
				public void actionPerformed( ActionEvent event){
					HistoryData rdif = new HistoryData( 2 );
				}
			}
			);
		c = new GridBagConstraints(5,5,2,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button1,c);
		panelin.add(button1);
		
		button2 = new JButton( "����" );
		button2.addActionListener(
			new ActionListener(){
				public void actionPerformed( ActionEvent event){
					HistoryData.this.setVisible(false);
				}
			}
			);
		c = new GridBagConstraints(8,5,2,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button2,c);
		panelin.add(button2);
		
		setSize(800,300);
		setVisible(true);
	}
	
	public HistoryData(String uptownid, String uptownname, String buildingid, String roomid)
	{
		super("��ѯҵ��");
		System.out.println("init 9");
		JLabel titleLabel, dateLabel[], waterLabel[], eleLabel[], gasLabel[];
		JTextField waterField[], eleField[], gasField[];
		JButton button1, button2;
		//String dates[], waters[], eles[], gass[];
		int y;
		Container panelin = getContentPane();
		gridbag=new GridBagLayout();
		panelin.setLayout(gridbag);
		
		dateLabel=new JLabel[3];
		waterLabel=new JLabel[3];
		eleLabel=new JLabel[3];
		gasLabel=new JLabel[3];
		waterField=new JTextField[3];
		eleField=new JTextField[3];
		gasField=new JTextField[3];
		dates=new String[3];
		waters=new String[3];
		eles=new String[3];
		gass=new String[3];
		
		try{
			Class.forName( "com.mysql.jdbc.Driver" );
			String url4 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection4 = DriverManager.getConnection( url4 ,"swing_wuye","swing_wuye");
			Statement stmt4 = connection4.createStatement();
			String sqlLastData = "SELECT  water_reading, elec_reading, gas_reading, date FROM user_reading WHERE district_id="+uptownid+" AND building_id="+buildingid+" AND room_id="+roomid;
			ResultSet rsLastData = stmt4.executeQuery( sqlLastData );
						
						
			k = 0;
			while( rsLastData.next() ) 
			{
				waters[k] = rsLastData.getString( "water_reading" );
				eles[k] = rsLastData.getString( "elec_reading" );
				gass[k] = rsLastData.getString( "gas_reading" );
				dates[k] = rsLastData.getString( "date" );
				k++;
			}
						
			rsLastData.close();
			connection4.close(); 
		}
					
		catch( Exception ex )
		{
			System.out.println(ex);
			
		}
		
		titleLabel=new JLabel(uptownname+"��"+buildingid+"��¥"+roomid+"�����������ˮ���������ú������");
		inset = new Insets(5,5,5,5);
		c = new GridBagConstraints(2,1,5,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(titleLabel,c);
		panelin.add(titleLabel);
		
		y=4;
		for( int j=0;j<k;j++)
		{
			dateLabel[j]=new JLabel(dates[j]);
			c = new GridBagConstraints(2,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(dateLabel[j],c);
			panelin.add(dateLabel[j]);
			
			waterLabel[j]=new JLabel("��ˮ");
			c = new GridBagConstraints(4,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(waterLabel[j],c);
			panelin.add(waterLabel[j]);
			
			waterField[j]=new JTextField(waters[j], 7);
			waterField[j].setEditable(false);
			c = new GridBagConstraints(6,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(waterField[j],c);
			panelin.add(waterField[j]);
			
			eleLabel[j]=new JLabel("�õ�");
			c = new GridBagConstraints(8,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(eleLabel[j],c);
			panelin.add(eleLabel[j]);
			
			eleField[j]=new JTextField(eles[j], 7);
			eleField[j].setEditable(false);
			c = new GridBagConstraints(10,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(eleField[j],c);
			panelin.add(eleField[j]);
			
			gasLabel[j]=new JLabel("ú��");
			c = new GridBagConstraints(12,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(gasLabel[j],c);
			panelin.add(gasLabel[j]);
			
			gasField[j]=new JTextField(gass[j], 7);
			gasField[j].setEditable(false);
			c = new GridBagConstraints(14,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(gasField[j],c);
			panelin.add(gasField[j]);
			
			y+=4;
		}
		
		y+=4;
		
		button1=new JButton("������ѯ");
		button1.addActionListener(
			new ActionListener()
			{
				public void actionPerformed( ActionEvent event){
					HistoryData rdif = new HistoryData( 3 );
					HistoryData.this.setVisible(false);
				}
			}
			);
		c = new GridBagConstraints(7,y,2,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button1,c);
		panelin.add(button1);
		
		button2 = new JButton( "����" );
		button2.addActionListener(
			new ActionListener(){
				public void actionPerformed( ActionEvent event){
					HistoryData.this.setVisible(false);
				}
			}
			);
		c = new GridBagConstraints(10,y,2,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button2,c);
		panelin.add(button2);
		
		setSize(800,300);
		setVisible(true);
	}
	
	public HistoryData(String uptownid, String uptownname, String buildingid, String roomid, int date)
	{
		System.out.println("init 10");
		JLabel titleLabel, waterLabel, eleLabel, gasLabel;
		JTextField waterField, eleField, gasField;
		JButton button1, button2;
		//String water, ele, gas;
		
		Container panelin = getContentPane();
		gridbag=new GridBagLayout();
		panelin.setLayout(gridbag);
		//Container panelin = getContentPane();
		gridbag=new GridBagLayout();
		panelin.setLayout(gridbag);
		
		try{
			Class.forName( "com.mysql.jdbc.Driver" );
			String url4 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection4 = DriverManager.getConnection( url4 ,"swing_wuye","swing_wuye");
			Statement stmt4 = connection4.createStatement();
			String sqlLastData = "SELECT  water_reading, elec_reading, gas_reading FROM user_reading WHERE district_id="+uptownid+" AND building_id="+buildingid+" AND room_id="+roomid+" AND date="+date;
			ResultSet rsLastData = stmt4.executeQuery( sqlLastData );
						
			while( rsLastData.next() ) 
			{
				water = rsLastData.getString( "water_reading" );
				ele = rsLastData.getString( "elec_reading" );
				gas = rsLastData.getString( "gas_reading" );
			}
						
			rsLastData.close();
			connection4.close(); 
		}
					
		catch( Exception ex )
		{
			System.out.println(ex);
			
		}
		
		titleLabel=new JLabel(uptownname+"��"+buildingid+"��¥ "+roomid+"�� "+date+"ˮ���������ú������");
		inset = new Insets(5,5,5,5);
		c = new GridBagConstraints(2,1,5,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(titleLabel,c);
		panelin.add(titleLabel);
		
		waterLabel=new JLabel("��ˮ");
		c = new GridBagConstraints(2,5,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(waterLabel,c);
		panelin.add(waterLabel);
			
		waterField=new JTextField(water, 7);
		waterField.setEditable(false);
		c = new GridBagConstraints(4,5,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(waterField,c);
		panelin.add(waterField);
		
		eleLabel=new JLabel("�õ�");
		c = new GridBagConstraints(6,5,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(eleLabel,c);
		panelin.add(eleLabel);
			
		eleField=new JTextField(ele, 7);
		eleField.setEditable(false);
		c = new GridBagConstraints(8,5,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(eleField,c);
		panelin.add(eleField);
			
		gasLabel=new JLabel("ú��");
		c = new GridBagConstraints(10,5,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(gasLabel,c);
		panelin.add(gasLabel);
			
		gasField=new JTextField(gas, 7);
		gasField.setEditable(false);
		c = new GridBagConstraints(12,5,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(gasField,c);
		panelin.add(gasField);
		
		button1=new JButton("������ѯ");
		button1.addActionListener(
			new ActionListener()
			{
				public void actionPerformed( ActionEvent event){
					HistoryData rdif = new HistoryData( 3 );
					HistoryData.this.setVisible(false);
				}
			}
			);
		c = new GridBagConstraints(5,7,2,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button1,c);
		panelin.add(button1);
		
		button2 = new JButton( "����" );
		button2.addActionListener(
			new ActionListener(){
				public void actionPerformed( ActionEvent event){
					HistoryData.this.setVisible(false);
				}
			}
			);
		c = new GridBagConstraints(8,7,2,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button2,c);
		panelin.add(button2);
		
		setSize(800,300);
		setVisible(true);
	}
	
	public void uptowndata()
	{
		Container panelin = getContentPane();
		gridbag=new GridBagLayout();
		panelin.setLayout(gridbag);
		
		uptown_name=new String[100];
		uptown_id=new String[100];
		uptown_name[0]=new String("ѡ��С��");
		date=new String[4];
		date[0]=new String("ѡ������");
		
		getuptown();
		
		uptownLabel=new JLabel("ѡ��С��");
		uptownLabel.setToolTipText("�������˵���ѡ��С��" );
		inset = new Insets(5,5,5,5);
		c = new GridBagConstraints(2,1,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownLabel,c);
		panelin.add(uptownLabel);
		
		uptownbox = new JComboBox( uptown_name );
		uptownbox.setMaximumRowCount( 5 );
		System.out.println("the out");
		uptownbox.addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = uptownbox.getSelectedIndex();
					//getbuilding(uptownid[i]);
					inuptownid = new String(uptown_id[i]);
					inuptownname = new String( uptown_name[i]);
					//setVisible(true);
					HistoryData.this.setVisible(false);
					if(t==0)
					{
						HistoryData hd1= new HistoryData(1,inuptownid,inuptownname);
					}
					t++;
				}
			}
		);
		c = new GridBagConstraints(4,1,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownbox,c);
		panelin.add(uptownbox);
		
		dateLabel = new JLabel("ѡ������");
		c = new GridBagConstraints(2,4,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateLabel,c);
		panelin.add(dateLabel);
		
		datebox=new JComboBox( date );
		datebox.setMaximumRowCount( 5 );
		c = new GridBagConstraints(4,4,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(datebox,c);
		panelin.add(datebox);
		
		button3 = new JButton( "ȷ��" );
		button3.setEnabled( false );
		c = new GridBagConstraints(3,6,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button3,c);
		panelin.add(button3);
		
		button4 = new JButton( "����" );
		button4.addActionListener(
			new ActionListener(){
				public void actionPerformed( ActionEvent event){
					HistoryData.this.setVisible(false);
					//MonthDataInputFrame mdif1 = new MonthDataInputFrame();
				}
			}
			);
		c = new GridBagConstraints(5,6,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button4,c);
		panelin.add(button4);
		
		setSize(350,300);
		setVisible(true);
		
	}
	
	public void uptowndata(String uptownid, String uptownname)
	{
		Container panelin = getContentPane();
		gridbag=new GridBagLayout();
		panelin.setLayout(gridbag);
		
		inuptownid=new String(uptownid);
		inuptownname=new String(uptownname);
		uptown_name=new String[100];
		uptown_id=new String[100];
		date=new String[4];
		uptown_name[0]=new String(uptownname);
		
		getuptown();
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			String url1 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection1 = DriverManager.getConnection(url1,"swing_wuye","swing_wuye");
			Statement stmt1 = connection1.createStatement(); 
			String sqlUptown = "SELECT date FROM district_reading WHERE district_id="+inuptownid;
			ResultSet rs1 = stmt1.executeQuery(sqlUptown);
			
			System.out.println("the 00");
		
			int i= 1;
			while( rs1.next() )
			{
				date[i] = rs1.getString( "date" );
				i++;
			}
			
			date[0]=new String("ȫ��");
			//System.out.println("the 01");
			
			rs1.close();
			connection1.close();
		}
		
		catch( Exception ex ) {
			System.out.println(ex);
			date[0]=new String("û������");
			//System.exit(0);
		}
		
		uptownLabel=new JLabel("ѡ��С��");
		uptownLabel.setToolTipText("�������˵���ѡ��С��" );
		inset = new Insets(5,5,5,5);
		c = new GridBagConstraints(2,1,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownLabel,c);
		panelin.add(uptownLabel);
		
		uptownbox = new JComboBox( uptown_name );
		uptownbox.setMaximumRowCount( 5 );
		System.out.println("the out");
		uptownbox.addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = uptownbox.getSelectedIndex();
					//getbuilding(uptownid[i]);
					inuptownid = new String(uptown_id[i]);
					inuptownname = new String( uptown_name[i]);
					//setVisible(true);
					if(t==0)
					{
						HistoryData hd1= new HistoryData(1,inuptownid,inuptownname);
					}
					HistoryData.this.setVisible(false);
					t++;
				}
			}
		);
		c = new GridBagConstraints(4,1,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownbox,c);
		panelin.add(uptownbox);
		
		dateLabel = new JLabel("ѡ������");
		c = new GridBagConstraints(2,4,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateLabel,c);
		panelin.add(dateLabel);
		
		datebox=new JComboBox( date );
		datebox.setMaximumRowCount( 5 );
		datebox.addItemListener(
			new ItemListener(){
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i=datebox.getSelectedIndex();
					if(i>0) 
					{
						indate=Integer.parseInt(date[i] );
					}
					else
					{
						indate=0;
					}
				}
			}
			);
		c = new GridBagConstraints(4,4,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(datebox,c);
		panelin.add(datebox);
		
		button3 = new JButton( "ȷ��" );
		button3.setEnabled( true );
		button3.addActionListener(
			new ActionListener(){
				public void actionPerformed( ActionEvent event){
					if(indate==0){
						HistoryData hd1= new HistoryData(inuptownid,inuptownname);
					}
					else
					{
						HistoryData hd1= new HistoryData(inuptownid,inuptownname,indate);
					}
					HistoryData.this.setVisible(false);
					//MonthDataInputFrame mdif1 = new MonthDataInputFrame();
				}
			}
			);
		c = new GridBagConstraints(3,6,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button3,c);
		panelin.add(button3);
		
		button4 = new JButton( "����" );
		button4.addActionListener(
			new ActionListener(){
				public void actionPerformed( ActionEvent event){
					HistoryData.this.setVisible(false);
					//MonthDataInputFrame mdif1 = new MonthDataInputFrame();
				}
			}
			);
		c = new GridBagConstraints(5,6,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button4,c);
		panelin.add(button4);
		
		setSize(350,300);
		setVisible(true);
	}
	
	public void buildingdata()
	{
		Container panelin = getContentPane();
		gridbag=new GridBagLayout();
		panelin.setLayout(gridbag);
		uptown_id=new String[100];
		uptown_name=new String[100];
		building_id=new String[150];
		date=new String[4];
		uptown_name[0]=new String("ѡ��С��");
		building_id[0]=new String("ѡ��¥��");
		date[0]=new String("ѡ������");
		
		getuptown();
		
		uptownLabel=new JLabel("ѡ��С��");
		uptownLabel.setToolTipText("�������˵���ѡ��С��" );
		inset = new Insets(5,5,5,5);
		c = new GridBagConstraints(2,1,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownLabel,c);
		panelin.add(uptownLabel);
		
		uptownbox = new JComboBox( uptown_name );
		uptownbox.setMaximumRowCount( 5 );
		System.out.println("the out");
		uptownbox.addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = uptownbox.getSelectedIndex();
					getbuilding(uptown_id[i]);
					inuptownid = new String(uptown_id[i]);
					inuptownname = new String( uptown_name[i]);
					//setVisible(true);
					if(t==0)
					{
						HistoryData hd1= new HistoryData(2,inuptownid,inuptownname);
					}
					t++;
					HistoryData.this.setVisible(false);
				}
			}
		);
		c = new GridBagConstraints(4,1,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownbox,c);
		panelin.add(uptownbox);
		
		buildingLabel=new JLabel("ѡ��¥��");
		c = new GridBagConstraints(2,4,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(buildingLabel,c);
		panelin.add(buildingLabel);
		
		buildingbox=new JComboBox( building_id );
		buildingbox.setMaximumRowCount( 5 );
		c = new GridBagConstraints(4,4,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(buildingbox,c);
		panelin.add(buildingbox);
		
		dateLabel=new JLabel("ѡ������");
		c = new GridBagConstraints(2,6,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateLabel,c);
		panelin.add(dateLabel);
		
		datebox=new JComboBox( date );
		datebox.setMaximumRowCount( 5 );
		c = new GridBagConstraints(4,6,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(datebox,c);
		panelin.add(datebox);
		
		button3 = new JButton( "ȷ��" );
		button3.setEnabled( false );
		c = new GridBagConstraints(3,8,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button3,c);
		panelin.add(button3);
		
		button4 = new JButton( "����" );
		button4.addActionListener(
			new ActionListener(){
				public void actionPerformed( ActionEvent event){
					HistoryData.this.setVisible(false);
					//MonthDataInputFrame mdif1 = new MonthDataInputFrame();
				}
			}
			);
		c = new GridBagConstraints(5,8,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button4,c);
		panelin.add(button4);
		
		setSize(350,300);
		setVisible(true);
	}
	
	public void buildingdata(String uptownid, String uptownname)
	{
		Container panelin = getContentPane();
		gridbag=new GridBagLayout();
		panelin.setLayout(gridbag);
		uptown_id=new String[100];
		uptown_name=new String[100];
		building_id=new String[150];
		date=new String[4];
		uptown_name[0]=new String(uptownname);
		building_id[0]=new String("ѡ��¥��");
		date[0]=new String("ѡ������");
		inuptownid=new String(uptownid);
		inuptownname=new String(uptownname);
		
		getuptown();
		getbuilding(inuptownid);
		
		uptownLabel=new JLabel("ѡ��С��");
		uptownLabel.setToolTipText("�������˵���ѡ��С��" );
		inset = new Insets(5,5,5,5);
		c = new GridBagConstraints(2,1,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownLabel,c);
		panelin.add(uptownLabel);
		
		uptownbox = new JComboBox( uptown_name );
		uptownbox.setMaximumRowCount( 5 );
		System.out.println("the out");
		uptownbox.addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = uptownbox.getSelectedIndex();
					getbuilding(uptown_id[i]);
					inuptownid = new String(uptown_id[i]);
					inuptownname = new String( uptown_name[i]);
					//setVisible(true);
					if(t==0)
					{
						HistoryData hd1= new HistoryData(2,inuptownid,inuptownname);
					}
					t++;
					HistoryData.this.setVisible(false);
				}
			}
		);
		c = new GridBagConstraints(4,1,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownbox,c);
		panelin.add(uptownbox);
		
		buildingLabel=new JLabel("ѡ��¥��");
		c = new GridBagConstraints(2,4,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(buildingLabel,c);
		panelin.add(buildingLabel);
		
		buildingbox=new JComboBox( building_id );
		buildingbox.addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = buildingbox.getSelectedIndex();
					//getroom(building_id[i]);
					//setVisible(true);
					inbuilding=new String(building_id[i]);
					if(t==0)
					{
						HistoryData hd2= new HistoryData(2,inuptownid,inuptownname,inbuilding);
					}
					t++;
					HistoryData.this.setVisible(false);
				}
			}
		);
		buildingbox.setMaximumRowCount( 5 );
		c = new GridBagConstraints(4,4,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(buildingbox,c);
		panelin.add(buildingbox);
		
		dateLabel=new JLabel("ѡ������");
		c = new GridBagConstraints(2,6,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateLabel,c);
		panelin.add(dateLabel);
		
		datebox=new JComboBox( date );
		datebox.setMaximumRowCount( 5 );
		c = new GridBagConstraints(4,6,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(datebox,c);
		panelin.add(datebox);
		
		button3 = new JButton( "ȷ��" );
		button3.setEnabled( false );
		c = new GridBagConstraints(3,8,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button3,c);
		panelin.add(button3);
		
		button4 = new JButton( "����" );
		button4.addActionListener(
			new ActionListener(){
				public void actionPerformed( ActionEvent event){
					HistoryData.this.setVisible(false);
					//MonthDataInputFrame mdif1 = new MonthDataInputFrame();
				}
			}
			);
		c = new GridBagConstraints(5,8,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button4,c);
		panelin.add(button4);
		
		setSize(350,300);
		setVisible(true);
	}
	
	public void buildingdata(String uptownid,String buildingid, String uptownname)
	{
		Container panelin = getContentPane();
		gridbag=new GridBagLayout();
		panelin.setLayout(gridbag);
		uptown_id=new String[100];
		uptown_name=new String[100];
		building_id=new String[150];
		date=new String[4];
		uptown_name[0]=new String(uptownname);
		building_id[0]=new String(buildingid);
		date[0]=new String("ѡ������");
		inuptownid=new String(uptownid);
		inuptownname=new String(uptownname);
		inbuilding=new String(buildingid);
		
		getuptown();
		getbuilding(inuptownid);
		//getroom(inuptownid,inbuilding);
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			String url2 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection2 = DriverManager.getConnection(url2,"swing_wuye","swing_wuye");
			Statement stmt2 = connection2.createStatement();
			String sqlBuilding = "SELECT date FROM building_elec_reading WHERE district_id="+uptownid+" AND building_id="+buildingid;
			System.out.println("the 041");
			ResultSet rs2 = stmt2.executeQuery(sqlBuilding);
						
			int i = 1;
			while( rs2.next() )
			{
				date[i] = rs2.getString( "date" );
				i++;
			}
			date[0]=new String("ȫ��");
			//System.out.println("the 11");
			//panelin.repaint();
			rs2.close();
			connection2.close();
		}
					
		catch( Exception ex )
		{
			System.out.println( ex );
			
			date[0]=new String("û������");
			//MonthDataInputFrame.this.setVisible(false);
		}
		
		uptownLabel=new JLabel("ѡ��С��");
		uptownLabel.setToolTipText("�������˵���ѡ��С��" );
		inset = new Insets(5,5,5,5);
		c = new GridBagConstraints(2,1,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownLabel,c);
		panelin.add(uptownLabel);
		
		uptownbox = new JComboBox( uptown_name );
		uptownbox.setMaximumRowCount( 5 );
		System.out.println("the out");
		uptownbox.addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = uptownbox.getSelectedIndex();
					getbuilding(uptown_id[i]);
					inuptownid = new String(uptown_id[i]);
					inuptownname = new String( uptown_name[i]);
					//setVisible(true);
					if(t==0)
					{
						HistoryData hd1= new HistoryData(2,inuptownid,inuptownname);
					}
					t++;
					HistoryData.this.setVisible(false);
				}
			}
		);
		c = new GridBagConstraints(4,1,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownbox,c);
		panelin.add(uptownbox);
		
		buildingLabel=new JLabel("ѡ��¥��");
		c = new GridBagConstraints(2,4,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(buildingLabel,c);
		panelin.add(buildingLabel);
		
		buildingbox=new JComboBox( building_id );
		buildingbox.addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = buildingbox.getSelectedIndex();
					//getroom(building_id[i]);
					//setVisible(true);
					inbuilding=new String(building_id[i]);
					if(t==0)
					{
						HistoryData hd2= new HistoryData(2,inuptownid,inuptownname,inbuilding);
					}
					t++;
					HistoryData.this.setVisible(false);
				}
			}
		);
		buildingbox.setMaximumRowCount( 5 );
		c = new GridBagConstraints(4,4,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(buildingbox,c);
		panelin.add(buildingbox);
		
		dateLabel=new JLabel("ѡ������");
		c = new GridBagConstraints(2,6,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateLabel,c);
		panelin.add(dateLabel);
		
		datebox=new JComboBox( date );
		datebox.addItemListener(
			new ItemListener(){
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i=datebox.getSelectedIndex();
					if(i>0) 
					{
						indate=Integer.parseInt(date[i] );
					}
					else
					{
						indate=0;
					}
				}
			}
			);
		datebox.setMaximumRowCount( 5 );
		c = new GridBagConstraints(4,6,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(datebox,c);
		panelin.add(datebox);
		
		button3 = new JButton( "ȷ��" );
		button3.setEnabled( true);
			button3.addActionListener(
			new ActionListener(){
				public void actionPerformed( ActionEvent event){
					if(indate==0){
						HistoryData hd1= new HistoryData(inuptownid,inuptownname,inbuilding);
					}
					else
					{
						HistoryData hd1= new HistoryData(inuptownid,inuptownname,inbuilding,indate);
					}
					HistoryData.this.setVisible(false);
					//MonthDataInputFrame mdif1 = new MonthDataInputFrame();
				}
			}
			);
		c = new GridBagConstraints(3,8,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button3,c);
		panelin.add(button3);
		
		button4 = new JButton( "����" );
		button4.addActionListener(
			new ActionListener(){
				public void actionPerformed( ActionEvent event){
					HistoryData.this.setVisible(false);
					//MonthDataInputFrame mdif1 = new MonthDataInputFrame();
				}
			}
			);
		c = new GridBagConstraints(5,8,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button4,c);
		panelin.add(button4);
		
		setSize(350,300);
		setVisible(true);
	}
	
	public void roomdata()
	{
		Container panelin = getContentPane();
		gridbag=new GridBagLayout();
		panelin.setLayout(gridbag);
		uptown_id=new String[100];
		uptown_name=new String[100];
		building_id=new String[150];
		room_id=new String[150];
		date=new String[4];
		uptown_name[0]=new String("ѡ��С��");
		building_id[0]=new String("ѡ��¥��");
		room_id[0]=new String("ѡ�񷿺�");
		date[0]=new String("ѡ������");
		//inuptownid=new String(uptownid);
		//inuptownname=new String(uptownname);
		//inbuilding=new String(buildingid);
		//inroom=new String(roomid)
		
		getuptown();
		
		uptownLabel=new JLabel("ѡ��С��");
		uptownLabel.setToolTipText("�������˵���ѡ��С��" );
		inset = new Insets(5,5,5,5);
		c = new GridBagConstraints(2,1,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownLabel,c);
		panelin.add(uptownLabel);
		
		uptownbox = new JComboBox( uptown_name );
		uptownbox.setMaximumRowCount( 5 );
		System.out.println("the out");
		uptownbox.addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = uptownbox.getSelectedIndex();
					getbuilding(uptown_id[i]);
					inuptownid = new String(uptown_id[i]);
					inuptownname = new String( uptown_name[i]);
					//setVisible(true);
					System.out.println("t ="+t);
					if(t==0)
					{
						HistoryData hd1= new HistoryData(3,inuptownid,inuptownname);
					}
					t++;
					
					HistoryData.this.setVisible(false);
				}
			}
		);
		c = new GridBagConstraints(4,1,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownbox,c);
		panelin.add(uptownbox);
		
		buildingLabel=new JLabel("ѡ��¥��");
		c = new GridBagConstraints(2,4,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(buildingLabel,c);
		panelin.add(buildingLabel);
		
		buildingbox=new JComboBox( building_id );
		buildingbox.setMaximumRowCount( 5 );
		c = new GridBagConstraints(4,4,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(buildingbox,c);
		panelin.add(buildingbox);
		
		roomLabel=new JLabel("ѡ�񷿺�");
		c = new GridBagConstraints(2,6,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(roomLabel,c);
		panelin.add(roomLabel);
		
		roombox=new JComboBox(room_id);
		roombox.setMaximumRowCount( 5 );
		c = new GridBagConstraints(4,6,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(roombox,c);
		panelin.add(roombox);
		
		dateLabel=new JLabel("ѡ������");
		c = new GridBagConstraints(2,8,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateLabel,c);
		panelin.add(dateLabel);
		
		datebox=new JComboBox( date );
		datebox.setMaximumRowCount( 5 );
		c = new GridBagConstraints(4,8,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(datebox,c);
		panelin.add(datebox);
		
		button3 = new JButton( "ȷ��" );
		button3.setEnabled( false);
		c = new GridBagConstraints(3,10,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button3,c);
		panelin.add(button3);
		
		button4 = new JButton( "����" );
		button4.addActionListener(
			new ActionListener(){
				public void actionPerformed( ActionEvent event){
					HistoryData.this.setVisible(false);
				}
			}
			);
		c = new GridBagConstraints(5,10,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button4,c);
		panelin.add(button4);
		
		setSize(350,300);
		setVisible(true);
	}
	
	public void roomdata(String uptownid, String uptownname)
	{
		Container panelin = getContentPane();
		gridbag=new GridBagLayout();
		panelin.setLayout(gridbag);
		uptown_id=new String[100];
		uptown_name=new String[100];
		building_id=new String[150];
		room_id=new String[150];
		date=new String[4];
		uptown_name[0]=new String(uptownname);
		building_id[0]=new String("ѡ��¥��");
		room_id[0]=new String("ѡ�񷿺�");
		date[0]=new String("ѡ������");
		inuptownid=new String(uptownid);
		inuptownname=new String(uptownname);
		//inbuilding=new String(buildingid);
		//inroom=new String(roomid)
		
		getuptown();
		getbuilding(inuptownid);
		
		uptownLabel=new JLabel("ѡ��С��");
		uptownLabel.setToolTipText("�������˵���ѡ��С��" );
		inset = new Insets(5,5,5,5);
		c = new GridBagConstraints(2,1,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownLabel,c);
		panelin.add(uptownLabel);
		
		uptownbox = new JComboBox( uptown_name );
		uptownbox.setMaximumRowCount( 5 );
		System.out.println("the out");
		uptownbox.addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = uptownbox.getSelectedIndex();
					getbuilding(uptown_id[i]);
					inuptownid = new String(uptown_id[i]);
					inuptownname = new String( uptown_name[i]);
					//setVisible(true);
					if(t==0)
					{
						HistoryData hd1= new HistoryData(3,inuptownid,inuptownname);
					}
					t++;
					
					HistoryData.this.setVisible(false);
				}
			}
		);
		c = new GridBagConstraints(4,1,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownbox,c);
		panelin.add(uptownbox);
		
		buildingLabel=new JLabel("ѡ��¥��");
		c = new GridBagConstraints(2,4,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(buildingLabel,c);
		panelin.add(buildingLabel);
		
		buildingbox=new JComboBox( building_id );
		buildingbox.addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = buildingbox.getSelectedIndex();
					//getroom(building_id[i]);
					//setVisible(true);
					inbuilding=new String(building_id[i]);
					if(t==0)
					{
						HistoryData hd2= new HistoryData(3,inuptownid,inuptownname,inbuilding);
					}
					t++;
					HistoryData.this.setVisible(false);
				}
			}
		);
		buildingbox.setMaximumRowCount( 5 );
		c = new GridBagConstraints(4,4,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(buildingbox,c);
		panelin.add(buildingbox);
		
		roomLabel=new JLabel("ѡ�񷿺�");
		c = new GridBagConstraints(2,6,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(roomLabel,c);
		panelin.add(roomLabel);
		
		roombox=new JComboBox(room_id);
		roombox.setMaximumRowCount( 5 );
		c = new GridBagConstraints(4,6,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(roombox,c);
		panelin.add(roombox);
		
		dateLabel=new JLabel("ѡ������");
		c = new GridBagConstraints(2,8,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateLabel,c);
		panelin.add(dateLabel);
		
		datebox=new JComboBox( date );
		datebox.setMaximumRowCount( 5 );
		c = new GridBagConstraints(4,8,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(datebox,c);
		panelin.add(datebox);
		
		button3 = new JButton( "ȷ��" );
		button3.setEnabled( false);
		c = new GridBagConstraints(3,10,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button3,c);
		panelin.add(button3);
		
		button4 = new JButton( "����" );
		button4.addActionListener(
			new ActionListener(){
				public void actionPerformed( ActionEvent event){
					HistoryData.this.setVisible(false);
				}
			}
			);
		c = new GridBagConstraints(5,10,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button4,c);
		panelin.add(button4);
		
		setSize(350,300);
		setVisible(true);
	}
	
	public void roomdata(String uptownid, String buildingid, String uptownname)
	{
		Container panelin = getContentPane();
		gridbag=new GridBagLayout();
		panelin.setLayout(gridbag);
		uptown_id=new String[100];
		uptown_name=new String[100];
		building_id=new String[150];
		room_id=new String[150];
		date=new String[4];
		uptown_name[0]=new String(uptownname);
		building_id[0]=new String(buildingid);
		room_id[0]=new String("ѡ�񷿺�");
		date[0]=new String("ѡ������");
		inuptownid=new String(uptownid);
		inuptownname=new String(uptownname);
		inbuilding=new String(buildingid);
		//inroom=new String(roomid)
		
		getuptown();
		getbuilding(inuptownid);
		getroom(inuptownid, inbuilding);
		
		uptownLabel=new JLabel("ѡ��С��");
		uptownLabel.setToolTipText("�������˵���ѡ��С��" );
		inset = new Insets(5,5,5,5);
		c = new GridBagConstraints(2,1,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownLabel,c);
		panelin.add(uptownLabel);
		
		uptownbox = new JComboBox( uptown_name );
		uptownbox.setMaximumRowCount( 5 );
		System.out.println("the out");
		uptownbox.addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = uptownbox.getSelectedIndex();
					getbuilding(uptown_id[i]);
					inuptownid = new String(uptown_id[i]);
					inuptownname = new String( uptown_name[i]);
					//setVisible(true);
					if(t==0)
					{
						HistoryData hd1= new HistoryData(3,inuptownid,inuptownname);
					}
					t++;
					HistoryData.this.setVisible(false);
				}
			}
		);
		c = new GridBagConstraints(4,1,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownbox,c);
		panelin.add(uptownbox);
		
		buildingLabel=new JLabel("ѡ��¥��");
		c = new GridBagConstraints(2,4,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(buildingLabel,c);
		panelin.add(buildingLabel);
		
		buildingbox=new JComboBox( building_id );
		buildingbox.addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = buildingbox.getSelectedIndex();
					//getroom(building_id[i]);
					//setVisible(true);
					
					inbuilding=new String(building_id[i]);
					if(t==0)
					{
						HistoryData hd2= new HistoryData(3,inuptownid,inuptownname,inbuilding);
					}
					t++;
					HistoryData.this.setVisible(false);
				}
			}
		);
		buildingbox.setMaximumRowCount( 5 );
		c = new GridBagConstraints(4,4,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(buildingbox,c);
		panelin.add(buildingbox);
		
		roomLabel=new JLabel("ѡ�񷿺�");
		c = new GridBagConstraints(2,6,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(roomLabel,c);
		panelin.add(roomLabel);
		
		roombox=new JComboBox(room_id);
		roombox.addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = roombox.getSelectedIndex();
					//getroom(building_id[i]);
					//setVisible(true);
					inroom=new String(room_id[i]);
					System.out.println("inroom = "+inroom);
					System.out.println("i = "+i);
					if(t==0)
					{
						HistoryData hd3= new HistoryData(3,inuptownid,inuptownname,inbuilding,inroom);
					}
					t++;
					HistoryData.this.setVisible(false);
				}
			}
		);
		roombox.setMaximumRowCount( 5 );
		c = new GridBagConstraints(4,6,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(roombox,c);
		panelin.add(roombox);
		
		dateLabel=new JLabel("ѡ������");
		c = new GridBagConstraints(2,8,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateLabel,c);
		panelin.add(dateLabel);
		
		datebox=new JComboBox( date );
		datebox.setMaximumRowCount( 5 );
		c = new GridBagConstraints(4,8,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(datebox,c);
		panelin.add(datebox);
		
		button3 = new JButton( "ȷ��" );
		button3.setEnabled( false);
		c = new GridBagConstraints(3,10,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button3,c);
		panelin.add(button3);
		
		button4 = new JButton( "����" );
		button4.addActionListener(
			new ActionListener(){
				public void actionPerformed( ActionEvent event){
					HistoryData.this.setVisible(false);
				}
			}
			);
		c = new GridBagConstraints(5,10,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button4,c);
		panelin.add(button4);
		
		setSize(350,300);
		setVisible(true);
	}
	
	public void roomdata(String uptownid, String buildingid, String roomid, String uptownname)
	{
		Container panelin = getContentPane();
		gridbag=new GridBagLayout();
		panelin.setLayout(gridbag);
		uptown_id=new String[100];
		uptown_name=new String[100];
		building_id=new String[150];
		room_id=new String[150];
		date=new String[4];
		uptown_name[0]=new String(uptownname);
		building_id[0]=new String(buildingid);
		room_id[0]=new String(roomid);
		date[0]=new String("ѡ������");
		inuptownid=new String(uptownid);
		inuptownname=new String(uptownname);
		inbuilding=new String(buildingid);
		inroom=new String(roomid);
		
		System.out.println(inuptownid);
		System.out.println(inbuilding);
		System.out.println(inroom);
		
		getuptown();
		getbuilding(inuptownid);
		getroom(inuptownid,inbuilding);
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			String url2 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection2 = DriverManager.getConnection(url2,"swing_wuye","swing_wuye");
			Statement stmt2 = connection2.createStatement();
			String sqlBuilding = "SELECT date FROM user_reading WHERE district_id="+inuptownid+" AND building_id="+inbuilding+" AND room_id="+inroom;
			System.out.println("the 041");
			ResultSet rs2 = stmt2.executeQuery(sqlBuilding);
						
			int i = 1;
			while( rs2.next() )
			{
				date[i] = rs2.getString( "date" );
				i++;
			}
			date[0]=new String("ȫ��");
			//System.out.println("the 11");
			//panelin.repaint();
			rs2.close();
			connection2.close();
		}
					
		catch( Exception ex )
		{
			System.out.println( ex );
			date[0]=new String("û������");
			//MonthDataInputFrame.this.setVisible(false);
		}
		
		uptownLabel=new JLabel("ѡ��С��");
		uptownLabel.setToolTipText("�������˵���ѡ��С��" );
		inset = new Insets(5,5,5,5);
		c = new GridBagConstraints(2,1,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownLabel,c);
		panelin.add(uptownLabel);
		
		uptownbox = new JComboBox( uptown_name );
		uptownbox.setMaximumRowCount( 5 );
		System.out.println("the out");
		uptownbox.addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = uptownbox.getSelectedIndex();
					getbuilding(uptown_id[i]);
					inuptownid = new String(uptown_id[i]);
					inuptownname = new String( uptown_name[i]);
					//setVisible(true);
					if(t==0)
					{
						HistoryData hd1= new HistoryData(3,inuptownid,inuptownname);
					}
					t++;
					HistoryData.this.setVisible(false);
				}
			}
		);
		c = new GridBagConstraints(4,1,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownbox,c);
		panelin.add(uptownbox);
		
		buildingLabel=new JLabel("ѡ��¥��");
		c = new GridBagConstraints(2,4,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(buildingLabel,c);
		panelin.add(buildingLabel);
		
		buildingbox=new JComboBox( building_id );
		buildingbox.addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = buildingbox.getSelectedIndex();
					//getroom(building_id[i]);
					//setVisible(true);
					inbuilding=new String(building_id[i]);
					if(t==0)
					{
						HistoryData hd2= new HistoryData(3,inuptownid,inuptownname,inbuilding);
					}
					t++;
					HistoryData.this.setVisible(false);
				}
			}
		);
		buildingbox.setMaximumRowCount( 5 );
		c = new GridBagConstraints(4,4,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(buildingbox,c);
		panelin.add(buildingbox);
		
		roomLabel=new JLabel("ѡ�񷿺�");
		c = new GridBagConstraints(2,6,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(roomLabel,c);
		panelin.add(roomLabel);
		
		roombox=new JComboBox(room_id);
		roombox.addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = buildingbox.getSelectedIndex();
					//getroom(building_id[i]);
					//setVisible(true);
					inroom=new String(room_id[i]);
					System.out.println("inroom = "+inroom);
					if(t==0)
					{
						HistoryData hd3= new HistoryData(3,inuptownid,inuptownname,inbuilding,inroom);
					}
					t++;
					HistoryData.this.setVisible(false);
				}
			}
		);
		roombox.setMaximumRowCount( 5 );
		c = new GridBagConstraints(4,6,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(roombox,c);
		panelin.add(roombox);
		
		dateLabel=new JLabel("ѡ������");
		c = new GridBagConstraints(2,8,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateLabel,c);
		panelin.add(dateLabel);
		
		datebox=new JComboBox( date );
		datebox.addItemListener(
			new ItemListener(){
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i=datebox.getSelectedIndex();
					if(i>0) 
					{
						indate=Integer.parseInt(date[i] );
					}
					else
					{
						indate=0;
					}
				}
			}
			);
		datebox.setMaximumRowCount( 5 );
		c = new GridBagConstraints(4,8,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(datebox,c);
		panelin.add(datebox);
		
		button3 = new JButton( "ȷ��" );
		button3.setEnabled( true);
			button3.addActionListener(
			new ActionListener(){
				public void actionPerformed( ActionEvent event){
					if(indate==0){
						HistoryData hd1= new HistoryData(inuptownid,inuptownname,inbuilding,inroom);
					}
					else
					{
						HistoryData hd1= new HistoryData(inuptownid,inuptownname,inbuilding,inroom,indate);
					}
					HistoryData.this.setVisible(false);
				}
			}
			);
		c = new GridBagConstraints(3,10,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button3,c);
		panelin.add(button3);
		
		button4 = new JButton( "����" );
		button4.addActionListener(
			new ActionListener(){
				public void actionPerformed( ActionEvent event){
					HistoryData.this.setVisible(false);
				}
			}
			);
		c = new GridBagConstraints(5,10,1,2,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button4,c);
		panelin.add(button4);
		
		setSize(350,300);
		setVisible(true);
	}
	
	public void getuptown()//��ȡС����Ϣ
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			String url1 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection1 = DriverManager.getConnection(url1,"swing_wuye","swing_wuye");
			Statement stmt1 = connection1.createStatement(); 
			String sqlUptown = "SELECT district_id,district_name FROM district_info ORDER BY district_id";
			ResultSet rs1 = stmt1.executeQuery(sqlUptown);
			
			System.out.println("the 00");
		
			int i= 1;
			while( rs1.next() )
			{
				uptown_id[i] = rs1.getString( "district_id" );
				uptown_name[i] = rs1.getString( "district_name" );
				i++;
			}
			
			//System.out.println("the 01");
			
			rs1.close();
			connection1.close();
		}
		
		catch( Exception ex ) {
			System.out.println(ex);
			HistoryData.this.setVisible(false);
		}//���ȡС����Ϣ
	}
	
	public void getbuilding(String uptown)//��ȡС���ڵ�¥����Ϣ
	{
		
		System.out.println("the 04");
		try{
			Class.forName("com.mysql.jdbc.Driver");
			String url2 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection2 = DriverManager.getConnection(url2,"swing_wuye","swing_wuye");
			Statement stmt2 = connection2.createStatement();
			String sqlBuilding = "SELECT building_id FROM building_info WHERE district_id="+uptown+" ORDER BY building_id";
			System.out.println("the 041");
			ResultSet rs2 = stmt2.executeQuery(sqlBuilding);
						
			int i = 1;
			while( rs2.next() )
			{
				building_id[i] = rs2.getString( "building_id" );
				i++;
			}
			//System.out.println("the 11");
			//panelin.repaint();
			rs2.close();
			connection2.close();
		}
					
		catch( Exception ex )
		{
			System.out.println( ex );
			//MonthDataInputFrame.this.setVisible(false);
		}
	}
	
	public void getroom( String uptown,String building)//��ȡ¥���з�����Ϣ
	{
		System.out.println("getroom begin");
		try{
			Class.forName( "com.mysql.jdbc.Driver" );
			String url3 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection3 = DriverManager.getConnection( url3 ,"swing_wuye","swing_wuye");
			Statement stmt3 = connection3.createStatement();
			String sqlRoom = "SELECT room_id FROM room_info WHERE district_id="+uptown+" AND building_id="+building+" ORDER BY room_id";
			ResultSet rs3 = stmt3.executeQuery( sqlRoom );
						
			int i=1;
			while( rs3.next() )
			{
				room_id[i] = rs3.getString( "room_id" );
				i++;
			}
						
			//roomcount = i;
			rs3.close();
			connection3.close();
		}
					
		catch( Exception ex )
		{
			System.out.println( ex );
			
		}
		System.out.println("getroom out");
	}
	
	public static void main(String args[])
	{
		HistoryData ap = new HistoryData(3);
		ap.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}