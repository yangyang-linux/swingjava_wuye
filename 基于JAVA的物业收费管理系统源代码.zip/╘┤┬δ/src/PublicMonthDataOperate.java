import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.*;
import javax.swing.event.*;

public class PublicMonthDataOperate
{
	private String uptownid, buildingid[], uptownwater, uptownele, uptownsecwater, last_buildingid[];
	private int water,ele,sec,buildinglift[],buildinglight[];
	private int buildingcount;
	private String message1, message2;
	private String delsql, sqlinsert[], uptowninsert, delsql2;
	private int indate, lastdate, deldate;

	private int lastuptownerror, deluptownerror, lastbuildingerror, delbuildingerror;
	private int last_tot_water, last_tot_ele, last_sec_supply, last_lift_ele[], last_lighting[];
	private String errorbuilding[], erroruptown;
	private int errortype;
	
	public PublicMonthDataOperate( String uptown, String building[],  String uptownwater,String  uptownele, String uptownsecwater, String  buildingele1[], String buildingele2[], String date, int count)
	{
		System.out.println("begining");
		uptownid = new String(uptown);
		System.out.println("uptownid ="+uptownid);
		buildingcount = count;
		System.out.println("buildingcount ="+buildingcount);
		buildingid = new String[buildingcount];
		System.out.println("buildingid init");
		water = Integer.parseInt(uptownwater);
		System.out.println("water="+water);
		ele = Integer.parseInt(uptownele);
		System.out.println("ele="+ele);
		sec = Integer.parseInt(uptownsecwater);
		System.out.println("sec="+sec);
		buildinglift= new int[buildingcount];
		buildinglight = new int[buildingcount];
		errorbuilding = new String[buildingcount];
		
		System.out.println("public operate begin");
		
		for(int j=0;j<buildingcount;j++)
		{
			buildinglift[j]=Integer.parseInt(buildingele1[j]);
			buildinglight[j]=Integer.parseInt(buildingele2[j]);
			buildingid[j] = new String(building[j]);
		}
		
		System.out.println(buildinglift[0]);
		
		indate = Integer.parseInt(date );
		if( indate%100==1 )
		{
			lastdate=indate-100+11;
			deldate=indate-100+9;
		}
		else
		{
			if(indate%100>3)
			{
				lastdate=indate-1;
				deldate=indate-3;
			}
			else
			{
				lastdate=indate-1;
				deldate=indate-100+9;
			}
		}
		System.out.println(indate);
		System.out.println(lastdate);
		System.out.println(deldate);
		
		System.out.println("init end");
		
		getlastuptown( uptownid, lastdate);
		getlastbuilding( uptownid, lastdate);
		getdeluptown( uptownid, deldate);
		getdelbuilding( uptownid, deldate);
		
		System.out.println(lastuptownerror);
		System.out.println(deluptownerror);
		
		if(lastuptownerror==0&&deluptownerror==0)
		{
			insertdata(uptownid,buildingid,water,ele,sec,buildinglift,buildinglight,indate);
		}
		if(lastuptownerror>0&&deluptownerror==0)
		{
			errortype=comparedata();
			
			if(errortype==0)
			{
				insertdata(uptownid,buildingid,water,ele,sec,buildinglift,buildinglight,indate);				
			}
			if(errortype==2)
			{
				int m=0;
				
				message1 = "���·���������ݿ����д�: ";
				
				if(erroruptown!=null)
				{
					message1+=erroruptown+",";
				}
				
				for(int k=0;k<buildingcount;k++)
				{
					if(errorbuilding[k]!=null)
					{
						message1+=errorbuilding[k]+",";
					}
				}
				
				message2=message1+"���鲢���������Ǽ������������";
				int messagetype = JOptionPane.INFORMATION_MESSAGE;
				int optiontype = JOptionPane.YES_NO_OPTION;
				String title = new String( "����");
				int result = JOptionPane.showConfirmDialog(null,message2,title,optiontype,messagetype);
				if( result == JOptionPane.YES_OPTION)
				{
					insertdata(uptownid,buildingid,water,ele,sec,buildinglift,buildinglight,indate);
					//deletedata( iduptown, indate );
				}
			}
			if(errortype==3)
			{
				int m=0;
				
				message1 = "��������������д�: ";
				
				if(erroruptown!=null)
				{
					message1+=erroruptown+",";
				}
				
				for(int k=0;k<buildingcount;k++)
				{
					if(errorbuilding[k]!=null)
					{
						message1+=errorbuilding[k]+",";
					}
				}
				
				message2=message1+"���鲢������";
				JOptionPane.showMessageDialog(null,message2,"Error",JOptionPane.PLAIN_MESSAGE);
			}
		}
		if(lastuptownerror>0&&deluptownerror>0)
		{
			errortype=comparedata();
			
			if(errortype==0)
			{
				insertdata(uptownid,buildingid,water,ele,sec,buildinglift,buildinglight,indate);
				deletedata( uptownid, deldate );				
			}
			if(errortype==2)
			{
				int m=0;
				
				message1 = "���·���������ݿ����д�: ";
				
				if(erroruptown!=null)
				{
					message1+=erroruptown+",";
				}
				
				for(int k=0;k<buildingcount;k++)
				{
					if(errorbuilding[k]!=null)
					{
						message1+=errorbuilding[k]+",";
					}
				}
				
				message2=message1+"���鲢���������Ǽ������������";
				int messagetype = JOptionPane.INFORMATION_MESSAGE;
				int optiontype = JOptionPane.YES_NO_OPTION;
				String title = new String( "����");
				int result = JOptionPane.showConfirmDialog(null,message2,title,optiontype,messagetype);
				if( result == JOptionPane.YES_OPTION)
				{
					insertdata(uptownid,buildingid,water,ele,sec,buildinglift,buildinglight,indate);
					deletedata( uptownid, deldate );
				}
			}
			if(errortype==3)
			{
				int m=0;
				
				message1 = "��������������д���";
				System.out.println("step 1");
				if(erroruptown!=null)
				{
					message1+=erroruptown;
				}
				System.out.println("step 2");
				for(int k=0;k<buildingcount;k++)
				{
					if(errorbuilding[k]!=null)
					{
						message1+=errorbuilding[k]+",";
					}
				}
				System.out.println("step 3");
				message2=message1+"���鲢������";
				System.out.println("step 4");
				JOptionPane.showMessageDialog(null,message2,"Error",JOptionPane.PLAIN_MESSAGE);
			}
		}
		
	}
	
	public void getlastuptown( String uptown, int date)
	{
		System.out.println("get last uptown begin");
		lastuptownerror = 0;
		try{
			Class.forName( "com.mysql.jdbc.Driver" );
			String url4 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection4 = DriverManager.getConnection( url4 ,"swing_wuye","swing_wuye");
			Statement stmt4 = connection4.createStatement();
			String sqlLastData = "SELECT tot_water_reading, tot_elec_reading, sec_supply_reading FROM district_reading WHERE district_id="+uptown+" AND date="+date;
			ResultSet rsLastData = stmt4.executeQuery( sqlLastData );
			
			while(rsLastData.next())
			{
				last_tot_water = rsLastData.getInt( "tot_water_reading");
				last_tot_ele = rsLastData.getInt( "tot_elec_reading");
				last_sec_supply = rsLastData.getInt("sec_supply_reading");
				lastuptownerror++;
			}
			
			rsLastData.close();
			connection4.close();
			System.out.println(lastuptownerror);
		}
		
		catch( Exception ex )
		{
			System.out.println(ex);
			
		}
	}
	
	public void getlastbuilding( String uptown,  int date)
	{
		System.out.println("get last building begin");
		lastbuildingerror = 0;
		
		try{
			Class.forName( "com.mysql.jdbc.Driver" );
			String url4 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection4 = DriverManager.getConnection( url4,"swing_wuye","swing_wuye" );
			Statement stmt4 = connection4.createStatement();
			String sqlLastData = "SELECT lift_ele_reading, lighting_reading ,building_id FROM building_elec_reading WHERE district_id="+uptown+" AND date="+date;
			ResultSet rsLastData = stmt4.executeQuery( sqlLastData );
			
			last_lift_ele = new int[buildingcount];
			last_lighting = new int[buildingcount];
			last_buildingid = new String[buildingcount];
			
			int i=0;
			while(rsLastData.next())
			{
				last_lift_ele[i] = rsLastData.getInt( "lift_ele_reading");
				last_lighting[i] = rsLastData.getInt( "lighting_reading");
				last_buildingid[i] = rsLastData.getString("building_id");
				i++;
				lastbuildingerror++;
			}
			
			rsLastData.close();
			connection4.close(); 
		}
		
		catch( Exception ex )
		{
			System.out.println(ex);
			
		}
	}
	
	public void getdeluptown( String uptown, int date)
	{
		System.out.println("get delete uptown begin");
		
		deluptownerror=0;
		
		try{
			Class.forName( "com.mysql.jdbc.Driver" );
			String url4 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection4 = DriverManager.getConnection( url4 ,"swing_wuye","swing_wuye");
			Statement stmt4 = connection4.createStatement();
			String sqlLastData = "SELECT tot_water_reading, tot_elec_reading, sec_supply_reading FROM district_reading WHERE district_id="+uptown+" AND date="+date;
			ResultSet rsLastData = stmt4.executeQuery( sqlLastData );
			
			while(rsLastData.next())
			{
				deluptownerror++;
			}
			
			rsLastData.close();
			connection4.close(); 
			System.out.println(deluptownerror);
		}
		
		catch( Exception ex )
		{
			System.out.println(ex);
			
		}
	}
	
	public void getdelbuilding( String uptown, int date )
	{
		System.out.println("get delete building begin");
		delbuildingerror = 0;
		
		try{
			Class.forName( "com.mysql.jdbc.Driver" );
			String url4 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection4 = DriverManager.getConnection( url4 ,"swing_wuye","swing_wuye");
			Statement stmt4 = connection4.createStatement();
			String sqlLastData = "SELECT lift_ele_reading, lighting_reading ,building_id FROM building_elec_reading WHERE district_id="+uptown+" AND date="+date;
			ResultSet rsLastData = stmt4.executeQuery( sqlLastData );
			
			while(rsLastData.next())
			{
				delbuildingerror++;
			}
			
			rsLastData.close();
			connection4.close(); 
		}
		
		catch( Exception ex )
		{
			System.out.println(ex);
			
		}
	}
	
	public void insertdata(String uptown, String building[], int totwater, int totele, int totsec, int buildingele1[], int buildingele2[], int date)
	{
		System.out.println("insert begin");
		try{
			Class.forName("com.mysql.jdbc.Driver");
				String url6 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
				Connection connection6 = DriverManager.getConnection(url6,"swing_wuye","swing_wuye");
				Statement stmt6 = connection6.createStatement();
				uptowninsert = "INSERT INTO district_reading VALUES ( "+uptown+", "+date+", "+totwater+", "+totele+", "+totsec+")";
				stmt6.execute( uptowninsert );
				sqlinsert = new String[buildingcount];
				for( int i =0 ; i<buildingcount ; i++){
					sqlinsert[i] = "INSERT INTO building_elec_reading values ( "+uptown+", "+building[i]+", "+date+", "+buildingele1[i]+", "+buildingele2[i]+")";
					// (district_id, building_id, room_id, date, water_reading, elec_reading, gas_reading)
					System.out.println(sqlinsert[i]);
					stmt6.execute( sqlinsert[i]);
				}
				connection6.close();
		}
		
		catch( Exception ex )
		{
			System.out.println( ex );
			//System.exit(0);
		}
	}
	
	public void deletedata(String uptown, int date)
	{
		System.out.println("delete begin");
		try{
			Class.forName("com.mysql.jdbc.Driver");
			String url7 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection7 = DriverManager.getConnection(url7,"swing_wuye","swing_wuye");
			Statement stmt7 = connection7.createStatement();
			delsql = "DELETE FROM district_reading WHERE district_id="+uptown+" AND date="+date;
			delsql2 = "DELETE FROM building_elec_reading WHERE district_id="+uptown+" AND date="+date;
			stmt7.execute( delsql);
			stmt7.execute( delsql2);
			connection7.close();
		}
		
		catch( Exception ex )
		{
			System.out.println( ex );
			//System.exit(0);
		}
	}
	
	public int comparedata()
	{
		System.out.println("compare begin");
		int error = 0;
		if(water>last_tot_water+5000)
		{
			if(error!=3) error=2;
			erroruptown=new String("С������,");
		}
		if(ele>last_tot_ele+10000)
		{
			if(error!=3) error=2;
			erroruptown=new String("С������,");
		}
		if(sec>last_sec_supply+5000)
		{
			if(error!=3) error=2;
			erroruptown=new String("С������,");
		}
		if(water<last_tot_water)
		{
			error=3;
			erroruptown=new String("С������,");
		}
		if(ele<last_tot_ele)
		{
			error=3;
			erroruptown=new String("С������,");
		}
		if(sec<last_sec_supply)
		{
			error=3;
			erroruptown=new String("С������,");
		}
		for(int i=0;i<buildingcount; i++)
		{
			if(buildinglift[i]>last_lift_ele[i]+500)
			{
				if(error!=3) error=2;
				errorbuilding[i] = new String(buildingid[i]);
			}
			if(buildinglight[i]>last_lighting[i]+500)
			{
				if(error!=3) error=2;
				errorbuilding[i] = new String(buildingid[i]);
			}
			if(buildinglift[i]<last_lift_ele[i])
			{
				error=3;
				errorbuilding[i] = new String(buildingid[i]);
			}
			if(buildinglight[i]<last_lighting[i])
			{
				error=3;
				errorbuilding[i] = new String(buildingid[i]);
			}
		}
		
		return(error);
	}
}