import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;


public class InterfaceStyle extends JFrame
{
	
	private JLabel label1,label2,label3,label4,label5,pictureLabel;
	private JList l1,l2,l3,l4,l5;
	String []data1={"�û���Ϣ","�����û�"};
	String []data2={"��ҵ������Ϣ","�շѵ���"};
	String []data3={"ҵ�����/ˮ��/ú��������¼��","�������/ˮ������¼��"};
	String []data4={"����վݱ���","ˮ���վݱ���","ú�����վݱ���","ҵ���շѱ���","����ҵ�շѱ���"};
	String []data5={"��ҵ����ѯ","���·ݲ�ѯ","����;��ѯ"};
	
	private String sql;
	private PreparedStatement statement;
	public JPanel panelRight;

	private static JMenu powerMenu;
	private static JMenu enterMenu;
	
	static String curtentuser = "";
	
	
	
	public static String getCurtentuser() {
		return curtentuser;
	}



	public static void setCurtentuser(String curtentuser) {
		InterfaceStyle.curtentuser = curtentuser;
	}



	public InterfaceStyle()
	{
		super("��ҵС���շѹ���ϵͳV1.0");
		
		Container con=getContentPane();
		
		/*-------------------------------------------------------------------
		 �������ò˵������ֳ� ���˵����ֱ�Ϊ��ϵͳ��Ȩ�޹�������ҵ��Ϣά�硢
		 ��ҵ�շ�¼�롢�����������ʷ��¼��ѯ��
		 **/
		
		//����ϵͳ�˵��Լ����µ��Ӳ˵�
		
		
		JMenu systemMenu=new JMenu("ϵͳ(S)");
		systemMenu.setMnemonic('S');//���ÿ�ݼ�Alt+S		
		JMenuItem loadItem=new JMenuItem("��½(L)");
		loadItem.setMnemonic('L');
		loadItem.addActionListener( new LoadHandler() );
		systemMenu.add(loadItem);//��½	
		JMenuItem exitItem=new JMenuItem("�˳�(X)");
		exitItem.setMnemonic('X');
		exitItem.addActionListener(
			new ActionListener()
			{
				public void actionPerformed(ActionEvent event)
				{
					System.exit(0);
				}
			}
		);
		systemMenu.add(exitItem);//�˳�		
		
		JMenuBar bar=new JMenuBar();
		setJMenuBar(bar);
		bar.add(systemMenu); //��systemmenu�ӵ��˵�����
		
		//����Ȩ�޹����˵�
		powerMenu = new JMenu("Ȩ�޹���(M)");
		powerMenu.setMnemonic('M');
		JMenuItem userItem = new JMenuItem("�û���Ϣ");
		userItem.addActionListener( new UserHandler() );
		powerMenu.add(userItem);
		JMenuItem insertUser=new JMenuItem("�����û�");
//		powerMenu.add(insertUser);
		bar.add(powerMenu);
		
		
		//������ҵ��Ϣά���˵�
		JMenu infMenu=new JMenu("��ҵ������Ϣ(I)");
		infMenu.setMnemonic('I');
		JMenu realInfMenu = new JMenu("��ҵ��Ϣά��");	
		JMenuItem placeItem=new JMenuItem("С����Ϣά��");
		placeItem.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event){
				XiaoQuinfo xq = new XiaoQuinfo();
			}
		}
		);
		realInfMenu.add(placeItem);
		
		JMenuItem buildingItem=new JMenuItem("¥����Ϣά��");
		buildingItem.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event){
				LouYuinfo ly = new LouYuinfo();
			}
		}
		);	
		realInfMenu.add(buildingItem);
		
		JMenuItem hostItem=new JMenuItem("ҵ��/������Ϣά��");
		hostItem.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event){
				UserInfo ui = new UserInfo();
			}
		}
		);
		realInfMenu.add(hostItem);
	    
	    infMenu.add(realInfMenu);
	    JMenu perPrice=new JMenu ("�շѵ���");
		JMenuItem enterPerPrice=new JMenuItem("�޸��շѵ���");
		enterPerPrice.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event){
				PriceChange cp1 = new PriceChange();
			}
		}
		);
		JMenuItem printPerPrice=new JMenuItem("��ʾ�շѵ���");
		printPerPrice.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event){
				Shoufei sf1 = new Shoufei();
			}
		}	
		);
		perPrice.add(enterPerPrice);
		perPrice.add(printPerPrice);
		infMenu.add(perPrice);
		bar.add(infMenu);
		
		//������ҵ�շ�¼��˵�
		enterMenu=new JMenu("��ҵ�շ�¼��(E)");
		enterMenu.setMnemonic('E');
		JMenuItem b1=new JMenuItem("ҵ�����/ˮ��/ú��������¼��");
		b1.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event){
				MonthDataInputFrame ap = new MonthDataInputFrame(1);
				//ap.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			}
		}
		);
		
		JMenuItem b2=new JMenuItem("�������/ˮ������¼��");
		b2.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event){
				PublicDataInputFrame ap = new PublicDataInputFrame(2);
				//ap.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			}
		}
		);
		enterMenu.add(b1);
		enterMenu.add(b2);
		bar.add(enterMenu);
		

		//���ñ�������˵�
		
		JMenu printMenu=new JMenu("�������(P)");
		printMenu.setMnemonic('P');
		JMenuItem a1=new JMenuItem("����շѱ���");
		a1.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event){
				MonthDataInputFrame ap = new MonthDataInputFrame(2);
				//ap.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			}
		}
		);
		
		JMenuItem a2=new JMenuItem("ˮ���շѱ���");
		a2.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event){
				MonthDataInputFrame ap = new MonthDataInputFrame(3);
				//ap.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			}
		}
		);
		
		JMenuItem a3=new JMenuItem("ú�����շѱ���");
		a3.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event){
				MonthDataInputFrame ap = new MonthDataInputFrame(4);
				//ap.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			}
		}
		);
		
		JMenuItem a4=new JMenuItem("�û��շѱ���");
		JMenuItem a5=new JMenuItem("����ҵ�շѱ���");
		printMenu.add(a1);
		printMenu.add(a2);
		printMenu.add(a3);
		printMenu.add(a4);
		printMenu.add(a5);	
		bar.add(printMenu);
		
		
		//������ʷ��¼��ѯ�˵�
		JMenu searchMenu=new JMenu("��ʷ��¼��ѯ(Q)");
		searchMenu.setMnemonic('Q');
		JMenuItem d1=new JMenuItem("��ҵ����ѯ");
		d1.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event){
				HistoryData hd3 = new HistoryData(3);
				//ap.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			}
		}
		);
		JMenuItem d3=new JMenuItem("��С����ѯ");
		d3.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event){
				HistoryData hd1 = new HistoryData(1);
				//ap.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			}
		}
		);
		JMenuItem d4=new JMenuItem("��¥���ѯ");
		d4.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event){
				HistoryData hd2 = new HistoryData(2);
				//ap.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			}
		}
		);
		JMenuItem d2=new JMenuItem("���·ݲ�ѯ");
		
		d2.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event){
				DateHistorySearch dhs = new DateHistorySearch();
				//ap.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			}
		}
		);
		//JMenuItem d3=new JMenuItem("����;��ѯ");
		searchMenu.add(d1);
		searchMenu.add(d3);
		searchMenu.add(d4);
		searchMenu.add(d2);
		//searchMenu.add(d3);		
		bar.add(searchMenu);
		
		
		//���ð����˵�
		JMenu helpMenu=new JMenu("����(H)");
		helpMenu.setMnemonic('H');	
		JMenuItem aboutItem=new JMenuItem("����..(A)");
		aboutItem.addActionListener(
			new ActionListener(){
				public void actionPerformed(ActionEvent event)
				{
					JOptionPane.showMessageDialog(InterfaceStyle.this,
					"��ҵС���շѹ���ϵͳV1.0\n"+
					 "--Configuration: JDK version 1.5.0 <Default>--","����",
					 JOptionPane.PLAIN_MESSAGE);
				}
			}
		);
		helpMenu.add(aboutItem);
		JMenuItem documentItem=new JMenuItem("�����ĵ�");
		helpMenu.add(documentItem);
		JMenuItem emailItem=new JMenuItem("�ʼ���ϵ����");
		helpMenu.add(emailItem);
		bar.add(helpMenu);
		
		//��������
		JPanel panel1=new JPanel();
		panel1.setOpaque(true);
		panel1.setBackground(Color.LIGHT_GRAY);
		
		JPanel panel2=new JPanel();
		panel2.setOpaque(true);
		panel2.setBackground(Color.LIGHT_GRAY);
		
		JPanel panel3=new JPanel();
		panel3.setOpaque(true);
		panel3.setBackground(Color.LIGHT_GRAY);
		
		JPanel panel4=new JPanel();
		panel4.setOpaque(true);
		panel4.setBackground(Color.LIGHT_GRAY);
		
		JPanel panel5=new JPanel();
		panel5.setOpaque(true);
		panel5.setBackground(Color.LIGHT_GRAY);
		
		panelRight=new JPanel();
		panelRight.setOpaque(true);
		panelRight.setBackground(Color.LIGHT_GRAY);
		
		JSplitPane sp1 = new JSplitPane(JSplitPane.VERTICAL_SPLIT,panel1,panel2);
        sp1.setDividerLocation(100);
        sp1.setOneTouchExpandable(true);
        
        JSplitPane sp2 = new JSplitPane(JSplitPane.VERTICAL_SPLIT,sp1,panel3);
        sp2.setDividerLocation(200);
        sp2.setOneTouchExpandable(true);
        
        JSplitPane sp3 = new JSplitPane(JSplitPane.VERTICAL_SPLIT,sp2,panel4);
        sp3.setDividerLocation(300);
        sp3.setOneTouchExpandable(true);
        
        JSplitPane sp4 = new JSplitPane(JSplitPane.VERTICAL_SPLIT,sp3,panel5);
        sp4.setDividerLocation(430);
        sp4.setOneTouchExpandable(true);
        
//        JSplitPane sp = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,sp4,panelRight);
		
//        sp.setOneTouchExpandable(true);
//        sp.setDividerLocation(200);
//        
//        con.add(sp);
//		
//		panel1.setLayout(new BoxLayout(panel1,BoxLayout.Y_AXIS));
//		label1=new JLabel("Ȩ�޹���");
//		panel1.add(label1);
//		
//		l1=new JList(data1);
//		l1.setVisibleRowCount(2);
//		l1.setBackground(Color.LIGHT_GRAY);
//		l1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
//		panel1.add(l1);
//		
//		panel2.setLayout(new BoxLayout(panel2,BoxLayout.Y_AXIS));
//		label2=new JLabel("��ҵ��Ϣά��");
//		panel2.add(label2);
//		l2=new JList(data2);
//		l2.setVisibleRowCount(2);
//		l2.setBackground(Color.LIGHT_GRAY);
//		l2.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
//		panel2.add(l2);
//		
//		panel3.setLayout(new BoxLayout(panel3,BoxLayout.Y_AXIS));
//		label3=new JLabel("��ҵ�շ�¼��");
//		panel3.add(label3);
//		l3=new JList(data3);
//		l3.setVisibleRowCount(2);
//		l3.setBackground(Color.LIGHT_GRAY);
//		l3.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
//		panel3.add(l3);
//		
//		panel4.setLayout(new BoxLayout(panel4,BoxLayout.Y_AXIS));
//		label4=new JLabel("�������");
//		panel4.add(label4);
//		l4=new JList(data4);
//		l4.setVisibleRowCount(4);
//		l4.setBackground(Color.LIGHT_GRAY);
//		l4.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
//		panel4.add(l4);
//		
//		panel5.setLayout(new BoxLayout(panel5,BoxLayout.Y_AXIS));
//		label5=new JLabel("��ʷ��¼��ѯ");
//		panel5.add(label5);
//		l5=new JList(data5);
//		l5.setVisibleRowCount(2);
//		l5.setBackground(Color.LIGHT_GRAY);
//		l5.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
//		panel5.add(l5);
//
//		
//		//ͼƬ
//		Icon p1= new ImageIcon("img/bgpic.jpg");
//		pictureLabel=new JLabel("\t\t��Ȩ����\t  \251  2018");
//		pictureLabel.setIcon(p1);
//		pictureLabel.setHorizontalTextPosition(SwingConstants.CENTER);
//		pictureLabel.setVerticalTextPosition(SwingConstants.BOTTOM);
//		panelRight.add(pictureLabel);
		

	}	
	
		

	public static void mainFrame(String userName,int purview)
	{		
		InterfaceStyle jf = new InterfaceStyle();
		jf.setSize(800,600);
		jf.setVisible(true);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
		//��InterfaceStyle�������ӵ�JFrame���������
		System.out.println(purview);
		if(purview==0){
			powerMenu.setEnabled(false);
			enterMenu.setEnabled(false);
		}
		if(purview==1)
			powerMenu.setEnabled(false);
		
	}
	
	private class LoadHandler implements ActionListener
	{
		public void actionPerformed(ActionEvent event)
		{
			Login.changeUser();
			InterfaceStyle.this.setVisible(false);
		}
	}
	
	private class UserHandler implements ActionListener
	{
		public void actionPerformed(ActionEvent event)
		{
			JOptionPane.showConfirmDialog(null, "��ǰ�û���Ϣ:"+curtentuser, "�û���Ϣ", JOptionPane.CLOSED_OPTION);  			
		}		
	}
} 