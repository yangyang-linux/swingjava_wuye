import java.util.*;

public class GetSystime
{
	public static int getSystime()
	{
		Calendar tt = Calendar.getInstance();
		Date time = tt.getTime();
		int year = time.getYear()+1900;
		int month = time.getMonth()+1;
		return year*100+month;
	}
}