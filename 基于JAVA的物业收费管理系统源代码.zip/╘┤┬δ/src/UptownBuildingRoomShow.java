import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.*;
import javax.swing.event.*;

public  class UptownBuildingRoomShow extends JFrame
{
	private String room[], water[], ele[], gas[];
	private JLabel buildinglabel[], roomlabel[], waterlabel[], elelabel[], gaslabel[];
	private JTextField waterfield[], elefield[], gasfield[];
	private int count,y;
	private String indate, inuptownid, inuptownname, inbuilding;
	private GridBagConstraints c;
	private Insets inset;
	private GridBagLayout gridbag;
	
	public UptownBuildingRoomShow(String uptownid, String uptownname, String building, String date)
	{
		super(uptownname+"��"+building+"¥"+"��"+date+"����ҵ���ļ�¼");
		System.out.println("uptown building room show begin");
		Container panelin = getContentPane();
		gridbag=new GridBagLayout();
		panelin.setLayout(gridbag);
		inset = new Insets(5,5,5,5);
		indate=new String(date);
		inuptownid=new String(uptownid);
		inuptownname=new String(uptownname);
		inbuilding=new String(building);
		
		getdata(indate,inuptownid,inbuilding);
		waterlabel=new JLabel[count];
		elelabel=new JLabel[count];
		gaslabel=new JLabel[count];
		roomlabel=new JLabel[count];
		waterfield=new JTextField[count];
		elefield=new JTextField[count];
		gasfield=new JTextField[count];
		
		System.out.println("init end");
		
		y=2;
		for(int i=0;i<count;i++)
		{
			roomlabel[i]=new JLabel(room[i]);
			c = new GridBagConstraints(2,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(roomlabel[i],c);
			panelin.add(roomlabel[i]);
			
			waterlabel[i]=new JLabel("ˮ������");
			c = new GridBagConstraints(4,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(waterlabel[i],c);
			panelin.add(waterlabel[i]);
			
			waterfield[i]=new JTextField(water[i], 7);
			waterfield[i].setEditable(false);
			c = new GridBagConstraints(5,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(waterfield[i],c);
			panelin.add(waterfield[i]);
			
			elelabel[i]=new JLabel("�������");
			c = new GridBagConstraints(6,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(elelabel[i],c);
			panelin.add(elelabel[i]);
			
			elefield[i]=new JTextField(ele[i], 7);
			elefield[i].setEditable(false);
			c = new GridBagConstraints(7,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(elefield[i],c);
			panelin.add(elefield[i]);
			
			gaslabel[i]=new JLabel("ú������");
			c = new GridBagConstraints(8,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(gaslabel[i],c);
			panelin.add(gaslabel[i]);
			
			gasfield[i]=new JTextField(gas[i], 7);
			gasfield[i].setEditable(false);
			c = new GridBagConstraints(9,y,1,1,0,0,10,0,inset,0,0);
			gridbag.setConstraints(gasfield[i],c);
			panelin.add(gasfield[i]);
			
			y+=4;
		}
		
		setSize(800,600);
		setVisible(true);
	}
	
	public void getdata(String date, String uptownid,String building)
	{
		water=new String[500];
		ele=new String[500];
		gas=new String[500];
		room=new String[500];
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			String url1 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection1 = DriverManager.getConnection(url1,"swing_wuye","swing_wuye");
			Statement stmt1 = connection1.createStatement(); 
			String sqlUptown = "SELECT room_id, elec_reading,water_reading, gas_reading FROM user_reading WHERE date="+date+" AND district_id="+uptownid+" AND building_id="+building;
			ResultSet rs1 = stmt1.executeQuery(sqlUptown);
			
			System.out.println("the 00");
			
			int i=0;
			while( rs1.next() )
			{
				room[i]=rs1.getString( "room_id" );
				ele[i] = rs1.getString( "elec_reading" );
				gas[i] = rs1.getString( "gas_reading" );
				water[i]=rs1.getString( "water_reading" );
				i++;
			}
			count=i;
			//System.out.println("the 01");
			
			rs1.close();
			connection1.close();
		}
		
		catch( Exception ex ) {
			System.out.println(ex);
			//System.exit(0);
		}
	}
}