import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.*;
import java.applet.*;
import javax.swing.event.*;

public class Shoufei extends JFrame {
	
	private Connection c1;
	private String Mouaction;
	private JTable display;
	
	public Shoufei(){
		try{
				Class.forName("com.mysql.jdbc.Driver");
				c1 = DriverManager.getConnection("jdbc:mysql://47.101.198.61:3306/swing_wuye","swing_wuye","swing_wuye");
			}
		catch(Exception err)
		{
			err.printStackTrace();
		}//�������ݿ����ӣ�
		
		display = new JTable();
		Container temp = getContentPane();
        temp.setLayout(new BorderLayout());
      	temp.add(display,BorderLayout.CENTER);
      	getpriceTable();
      	setSize(500,300);
      	show();
	}
		
	
	/*public void actionPerformed(ActionEvent e){
		Mouaction = e.getActionCommand();
		try{
				Class.forName("com.mysql.jdbc.Driver");
				c1 = DriverManager.getConnection("jdbc:mysql://47.101.198.61:3306/swing_wuye");
			}
		catch(Exception err)
		{
			err.printStackTrace();
		}//�������ݿ����ӣ�
		
		getpriceTable();
		
	}*/
	
	public void getpriceTable(){
		try
			{
				Vector columnName = new Vector();
				Vector rows = new Vector();//�����������������ݿ����ݲ���
				
				String sql="SELECT * FROM unit_price_info";
				Statement stmt1  = c1.createStatement();
				ResultSet rsl1 = stmt1.executeQuery(sql);
				ResultSetMetaData rsmd1 = rsl1.getMetaData();//��ȡ�����ֶ�����
				
				columnName.addElement("�շ���Ŀ");
				columnName.addElement("����(��λ��Ԫ��");
				
				while(rsl1.next())
				{                                              // ��ȡ��¼��
            		Vector currentRow = new Vector();
            		for ( int i = 2; i <= rsmd1.getColumnCount(); ++i )
            		{
         				currentRow.addElement( rsl1.getString( i ) );
      				}
            		rows.addElement( currentRow);
            	}
            	
            	display = new JTable(rows,columnName);
            	JScrollPane scroller = new JScrollPane(display);
            	Container temp = getContentPane();
            	
            	temp.add(scroller,BorderLayout.CENTER);
            	temp.validate();				
			}
			catch(Exception sqlex)
			{
				sqlex.printStackTrace();
			}
		}
		
		public static void main(String args[]){
			Shoufei s1 = new Shoufei();
			s1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		}
		
			
	}