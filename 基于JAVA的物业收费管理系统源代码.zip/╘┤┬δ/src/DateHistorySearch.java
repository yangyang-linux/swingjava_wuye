import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.*;
import javax.swing.event.*;

public class DateHistorySearch extends JFrame
{
	private JLabel titleLabel1, titleLabel2, titleLabel3, titleLabel4, dateLabel[], uptownLabel[], buildingLabel;
	private JButton button1, button2, button3, button4, button5;
	private JComboBox dateBox1, dateBox2, dateBox3, dateBox4, uptownBox[], buildingBox;
	private String uptown_name2[], uptown_id2[], building_id[], date1[], room_id[], date2[], date3[], date4[];
	private String uptown_name3[], uptown_id3[], uptown_name4[], uptown_id4[];
	private String inuptownid, inuptownname, inbuilding, indate;
	
	private GridBagConstraints c;
	private Insets inset;
	private GridBagLayout gridbag;
	private int t;
	
	public DateHistorySearch()
	{
		super("���ѡ��");
		Container panelin = getContentPane();
		gridbag=new GridBagLayout();
		panelin.setLayout(gridbag);
		inset = new Insets(5,5,5,5);
		indate=new String("ѡ������");
		
		dateLabel=new JLabel[4];
		uptownLabel=new JLabel[3];
		uptownBox=new JComboBox[3];
		
		building_id=new String[100];
		building_id[0]=new String("ѡ��¥��");
		
		getuptown();
		getdate1();
		
		titleLabel1=new JLabel("1����ѯȫ��С��");
		c = new GridBagConstraints(2,1,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(titleLabel1,c);
		panelin.add(titleLabel1);
		
		dateLabel[0]=new JLabel("ʱ��");
		c = new GridBagConstraints(2,3,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateLabel[0],c);
		panelin.add(dateLabel[0]);
		
		dateBox1=new JComboBox(date1);
		dateBox1.setMaximumRowCount( 5 );
		c = new GridBagConstraints(3,3,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateBox1,c);
		panelin.add(dateBox1);
		dateBox1.addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = dateBox1.getSelectedIndex();
					t++;
					indate=new String(date1[i]);
				}
			}
			);
		
		button1=new JButton("ȷ��");
		c = new GridBagConstraints(11,3,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button1,c);
		panelin.add(button1);
		button1.addActionListener( 
			new ActionListener(){
				public void actionPerformed( ActionEvent event) {
					if(indate.equals("ѡ������"))
					{
						JOptionPane.showMessageDialog(null,"��ѡ�����ں��ٰ�ȷ��","Error",JOptionPane.PLAIN_MESSAGE);
					}
					else
					{
						UptownShow us=new UptownShow(indate);
						DateHistorySearch.this.setVisible(false);
					}
				}
			}
			);
			
		titleLabel2=new JLabel("2����ѯС����ȫ��¥��");
		c = new GridBagConstraints(2,4,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(titleLabel2,c);
		panelin.add(titleLabel2);
		
		uptownLabel[0]=new JLabel("С��ѡ��");
		c = new GridBagConstraints(2,5,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownLabel[0],c);
		panelin.add(uptownLabel[0]);
		
		uptownBox[0]=new JComboBox(uptown_name2);
		uptownBox[0].setMaximumRowCount( 5 );
		c = new GridBagConstraints(3,5,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownBox[0],c);
		panelin.add(uptownBox[0]);
		uptownBox[0].addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = uptownBox[0].getSelectedIndex();
					t++;
					inuptownname=new String(uptown_name2[i]);
					inuptownid=new String(uptown_id2[i]);
					if(t==1)
					{
						DateHistorySearch dhs1=new DateHistorySearch(2,inuptownid, inuptownname);
					}
					DateHistorySearch.this.setVisible(false);
				}
			}
			);
		dateLabel[1]=new JLabel("ʱ��");
		c = new GridBagConstraints(5,5,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateLabel[1],c);
		panelin.add(dateLabel[1]);
		
		date2=new String[4];
		date2[0]=new String("ѡ��ʱ��");
		dateBox2=new JComboBox(date2);
		dateBox2.setMaximumRowCount( 5 );
		c = new GridBagConstraints(6,5,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateBox2,c);
		panelin.add(dateBox2);
		
		button2=new JButton("ȷ��");
		c = new GridBagConstraints(11,5,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button2,c);
		panelin.add(button2);
		button2.setEnabled(false);
		
		titleLabel3=new JLabel("3����ѯС���ڵ�ȫ��ҵ��");
		c = new GridBagConstraints(2,6,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(titleLabel3,c);
		panelin.add(titleLabel3);
		
		uptownLabel[1]=new JLabel("С��ѡ��");
		c = new GridBagConstraints(2,7,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownLabel[1],c);
		panelin.add(uptownLabel[1]);
		
		uptownBox[1]=new JComboBox(uptown_name3);
		uptownBox[1].setMaximumRowCount( 5 );
		c = new GridBagConstraints(3,7,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownBox[1],c);
		panelin.add(uptownBox[1]);
		uptownBox[1].addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = uptownBox[1].getSelectedIndex();
					t++;
					inuptownname=new String(uptown_name3[i]);
					inuptownid=new String(uptown_id3[i]);
					if(t==1)
					{
						DateHistorySearch dhs1=new DateHistorySearch(3,inuptownid, inuptownname);
					}
					DateHistorySearch.this.setVisible(false);
				}
			}
			);
		dateLabel[2]=new JLabel("ʱ��");
		c = new GridBagConstraints(5,7,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateLabel[2],c);
		panelin.add(dateLabel[2]);
		
		date3=new String[5];
		date3[0]=new String("ѡ��ʱ��");
		dateBox3=new JComboBox(date3);
		dateBox3.setMaximumRowCount( 5 );
		c = new GridBagConstraints(6,7,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateBox3,c);
		panelin.add(dateBox3);
		
		button3=new JButton("ȷ��");
		c = new GridBagConstraints(11,7,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button3,c);
		panelin.add(button3);
		button3.setEnabled(false);
		
		titleLabel4=new JLabel("4����ѯС����ĳ��¥��ȫ��ҵ��");
		c = new GridBagConstraints(2,8,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(titleLabel4,c);
		panelin.add(titleLabel4);
		
		uptownLabel[2]=new JLabel("С��ѡ��");
		c = new GridBagConstraints(2,9,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownLabel[2],c);
		panelin.add(uptownLabel[2]);
		
		uptownBox[2]=new JComboBox(uptown_name4);
		uptownBox[2].setMaximumRowCount( 5 );
		c = new GridBagConstraints(3,9,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownBox[2],c);
		panelin.add(uptownBox[2]);
		uptownBox[2].addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = uptownBox[2].getSelectedIndex();
					t++;
					inuptownname=new String(uptown_name4[i]);
					inuptownid=new String(uptown_id4[i]);
					if(t==1)
					{
						DateHistorySearch dhs1=new DateHistorySearch(4,inuptownid, inuptownname);
					}
					DateHistorySearch.this.setVisible(false);
				}
			}
			);
		
		buildingLabel=new JLabel("¥��ѡ��");
		c = new GridBagConstraints(5,9,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(buildingLabel,c);
		panelin.add(buildingLabel);
		
		buildingBox=new JComboBox(building_id);
		buildingBox.setMaximumRowCount( 5 );
		c = new GridBagConstraints(6,9,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(buildingBox,c);
		panelin.add(buildingBox);
		
		dateLabel[3]=new JLabel("ʱ��ѡ��");
		c = new GridBagConstraints(8,9,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateLabel[3],c);
		panelin.add(dateLabel[3]);
		
		date4=new String[5];
		date4[0]=new String("ѡ��ʱ��");
		dateBox4=new JComboBox(date4);
		dateBox4.setMaximumRowCount( 5 );
		c = new GridBagConstraints(9,9,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateBox4,c);
		panelin.add(dateBox4);
		
		button4=new JButton("ȷ��");
		c = new GridBagConstraints(11,9,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button4,c);
		panelin.add(button4);
		button4.setEnabled(false);
		
		setSize(800,600);
		setVisible(true);
	}
	
	public DateHistorySearch(int tt, String uptownid, String uptownname)
	{
		super("���ѡ��");
		System.out.println("date history search 2 begin");
		Container panelin = getContentPane();
		gridbag=new GridBagLayout();
		panelin.setLayout(gridbag);
		inset = new Insets(5,5,5,5);
		indate=new String("ѡ������");
		
		dateLabel=new JLabel[4];
		uptownLabel=new JLabel[3];
		uptownBox=new JComboBox[3];
		building_id=new String[6];
		building_id[0]=new String("ѡ��¥��");
		
		getuptown();
		getdate1();
		
		inuptownid=new String(uptownid);
		inuptownname=new String(uptownname);
		
		date2=new String[6];
		date2[0]=new String("ѡ��ʱ��");
		date3=new String[6];
		date3[0]=new String("ѡ��ʱ��");
		date4=new String[6];
		date4[0]=new String("ѡ��ʱ��");
		if(tt==2)
		{
			uptown_name2[0]=new String(inuptownname);
			uptown_id2[0]=new String(inuptownid);
			getdate2(inuptownid);
		}
		if(tt==3)
		{
			uptown_name3[0]=new String(inuptownname);
			uptown_id3[0]=new String(inuptownid);
			getdate3(inuptownid);
		}
		if(tt==4)
		{
			uptown_name4[0]=new String(inuptownname);
			uptown_id4[0]=new String(inuptownid);
			getbuilding(inuptownid);
		}
		
		
		System.out.println("init end");
		
		titleLabel1=new JLabel("1����ѯȫ��С��");
		c = new GridBagConstraints(2,1,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(titleLabel1,c);
		panelin.add(titleLabel1);
		
		dateLabel[0]=new JLabel("ʱ��");
		c = new GridBagConstraints(2,3,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateLabel[0],c);
		panelin.add(dateLabel[0]);
		
		dateBox1=new JComboBox(date1);
		dateBox1.setMaximumRowCount( 5 );
		c = new GridBagConstraints(3,3,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateBox1,c);
		panelin.add(dateBox1);
		dateBox1.addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = dateBox1.getSelectedIndex();
					t++;
					indate=new String(date1[i]);
				}
			}
			);
		
		button1=new JButton("ȷ��");
		c = new GridBagConstraints(11,3,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button1,c);
		panelin.add(button1);
		button1.addActionListener( 
			new ActionListener(){
				public void actionPerformed( ActionEvent event) {
					if(indate.equals("ѡ������"))
					{
						JOptionPane.showMessageDialog(null,"��ѡ�����ں��ٰ�ȷ��","Error",JOptionPane.PLAIN_MESSAGE);
					}
					else
					{
						UptownShow us=new UptownShow(indate);
						DateHistorySearch.this.setVisible(false);
					}
				}
			}
			);
		
		System.out.println("step1 end");
			
		titleLabel2=new JLabel("2����ѯС����ȫ��¥��");
		c = new GridBagConstraints(2,4,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(titleLabel2,c);
		panelin.add(titleLabel2);
		
		uptownLabel[0]=new JLabel("С��ѡ��");
		c = new GridBagConstraints(2,5,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownLabel[0],c);
		panelin.add(uptownLabel[0]);
		
		uptownBox[0]=new JComboBox(uptown_name2);
		uptownBox[0].setMaximumRowCount( 5 );
		c = new GridBagConstraints(3,5,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownBox[0],c);
		panelin.add(uptownBox[0]);
		uptownBox[0].addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = uptownBox[0].getSelectedIndex();
					t++;
					inuptownname=new String(uptown_name2[i]);
					inuptownid=new String(uptown_id2[i]);
					if(t==1)
					{
						DateHistorySearch dhs1=new DateHistorySearch(2,inuptownid, inuptownname);
					}
					DateHistorySearch.this.setVisible(false);
				}
			}
			);
		dateLabel[1]=new JLabel("ʱ��");
		c = new GridBagConstraints(5,5,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateLabel[1],c);
		panelin.add(dateLabel[1]);
		
		dateBox2=new JComboBox(date2);
		dateBox2.setMaximumRowCount( 5 );
		c = new GridBagConstraints(6,5,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateBox2,c);
		panelin.add(dateBox2);
		dateBox2.addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = dateBox2.getSelectedIndex();
					t++;
					indate=new String(date2[i]);
				}
			}
			);
		
		button2=new JButton("ȷ��");
		c = new GridBagConstraints(11,5,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button2,c);
		panelin.add(button2);
		button2.addActionListener( 
			new ActionListener(){
				public void actionPerformed( ActionEvent event) {
					if(indate.equals("ѡ������"))
					{
						JOptionPane.showMessageDialog(null,"��ѡ�����ں��ٰ�ȷ��","Error",JOptionPane.PLAIN_MESSAGE);
					}
					else
					{
						UptownBuildingShow ubs=new UptownBuildingShow(indate, inuptownid, inuptownname);
						DateHistorySearch.this.setVisible(false);
					}
				}
			}
			);
		if(tt!=2)
		{
			button2.setEnabled(false);
		}
		
		System.out.println("step2 end");
		
		titleLabel3=new JLabel("3����ѯС���ڵ�ȫ��ҵ��");
		c = new GridBagConstraints(2,6,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(titleLabel3,c);
		panelin.add(titleLabel3);
		
		uptownLabel[1]=new JLabel("С��ѡ��");
		c = new GridBagConstraints(2,7,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownLabel[1],c);
		panelin.add(uptownLabel[1]);
		
		uptownBox[1]=new JComboBox(uptown_name3);
		uptownBox[1].setMaximumRowCount( 5 );
		c = new GridBagConstraints(3,7,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownBox[1],c);
		panelin.add(uptownBox[1]);
		uptownBox[1].addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = uptownBox[1].getSelectedIndex();
					t++;
					inuptownname=new String(uptown_name3[i]);
					inuptownid=new String(uptown_id3[i]);
					if(t==1)
					{
						DateHistorySearch dhs1=new DateHistorySearch(3,inuptownid, inuptownname);
					}
					DateHistorySearch.this.setVisible(false);
				}
			}
			);
		dateLabel[2]=new JLabel("ʱ��");
		c = new GridBagConstraints(5,7,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateLabel[2],c);
		panelin.add(dateLabel[2]);
		
		dateBox3=new JComboBox(date3);
		dateBox3.setMaximumRowCount( 5 );
		c = new GridBagConstraints(6,7,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateBox3,c);
		panelin.add(dateBox3);
		dateBox3.addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = dateBox3.getSelectedIndex();
					t++;
					indate=new String(date3[i]);
				}
			}
			);
		
		button3=new JButton("ȷ��");
		c = new GridBagConstraints(11,7,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button3,c);
		panelin.add(button3);
		button3.addActionListener( 
			new ActionListener(){
				public void actionPerformed( ActionEvent event) {
					if(indate.equals("ѡ������"))
					{
						JOptionPane.showMessageDialog(null,"��ѡ�����ں��ٰ�ȷ��","Error",JOptionPane.PLAIN_MESSAGE);
					}
					else
					{
						UptownRoomShow urs=new UptownRoomShow(indate, inuptownid, inuptownname);
						DateHistorySearch.this.setVisible(false);
					}
				}
			}
			);
		if(tt!=3)
		{
			button3.setEnabled(false);
		}
		
		System.out.println("step3 end");
		
		titleLabel4=new JLabel("4����ѯС����ĳ��¥��ȫ��ҵ��");
		c = new GridBagConstraints(2,8,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(titleLabel4,c);
		panelin.add(titleLabel4);
		
		uptownLabel[2]=new JLabel("С��ѡ��");
		c = new GridBagConstraints(2,9,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownLabel[2],c);
		panelin.add(uptownLabel[2]);
		
		uptownBox[2]=new JComboBox(uptown_name4);
		uptownBox[2].setMaximumRowCount( 5 );
		c = new GridBagConstraints(3,9,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownBox[2],c);
		panelin.add(uptownBox[2]);
		uptownBox[2].addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = uptownBox[2].getSelectedIndex();
					t++;
					inuptownname=new String(uptown_name4[i]);
					inuptownid=new String(uptown_id4[i]);
					if(t==1)
					{
						DateHistorySearch dhs1=new DateHistorySearch(4,inuptownid, inuptownname);
					}
					DateHistorySearch.this.setVisible(false);
				}
			}
			);
		
		buildingLabel=new JLabel("¥��ѡ��");
		c = new GridBagConstraints(5,9,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(buildingLabel,c);
		panelin.add(buildingLabel);
		
		buildingBox=new JComboBox(building_id);
		buildingBox.setMaximumRowCount( 5 );
		c = new GridBagConstraints(6,9,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(buildingBox,c);
		panelin.add(buildingBox);
		buildingBox.addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = buildingBox.getSelectedIndex();
					t++;
					inbuilding=new String(building_id[i]);
					if(t==1)
					{
						DateHistorySearch dhs1=new DateHistorySearch(inuptownid, inuptownname, inbuilding);
					}
					DateHistorySearch.this.setVisible(false);
				}
			}
			);
		
		dateLabel[3]=new JLabel("ʱ��");
		c = new GridBagConstraints(8,9,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateLabel[3],c);
		panelin.add(dateLabel[3]);
		
		date4=new String[5];
		date4[0]=new String("ѡ��ʱ��");
		dateBox4=new JComboBox(date4);
		dateBox4.setMaximumRowCount( 5 );
		c = new GridBagConstraints(9,9,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateBox4,c);
		panelin.add(dateBox4);
		
		button4=new JButton("ȷ��");
		c = new GridBagConstraints(11,9,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button4,c);
		panelin.add(button4);
		button4.setEnabled(false);
		
		System.out.println("step14 end");
		
		setSize(800,600);
		setVisible(true);
	}
	
	public DateHistorySearch(String uptownid, String uptownname, String buildingid)
	{
		super("���ѡ��");
		System.out.println("date history seatch 3 begin");
		Container panelin = getContentPane();
		gridbag=new GridBagLayout();
		panelin.setLayout(gridbag);
		inset = new Insets(5,5,5,5);
		indate=new String("ѡ������");
		
		dateLabel=new JLabel[4];
		uptownLabel=new JLabel[3];
		uptownBox=new JComboBox[3];
		
		getuptown();
		getdate1();
		
		inuptownid=new String(uptownid);
		inuptownname=new String(uptownname);
		inbuilding=new String(buildingid);
		
		getdate4(inuptownid,inbuilding);
		
		uptown_name4[0]=new String(inuptownname);
		uptown_id4[0]=new String(inuptownid);
		
		getbuilding(inuptownid);
		building_id[0]=new String(inbuilding);
		
		
		titleLabel1=new JLabel("1����ѯȫ��С��");
		c = new GridBagConstraints(2,1,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(titleLabel1,c);
		panelin.add(titleLabel1);
		
		dateLabel[0]=new JLabel("ʱ��");
		c = new GridBagConstraints(2,3,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateLabel[0],c);
		panelin.add(dateLabel[0]);
		
		dateBox1=new JComboBox(date1);
		dateBox1.setMaximumRowCount( 5 );
		c = new GridBagConstraints(3,3,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateBox1,c);
		panelin.add(dateBox1);
		dateBox1.addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = dateBox1.getSelectedIndex();
					t++;
					indate=new String(date1[i]);
				}
			}
			);
		
		button1=new JButton("ȷ��");
		c = new GridBagConstraints(11,3,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button1,c);
		panelin.add(button1);
		button1.addActionListener( 
			new ActionListener(){
				public void actionPerformed( ActionEvent event) {
					if(indate.equals("ѡ������"))
					{
						JOptionPane.showMessageDialog(null,"��ѡ�����ں��ٰ�ȷ��","Error",JOptionPane.PLAIN_MESSAGE);
					}
					else
					{
						UptownShow us=new UptownShow(indate);
						DateHistorySearch.this.setVisible(false);
					}
				}
			}
			);
		
		System.out.println("step 1 end");
			
		titleLabel2=new JLabel("2����ѯС����ȫ��¥��");
		c = new GridBagConstraints(2,4,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(titleLabel2,c);
		panelin.add(titleLabel2);
		
		uptownLabel[0]=new JLabel("С��ѡ��");
		c = new GridBagConstraints(2,5,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownLabel[0],c);
		panelin.add(uptownLabel[0]);
		
		uptownBox[0]=new JComboBox(uptown_name2);
		uptownBox[0].setMaximumRowCount( 5 );
		c = new GridBagConstraints(3,5,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownBox[0],c);
		panelin.add(uptownBox[0]);
		uptownBox[0].addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = uptownBox[0].getSelectedIndex();
					t++;
					inuptownname=new String(uptown_name2[i]);
					inuptownid=new String(uptown_id2[i]);
					if(t==1)
					{
						DateHistorySearch dhs1=new DateHistorySearch(2,inuptownid, inuptownname);
					}DateHistorySearch.this.setVisible(false);
				}
			}
			);
		dateLabel[1]=new JLabel("ʱ��");
		c = new GridBagConstraints(5,5,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateLabel[1],c);
		panelin.add(dateLabel[1]);
		
		date2=new String[4];
		date2[0]=new String("ѡ��ʱ��");
		dateBox2=new JComboBox(date2);
		dateBox2.setMaximumRowCount( 5 );
		c = new GridBagConstraints(6,5,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateBox2,c);
		panelin.add(dateBox2);
		
		button2=new JButton("ȷ��");
		c = new GridBagConstraints(11,5,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button2,c);
		panelin.add(button2);
		button2.setEnabled(false);
		
		System.out.println("step 2 end");
		
		titleLabel3=new JLabel("3����ѯС���ڵ�ȫ��ҵ��");
		c = new GridBagConstraints(2,6,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(titleLabel3,c);
		panelin.add(titleLabel3);
		
		uptownLabel[1]=new JLabel("С��ѡ��");
		c = new GridBagConstraints(2,7,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownLabel[1],c);
		panelin.add(uptownLabel[1]);
		
		uptownBox[1]=new JComboBox(uptown_name3);
		uptownBox[1].setMaximumRowCount( 5 );
		c = new GridBagConstraints(3,7,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownBox[1],c);
		panelin.add(uptownBox[1]);
		uptownBox[1].addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = uptownBox[1].getSelectedIndex();
					t++;
					inuptownname=new String(uptown_name3[i]);
					inuptownid=new String(uptown_id3[i]);
					if(t==1)
					{
						DateHistorySearch dhs1=new DateHistorySearch(3,inuptownid, inuptownname);
					}
					DateHistorySearch.this.setVisible(false);
				}
			}
			);
		dateLabel[2]=new JLabel("ʱ��");
		c = new GridBagConstraints(5,7,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateLabel[2],c);
		panelin.add(dateLabel[2]);
		
		date3=new String[4];
		date3[0]=new String("ѡ��ʱ��");
		dateBox3=new JComboBox(date3);
		dateBox3.setMaximumRowCount( 5 );
		c = new GridBagConstraints(6,7,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateBox3,c);
		panelin.add(dateBox3);
		
		button3=new JButton("ȷ��");
		c = new GridBagConstraints(11,7,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button3,c);
		panelin.add(button3);
		button3.setEnabled(false);
		
		System.out.println("step 3 end");
		
		titleLabel4=new JLabel("4����ѯС����ĳ��¥��ȫ��ҵ��");
		c = new GridBagConstraints(2,8,2,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(titleLabel4,c);
		panelin.add(titleLabel4);
		
		uptownLabel[2]=new JLabel("С��ѡ��");
		c = new GridBagConstraints(2,9,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownLabel[2],c);
		panelin.add(uptownLabel[2]);
		
		uptownBox[2]=new JComboBox(uptown_name4);
		uptownBox[2].setMaximumRowCount( 5 );
		c = new GridBagConstraints(3,9,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(uptownBox[2],c);
		panelin.add(uptownBox[2]);
		uptownBox[2].addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = uptownBox[2].getSelectedIndex();
					t++;
					inuptownname=new String(uptown_name4[i]);
					inuptownid=new String(uptown_id4[i]);
					if(t==1)
					{
						DateHistorySearch dhs1=new DateHistorySearch(4,inuptownid, inuptownname);
					}
					DateHistorySearch.this.setVisible(false);
				}
			}
			);
		
		buildingLabel=new JLabel("¥��ѡ��");
		c = new GridBagConstraints(5,9,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(buildingLabel,c);
		panelin.add(buildingLabel);
		
		buildingBox=new JComboBox(building_id);
		buildingBox.setMaximumRowCount( 5 );
		c = new GridBagConstraints(6,9,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(buildingBox,c);
		panelin.add(buildingBox);
		buildingBox.addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = buildingBox.getSelectedIndex();
					t++;
					inbuilding=new String(building_id[i]);
					if(t==1)
					{
						DateHistorySearch dhs1=new DateHistorySearch(inuptownid, inuptownname, inbuilding);
					}
					DateHistorySearch.this.setVisible(false);
				}
			}
			);
		
		dateLabel[3]=new JLabel("ʱ��");
		c = new GridBagConstraints(8,9,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateLabel[3],c);
		panelin.add(dateLabel[3]);
		
		
		dateBox4=new JComboBox(date4);
		dateBox4.setMaximumRowCount( 5 );
		c = new GridBagConstraints(9,9,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(dateBox4,c);
		panelin.add(dateBox4);
		dateBox4.addItemListener(
			new ItemListener() {
				public void itemStateChanged( ItemEvent event )
				{
					int i=0;
					i = dateBox4.getSelectedIndex();
					t++;
					indate=new String(date4[i]);
				}
			}
			);
		
		button4=new JButton("ȷ��");
		c = new GridBagConstraints(11,9,1,1,0,0,10,0,inset,0,0);
		gridbag.setConstraints(button4,c);
		panelin.add(button4);
		button4.addActionListener( 
			new ActionListener(){
				public void actionPerformed( ActionEvent event) {
					if(indate.equals("ѡ������"))
					{
						JOptionPane.showMessageDialog(null,"��ѡ�����ں��ٰ�ȷ��","Error",JOptionPane.PLAIN_MESSAGE);
					}
					else
					{
						UptownBuildingRoomShow ubrs=new UptownBuildingRoomShow(inuptownid,inuptownname,inbuilding,indate);
						DateHistorySearch.this.setVisible(false);
					}
				}
			}
			);
		//button4.setVisible(false);
		
		setSize(800,600);
		setVisible(true);
	}
	
	public void getdate1()
	{
		date1 =new String[6];
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			String url1 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection1 = DriverManager.getConnection(url1,"swing_wuye","swing_wuye");
			Statement stmt1 = connection1.createStatement(); 
			String sqlUptown = "SELECT date FROM district_reading ORDER BY date";
			ResultSet rs1 = stmt1.executeQuery(sqlUptown);
			
			System.out.println("the 00");
		
			int i= 1;
			date1[0]=new String("ѡ������");
			while( rs1.next() )
			{
				date1[i] = rs1.getString( "date" );
				i++;
			}
			
			//System.out.println("the 01");
			
			rs1.close();
			connection1.close();
		}
		
		catch( Exception ex ) {
			System.out.println(ex);
			//System.exit(0);
		}
	}
	
	public void getdate2(String uptownid)
	{
		date2=new String[6];
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			String url1 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection1 = DriverManager.getConnection(url1,"swing_wuye","swing_wuye");
			Statement stmt1 = connection1.createStatement(); 
			String sqlUptown = "SELECT date FROM building_elec_reading WHERE district_id="+uptownid+" ORDER BY date";
			ResultSet rs1 = stmt1.executeQuery(sqlUptown);
			
			System.out.println("the 00");
		
			int i= 1;
			date2[0]=new String("ѡ������");
			while( rs1.next() )
			{
				date2[i] = rs1.getString( "date" );
				i++;
			}
			
			//System.out.println("the 01");
			
			rs1.close();
			connection1.close();
		}
		
		catch( Exception ex ) {
			System.out.println(ex);
			//System.exit(0);
		}
	}
	
	public void getdate3(String uptownid)
	{
		date3=new String[6];
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			String url1 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection1 = DriverManager.getConnection(url1,"swing_wuye","swing_wuye");
			Statement stmt1 = connection1.createStatement(); 
			String sqlUptown = "SELECT date FROM user_reading WHERE district_id="+uptownid+" ORDER BY date";
			ResultSet rs1 = stmt1.executeQuery(sqlUptown);
			
			System.out.println("the 00");
		
			int i= 1;
			date3[0]=new String("ѡ������");
			while( rs1.next() )
			{
				date3[i] = rs1.getString( "date" );
				i++;
			}
			
			//System.out.println("the 01");
			
			rs1.close();
			connection1.close();
		}
		
		catch( Exception ex ) {
			System.out.println(ex);
			//System.exit(0);
		}
	}
	
	public void getdate4(String uptownid, String buildingid)
	{
		date4=new String[6];
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			String url1 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection1 = DriverManager.getConnection(url1,"swing_wuye","swing_wuye");
			Statement stmt1 = connection1.createStatement(); 
			String sqlUptown = "SELECT distinct date FROM user_reading WHERE district_id="+uptownid+" AND building_id="+buildingid+" ORDER BY date";
			ResultSet rs1 = stmt1.executeQuery(sqlUptown);
			
			System.out.println("the 00");
		
			int i= 1;
			date4[0]=new String("ѡ������");
			while( rs1.next() )
			{
				date4[i] = rs1.getString( "date" );
				i++;
			}
			
			//System.out.println("the 01");
			
			rs1.close();
			connection1.close();
		}
		
		catch( Exception ex ) {
			System.out.println(ex);
			//System.exit(0);
		}
	}
	
	public void getuptown()//��ȡС����Ϣ
	{
		uptown_name2=new String[50];
		uptown_id2=new String[50];
		uptown_name3=new String[50];
		uptown_id3=new String[50];
		uptown_name4=new String[50];
		uptown_id4=new String[50];
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			String url1 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection1 = DriverManager.getConnection(url1,"swing_wuye","swing_wuye");
			Statement stmt1 = connection1.createStatement(); 
			String sqlUptown = "SELECT district_id,district_name FROM district_info ORDER BY district_id";
			ResultSet rs1 = stmt1.executeQuery(sqlUptown);
			
			System.out.println("the 00");
		
			int i= 1;
			while( rs1.next() )
			{
				uptown_id2[i] = rs1.getString( "district_id" );
				uptown_name2[i] = rs1.getString( "district_name" );
				//uptown_id3[i] = rs1.getString( "district_id" );
				//uptown_name3[i] = rs1.getString( "district_name" );
				//uptown_id4[i] = rs1.getString( "district_id" );
				//uptown_name4[i] = rs1.getString( "district_name" );
				i++;
			}
			
			for(int j=1;j<i;j++)
			{
				uptown_id3[j] = new String(uptown_id2[j]);
				uptown_name3[j] = new String(uptown_name2[j]);
				uptown_id4[j] = new String(uptown_id2[j]);
				uptown_name4[j] = new String(uptown_name2[j]);
			}
			uptown_name2[0]=new String("ѡ��С��");
			uptown_name3[0]=new String("ѡ��С��");
			uptown_name4[0]=new String("ѡ��С��");
			//System.out.println("the 01");
			
			rs1.close();
			connection1.close();
		}
		
		catch( Exception ex ) {
			System.out.println(ex);
			System.out.println("getuptown() error");
			uptown_name2[0]=new String("û��С��");
			uptown_name3[0]=new String("û��С��");
			uptown_name4[0]=new String("û��С��");
			//System.exit(0);
		}//���ȡС����Ϣ
	}
	
	public void getbuilding(String uptown)//��ȡС���ڵ�¥����Ϣ
	{
		
		System.out.println("the 04");
		building_id=new String[100];
		try{
			Class.forName("com.mysql.jdbc.Driver");
			String url2 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection2 = DriverManager.getConnection(url2,"swing_wuye","swing_wuye");
			Statement stmt2 = connection2.createStatement();
			String sqlBuilding = "SELECT building_id FROM building_info WHERE district_id="+uptown+" ORDER BY building_id";
			System.out.println("the 041");
			ResultSet rs2 = stmt2.executeQuery(sqlBuilding);
						
			int i = 1;
			while( rs2.next() )
			{
				building_id[i] = rs2.getString( "building_id" );
				i++;
			}
			building_id[0]=new String("ѡ��¥��");
			//count = i;
			//System.out.println("the 11");
			//panelin.repaint();
			rs2.close();
			connection2.close();
		}
					
		catch( Exception ex )
		{
			System.out.println( ex );
			//System.exit(0);
		}
	}
	
	public static void main(String args[])
	{
		DateHistorySearch ap = new DateHistorySearch();
		ap.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}