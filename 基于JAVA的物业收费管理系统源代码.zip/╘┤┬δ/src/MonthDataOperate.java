import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.*;
import javax.swing.event.*;

public class MonthDataOperate
{
	private int indate, lastdate, deletedate;
	private int in_water[],in_ele[],in_gas[],last_water[],last_ele[],last_gas[];
	private String message1, message2;
	private String in_uptown, in_building, in_roomid[], last_roomid[], errorid[];
	private int roomcount, errortype, lasterror, delerror;
	private String delsql, sqlinsert[];
	
	public MonthDataOperate( String uptownid, String buildingid, String roomid[], String water[], String ele[], String gas[], String date, int count) 
	{
		in_water = new int[count];
		in_ele = new int[count];
		in_gas = new int[count];
		last_water = new int [count];
		last_ele = new int[count];
		last_gas = new int[count];
		in_roomid = new String[count];
		last_roomid = new String[count];
		errorid = new String[count];
		roomcount = count;
		
		System.out.println("the operate begin");
		
		indate = Integer.parseInt(date );
		if( indate%100==1 )
		{
			lastdate=indate-100+11;
			deletedate=indate-100+9;
		}
		else
		{
			if(indate%100>3)
			{
				lastdate=indate-1;
				deletedate=indate-3;
			}
			else
			{
				lastdate=indate-1;
				deletedate=indate-100+9;
			}
		}
		
		for( int i=0; i<count; i++)
		{
			in_water[i] = Integer.parseInt( water[i] );
			in_ele[i] = Integer.parseInt( ele[i] );
			in_gas[i] = Integer.parseInt( gas[i] );
			in_roomid[i] = new String( roomid[i] );
		}
		
		System.out.println(in_water[1]);
		System.out.print("for end");
		
		in_uptown = new String( uptownid );
		in_building = new String( buildingid );
		
		getlastdata( in_uptown, in_building, in_roomid, lastdate);
		getdeldata( in_uptown, in_building, in_roomid, deletedate);
		
		System.out.println("search end");
		
		if(lasterror==0&&delerror==0)
		{
			insertdata( in_uptown, in_building, in_roomid, in_water, in_ele, in_gas, indate, roomcount);
		}
		if(lasterror>0&&delerror==0)
		{
			errortype = datacompare( in_water, in_ele, in_gas, last_water, last_ele, last_gas, in_roomid);
			
			System.out.println("errortype = "+errortype);
			
			if( errortype==0 )
			{
				insertdata( in_uptown, in_building, in_roomid, in_water, in_ele, in_gas, indate, roomcount);
			}
			if( errortype==2 )
			{
				int j=0;
				message1 = "���·�����������ݿ����д�";
				
				
				for(int k=0;k<roomcount;k++)
				{
					if(errorid[k]!=null)
					{
						message1+=errorid[k]+",";
					}
				}
				
				message2=message1+"���鲢���������Ǽ������������";
				int messagetype = JOptionPane.INFORMATION_MESSAGE;
				int optiontype = JOptionPane.YES_NO_OPTION;
				String title = new String( "����");
				int result = JOptionPane.showConfirmDialog(null,message2,title,optiontype,messagetype);
				if( result == JOptionPane.YES_OPTION)
				{
					insertdata( in_uptown, in_building, in_roomid, in_water, in_ele, in_gas, indate, roomcount);
				}
				
			}
			if( errortype==3 )
			{
				int j=0;
				message1 = "���·�������������д�";
				
				
				for(int k=0;k<roomcount;k++)
				{
					if(errorid[k]!=null)
					{
						message1+=errorid[k]+",";
					}
				}
				/*while( errorid[j]!=null)
				{
					message1+=errorid[j]+",";
					j++;
				}*/
				System.out.println(message1);
				message2=message1+"���鲢������";
				JOptionPane.showMessageDialog(null,message2,"Error",JOptionPane.PLAIN_MESSAGE);
				//System.exit(0);
			}
		}
		
		System.out.println("case 1 end");
		
		if(lasterror>0&&delerror>0)
		{
			errortype = datacompare( in_water, in_ele, in_gas, last_water, last_ele, last_gas, in_roomid);
			
			System.out.println("errortype = "+errortype);
			
			if( errortype==0 )
			{
				insertdata( in_uptown, in_building, in_roomid, in_water, in_ele, in_gas, indate, roomcount);
				deletedata( in_uptown, in_building, indate );
			}
			if( errortype==2 )
			{
				int m=0;
				
				message1 = "���·�����������ݿ����д�";
				
				
				for(int k=0;k<roomcount;k++)
				{
					if(errorid[k]!=null)
					{
						message1+=errorid[k]+",";
					}
				}
				
				message2=message1+"���鲢���������Ǽ������������";
				int messagetype = JOptionPane.INFORMATION_MESSAGE;
				int optiontype = JOptionPane.YES_NO_OPTION;
				String title = new String( "����");
				int result = JOptionPane.showConfirmDialog(null,message2,title,optiontype,messagetype);
				if( result == JOptionPane.YES_OPTION)
				{
					insertdata( in_uptown, in_building, in_roomid, in_water, in_ele, in_gas, indate, roomcount);
					deletedata( in_uptown, in_building, indate );
				}
			}
			if( errortype==3 )
			{
				int m=0;
				message1 = "���·�������������д�";
				
				
				for(int k=0;k<roomcount;k++)
				{
					if(errorid[k]!=null)
					{
						message1+=errorid[k]+",";
					}
				}
				message2=message1+"���鲢������";
				JOptionPane.showMessageDialog(null,message2,"Error",JOptionPane.PLAIN_MESSAGE);
				//System.exit(0);
			}
		}
		
		System.out.println("case 2 end");
	}
	
	public void getlastdata( String uptown, String building, String room[], int date)
	{
		System.out.println("get last data begin");
		lasterror=0;
		try{
			Class.forName( "com.mysql.jdbc.Driver" );
			String url4 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection4 = DriverManager.getConnection( url4 ,"swing_wuye","swing_wuye");
			Statement stmt4 = connection4.createStatement();
			String sqlLastData = "SELECT room_id, water_reading, elec_reading, gas_reading FROM user_reading WHERE district_id="+uptown+" AND building_id="+building+" AND date="+date;
			ResultSet rsLastData = stmt4.executeQuery( sqlLastData );
						
			last_water = new int[roomcount];
			last_ele = new int[roomcount];
			last_gas = new int[roomcount];
			last_roomid = new String[roomcount];
						
			int i = 0;
			while( rsLastData.next() ) 
			{
				last_roomid[i] = rsLastData.getString( "room_id" );
				last_water[i] = rsLastData.getInt( "water_reading" );
				last_ele[i] = rsLastData.getInt( "elec_reading" );
				last_gas[i] = rsLastData.getInt( "gas_reading" );
				i++;
				lasterror++;
			}
			
			System.out.println("i = "+i);
			for(int j=0;j<i;j++)
			{
				System.out.println(last_roomid[j]);
				System.out.println(last_ele[j]);
				System.out.println(last_gas[j]);
				System.out.println(last_water[j]);
			}
						
			rsLastData.close();
			connection4.close(); 
		}
					
		catch( Exception ex )
		{
			System.out.println(ex);
			
		}
		System.out.println(lasterror);
		
		System.out.println("get last data end");
	}
	
	public void getdeldata( String uptown, String building, String room[], int date)
	{
		System.out.println(" get delete data begin");
		delerror=0;
		try{
			Class.forName( "com.mysql.jdbc.Driver" );
			String url4 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection4 = DriverManager.getConnection( url4 ,"swing_wuye","swing_wuye");
			Statement stmt4 = connection4.createStatement();
			String sqlLastData = "SELECT room_id, water_reading, elec_reading, gas_reading FROM user_reading WHERE district_id="+uptown+" AND building_id="+building+" AND date="+date;
			ResultSet rsLastData = stmt4.executeQuery( sqlLastData );
			
			while( rsLastData.next() ) 
			{
				delerror++;
			}			
			rsLastData.close();
			connection4.close(); 
		}
					
		catch( Exception ex )
		{
			//delerror=1;
		}
		
		System.out.println(delerror);
		System.out.println("get delete data end");
	}
	
	public void deletedata( String uptown, String building, int date)
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			String url7 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
			Connection connection7 = DriverManager.getConnection(url7,"swing_wuye","swing_wuye");
			Statement stmt7 = connection7.createStatement();
			delsql = "DELETE FROM user_reading WHERE district_id="+uptown+" AND building_id="+building+" AND date="+date;
			stmt7.execute( delsql);
			connection7.close();
		}
		catch( Exception ex )
		{
			System.out.println( ex );
			//System.exit(0);
		}
	}
	
	public void insertdata( String uptown, String building, String room[], int water[], int ele[], int gas[], int date, int count)
	{
		System.out.println("insert data begin");
		try{
				Class.forName("com.mysql.jdbc.Driver");
				String url6 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
				Connection connection6 = DriverManager.getConnection(url6,"swing_wuye","swing_wuye");
				Statement stmt6 = connection6.createStatement();
				sqlinsert = new String[count];
				for( int i =0 ; i<count ; i++){
					sqlinsert[i] = "INSERT INTO user_reading values ( "+uptown+", "+building+", "+room[i]+", "+date+", "+water[i]+", "+ele[i]+", "+gas[i]+")";
					// (district_id, building_id, room_id, date, water_reading, elec_reading, gas_reading)
					System.out.println(sqlinsert[i]);
					stmt6.execute( sqlinsert[i]);
				}
				connection6.close();
				JOptionPane.showMessageDialog(null,"����ɹ���","����ɹ���",JOptionPane.PLAIN_MESSAGE);
			}
		catch( Exception ex )
		{
			System.out.println( ex );
			//System.exit(0);
		}
		
		System.out.println("insert data end");
	}
	
	public int datacompare( int water1[], int ele1[], int gas1[], int water2[], int ele2[], int gas2[], String room[])
	{
		int error=0;
		for( int i=0; i<roomcount; i++)
		{
			if( water1[i]<water2[i])
			{
				error=3;
				errorid[i] = new String(room[i]);
			}
			if( ele1[i]<ele2[i])
			{
				error=3;
				errorid[i] = new String(room[i]);
			}
			if( gas1[i]<gas2[i])
			{
				error=3;
				errorid[i] = new String(room[i]);
			}
			if( water1[i]>( water2[i]+100))
			{
				if(error==0)
					error=2;
				errorid[i] = new String(room[i]);
			}
			if( ele1[i]>( ele2[i]+1000))
			{
				if(error==0)
					error=2;
				errorid[i] = new String(room[i]);
			}
			if( gas1[i]>( gas2[i]+100))
			{
				if(error==0)
					error=2;
				errorid[i] = new String(room[i]);
			}
		}
		
		return( error );
	}

	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
	}
}