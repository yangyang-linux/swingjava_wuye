
/*===================================================
 *����С����ˮ�����ܵ�������ι�ˮ���
 *����¥����ݵ�����������
 *=================================================*/
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.*;

public class MonthDataInputBuilding
{
	private JTextField totalwater[], totalele[], totalsecsupply[], buildinglift[], buildinglight[];
	private JLabel uptownnamelabel[],buildingidlabel[], totalwaterlabel, totalelelabel, totalsecsupplylabel, buildingliftlabel, buildinglightlabel, uptownlabel;
	private String uptownid[], uptownname[], buildingid[], selectuptown, sqlinsert[], water,elec,secelec,lift,light;
	private JButton uptownbutton, buildingbutton, inputbutton, returnbutton;
	private Box box1, subbox[], box2, box3, buttonbox, box31;
	private int uptowncount, buildingcount;
	private JComboBox uptownselect;
	//private String uptownname[], uptownid[], buildingid[];
	
	public MonthDataInputBuilding(final JPanel panelin)
	{
		panelin.removeAll();//��������ϵ��������
		panelin.setLayout(new BoxLayout( panelin, BoxLayout.Y_AXIS));
		uptownbutton = new JButton( "�������С����ˮ�����ܵ�������ι�ˮ����������" );
		uptownbutton.addActionListener(
			new ActionListener(){
				public void actionPerformed( ActionEvent event){
					panelin.removeAll();
					box2 = Box.createVerticalBox();
					box2.add( Box.createVerticalStrut(10) );
					try
					{
						Class.forName("com.mysql.jdbc.Driver");
						String url1 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
						Connection connection1 = DriverManager.getConnection(url1,"swing_wuye","swing_wuye");
						Statement stmt1 = connection1.createStatement(); 
						String sqlUptown = "SELECT district_id,district_name FROM district_info ORDER BY district_id";
						ResultSet rs1 = stmt1.executeQuery(sqlUptown);
		
						int i= 0;
						while( rs1.next() )
						{
							uptownid[i] = rs1.getString( "district_id" );
							uptownname[i] = rs1.getString( "district_name" );
							i++;
						}
						uptowncount=i;
		
						rs1.close();
						connection1.close();
					}
		
					catch( Exception ex ) {
						System.out.println(ex);
						System.exit(0);
					}//���ȡС����Ϣ
					
					totalwaterlabel = new JLabel( "С����ˮ������" );
					totalelelabel = new JLabel( "С���ܵ������" );
					totalsecsupplylabel = new JLabel( "С�����ι�ˮ�������" );
					subbox = new Box[uptowncount];
					for( int i = 0; i<uptowncount; i++)
					{
						subbox[i] = Box.createHorizontalBox();
						uptownnamelabel[i] = new JLabel( uptownname[i] );
						totalwater[i] = new JTextField();
						totalele[i] = new JTextField();
						totalsecsupply[i] = new JTextField();
						subbox[i].add( Box.createHorizontalStrut(10) );
						subbox[i].add( uptownnamelabel[i] );
						subbox[i].add( totalwaterlabel );
						subbox[i].add( totalwater[i] );
						subbox[i].add( totalelelabel );
						subbox[i].add( totalele[i] );
						subbox[i].add( totalsecsupplylabel );
						subbox[i].add( totalsecsupply[i] ); 
						box2.add( subbox[i] );
					}
					
					buttonbox = Box.createHorizontalBox();
					buttonbox.add( Box.createVerticalStrut(20) );
					inputbutton = new JButton( "ȷ��" );
					inputbutton.addActionListener(
						new ActionListener(){
							public void actionPerformed( ActionEvent event) {
								sqlinsert = new String[uptowncount];
								Calendar cal=Calendar.getInstance();
								int y=cal.get(Calendar.YEAR);
								int m=cal.get(Calendar.MONTH)+1;
								int inputdate = y*100+m;
								try{
									Class.forName("com.mysql.jdbc.Driver");
									String url3 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
									Connection connection3 = DriverManager.getConnection(url3,"swing_wuye","swing_wuye");
									Statement stmt3 = connection3.createStatement();
									for( int i =0 ; i<uptowncount ; i++){
										water = new String( totalwater[i].getText() );
										elec = new String( totalele[i].getText() );
										secelec = new String( totalsecsupply[i].getText());
										sqlinsert[i] = "INSERT INTO district_reading (district_id,date,tot_water_reading,tot_elec_reading,sec_supply_reading) value("+uptownid[i]+","+inputdate+","+water+","+elec+","+secelec+")";
										stmt3.execute( sqlinsert[i]);
									}
									connection3.close();
								}
								catch( Exception ex ) {
									System.out.println(ex);
									System.exit(0);
								}//������ݲ���
							}
						}
						);
					
					returnbutton =new JButton( "����" );
					returnbutton.addActionListener(
						new ActionListener(){
							public void actionPerformed( ActionEvent event) {
								new MonthDataInputBuilding( panelin );
							}
						}
						);
					buttonbox.add( inputbutton );
					buttonbox.add( returnbutton);
					box2.add( buttonbox );
					panelin.add( box2 );
					panelin.setVisible( true );
				}
			}
			);
		
		
		buildingbutton = new JButton( "�������¥��������¼�����" );
		buildingbutton.addActionListener(
			new ActionListener(){
				public void actionPerformed( ActionEvent event){
					panelin.removeAll();
					box3 = Box.createVerticalBox();
					box3.add( Box.createVerticalStrut(10) );
					try
					{
						Class.forName("com.mysql.jdbc.Driver");
						String url1 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
						Connection connection1 = DriverManager.getConnection(url1,"swing_wuye","swing_wuye");
						Statement stmt1 = connection1.createStatement(); 
						String sqlUptown = "SELECT district_id,district_name FROM district_info ORDER BY district_id";
						ResultSet rs1 = stmt1.executeQuery(sqlUptown);
		
						int i= 0;
						while( rs1.next() )
						{
							uptownid[i] = rs1.getString( "district_id" );
							uptownname[i] = rs1.getString( "district_name" );
							i++;
						}
						uptowncount=i;
		
						rs1.close();
						connection1.close();
					}
		
					catch( Exception ex ) {
						System.out.println(ex);
						System.exit(0);
					}//���ȡС����Ϣ
					
					uptownlabel = new JLabel( "ѡ��С��" );
					uptownlabel.setToolTipText("���ѡ��С��" );
		
					uptownselect = new JComboBox( uptownname );
					uptownselect.setMaximumRowCount( 3 );
					uptownselect.addItemListener(
						new ItemListener() {
							public void itemStateChanged( ItemEvent event )
							{
								int i=0;
								if( event.getStateChange() == ItemEvent.SELECTED)
									i = uptownselect.getSelectedIndex();
									selectuptown = uptownid[i];
					
								try{
									Class.forName("com.mysql.jdbc.Driver");
									String url2 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
									Connection connection2 = DriverManager.getConnection(url2,"swing_wuye","swing_wuye");
									Statement stmt2 = connection2.createStatement();
									String sqlBuilding = "SELECT building_id FROM building_info WHERE district_id="+uptownid[i]+" ORDER BY building_id";
									ResultSet rs2 = stmt2.executeQuery(sqlBuilding);
						
									i = 0;
									while( rs2.next() )
									{
										buildingid[i] = rs2.getString( "building_id" );
										i++;
									}
						
									buildingcount = i;
									rs2.close();
									connection2.close();
								}
					
								catch( Exception ex )
								{
									System.out.println( ex );
									System.exit(0);
								}
					
					
								}
							}	
						) ;//������ݿ����
						
					box31 = Box.createHorizontalBox();
					box31.add( Box.createVerticalStrut(10) );
					box31.add( uptownlabel );
					box31.add( uptownselect );
					
					buildingliftlabel = new JLabel( "¥����ݵ������" );
					buildinglightlabel = new JLabel( "¥�������������" );
					subbox = new Box[buildingcount];
					for( int i = 0; i<buildingcount; i++)
					{
						subbox[i] = Box.createHorizontalBox();
						buildingidlabel[i] = new JLabel( buildingid[i] );
						buildinglift[i] = new JTextField();
						buildinglight[i] = new JTextField();
						subbox[i].add( Box.createHorizontalStrut(10) );
						subbox[i].add( buildingidlabel[i] );
						subbox[i].add( buildingliftlabel );
						subbox[i].add( buildinglift[i] );
						subbox[i].add( buildinglightlabel );
						subbox[i].add( buildinglight[i] ); 
						box3.add( subbox[i] );
					}
					buttonbox = Box.createHorizontalBox();
					buttonbox.add( Box.createVerticalStrut(20) );
					inputbutton = new JButton( "ȷ��" );
					inputbutton.addActionListener(
						new ActionListener(){
							public void actionPerformed( ActionEvent event) {
								sqlinsert = new String[uptowncount];
								Calendar cal=Calendar.getInstance();
								int y=cal.get(Calendar.YEAR);
								int m=cal.get(Calendar.MONTH)+1;
								int inputdate = y*100+m;
								try{
									Class.forName("com.mysql.jdbc.Driver");
									String url3 = "jdbc:mysql://47.101.198.61:3306/swing_wuye";
									Connection connection3 = DriverManager.getConnection(url3,"swing_wuye","swing_wuye");
									Statement stmt3 = connection3.createStatement();
									for( int i =0 ; i<uptowncount ; i++){
										lift = new String( buildinglift[i].getText() );
										light = new String( buildinglight[i].getText() );
										sqlinsert[i] = "INSERT INTO building_elec_reading (district_id,building_id,date,lift_elec_reading,light_elec_reading) value("+uptownid[i]+","+buildingid[i]+","+inputdate+","+lift+","+light+")";
										stmt3.execute( sqlinsert[i]);
									}
									JOptionPane.showMessageDialog(null,"�û������������������","����",JOptionPane.ERROR_MESSAGE);
									connection3.close();
								}
								catch( Exception ex ) {
									System.out.println(ex);
									System.exit(0);
								}//������ݲ���
							}
							
						}
						);
					
					returnbutton =new JButton( "����" );
					returnbutton.addActionListener(
						new ActionListener(){
							public void actionPerformed( ActionEvent event) {
								new MonthDataInputBuilding( panelin );
							}
						}
						);
					buttonbox.add( inputbutton );
					buttonbox.add( returnbutton);
					box3.add( buttonbox );
					panelin.add( box3 );
					panelin.setVisible( true );	
				}
			}
			);
		box1 = Box.createVerticalBox();
		box1.add( Box.createVerticalStrut( 30 ));
		box1.add( uptownbutton );
		box1.add( buildingbutton );
		panelin.add( box1 );
		panelin.setVisible( true );	
	}
}