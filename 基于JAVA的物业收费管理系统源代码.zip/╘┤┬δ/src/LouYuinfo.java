import javax.swing.table.AbstractTableModel;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.sql.*;
import java.util.*;



public class LouYuinfo extends JFrame
{
	
	
	private JPanel buttonPanel,tablePanel,fieldPanel,fieldPanel1,fieldPanel2;

	private JLabel label1 = new JLabel();
	private JTextField districtid = new JTextField(3);
	
	private JLabel label2 = new JLabel();
	private JTextField buildingid = new JTextField(3);
	
	private JLabel label3 = new JLabel();
	private JTextField storey = new JTextField(4);
	
	private JLabel label4 = new JLabel();
	private JTextField area = new JTextField(4);
	
	private JLabel label5 = new JLabel();
	private JTextField height = new JTextField(4);
	
	private JLabel label6 = new JLabel();
	private JTextField type = new JTextField(5);
	
	private JLabel label7 = new JLabel();
	private JTextField state = new JTextField(6);
	
	/*private JLabel label8 = new JLabel();
	private JTextField sex = new JTextField(4);
	
	private JLabel label9 = new JLabel();
	private JTextField idnum = new JTextField(13);
	
	private JLabel label10 = new JLabel();
	private JTextField addr = new JTextField(15);
	
	private JLabel label11 = new JLabel();
	private JTextField tetel = new JTextField(8);*/
	
	
	private JButton searchButton = new JButton("��С����ѯ");
	private JButton addButton = new JButton("����");
	private JButton changeButton = new JButton("�޸�");
	private JButton deleteButton = new JButton("ɾ��");
	private JButton renewButton = new JButton("����");
	private JButton updateButton= new JButton("����");
	
	String title[]= {"С�����","¥����","¥�����","��Ȩ���","¥��߶�","����","¥��״̬"};

	Vector vector=new Vector();
	

	Connection connection = null;
	ResultSet rSet = null;
	Statement statement = null;
	AbstractTableModel tm;
	
	public LouYuinfo()
	{
		
		
		enableEvents(AWTEvent.WINDOW_EVENT_MASK);
		try
		{
			jbInit();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	private void jbInit() throws Exception
	{
		Container con = getContentPane();
		con.setLayout(new BorderLayout());
		
		label1.setText("С�����");
		label2.setText("¥����");
		label3.setText("¥�����");
		label4.setText("��Ȩ���");
		label5.setText("¥��߶�");
		label6.setText("����");
		label7.setText("¥��״̬");
		
				
		searchButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				searchButton_actionPerformed(e);
			}
		});
		
		addButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				addButton_actionPerformed(e);
			}
		});
		
		changeButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				changeButton_actionPerformed(e);
			}
		});
		
		deleteButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				deleteButton_actionPerformed(e);
			}
		});
		
		renewButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				renewButton_actionPerformed(e);
			}
		});
		
		updateButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				updateButton_actionPerformed(e);
			}
		});
		
		fieldPanel1=new JPanel();
		fieldPanel1.setLayout(new FlowLayout());
		
		fieldPanel1.add(label1);
		fieldPanel1.add(districtid);
		fieldPanel1.add(label2);
		fieldPanel1.add(buildingid);
		fieldPanel1.add(label3);
		fieldPanel1.add(storey);
		fieldPanel1.add(label4);
		fieldPanel1.add(area);

		
		fieldPanel2=new JPanel();
		fieldPanel2.setLayout(new FlowLayout());
		
		fieldPanel2.add(label5);
		fieldPanel2.add(height);
		fieldPanel2.add(label6);
		fieldPanel2.add(type);
		fieldPanel2.add(label7);
		fieldPanel2.add(state);
		
		
		
		fieldPanel = new JPanel();
		fieldPanel.setLayout(new BorderLayout());
	
		fieldPanel.add(fieldPanel1,BorderLayout.NORTH);
		fieldPanel.add(fieldPanel2,BorderLayout.CENTER);
		//fieldPanel.add(fieldPanel3,BorderLayout.SOUTH);
		
		buttonPanel=new JPanel();
		buttonPanel.setLayout(new FlowLayout());
		
		buttonPanel.add(searchButton);
		buttonPanel.add(addButton);
		buttonPanel.add(changeButton);
		buttonPanel.add(deleteButton);
		buttonPanel.add(renewButton);
		buttonPanel.add(updateButton);
		
		tablePanel=new JPanel();
		
		createtable();
		con.add(tablePanel,BorderLayout.NORTH);
		con.add(fieldPanel,BorderLayout.CENTER);
		con.add(buttonPanel,BorderLayout.SOUTH);
		updated();
		
		setSize(600,650);
		setResizable(false);
		setVisible(true);
		
	}
	
	public static void main(String[] args) 
	{
		LouYuinfo userInformation=new LouYuinfo();
		
		userInformation.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE );
	}
	
	private void createtable()
	{
		JTable table;
		JScrollPane scroll;
	//	vector = new Vector();
		tm = new AbstractTableModel()
		{
			public int getColumnCount()
			{
				return title.length;
			}
			public int getRowCount()
			{
				return vector.size();
			}
			public String getColumnName(int col) 
			{
				return title[col];
			}
			
			public Object getValueAt(int row, int column)
			{
				if(!vector.isEmpty())
				{
					return ((Vector)vector.elementAt(row)).elementAt(column);
				}
				else
				{
					return null;
				}
	
			}
			public void setValueAt(Object value, int row, int column)
			{
				
			}
		
			public Class getColumnClass(int c)
			{
				return getValueAt(0,c).getClass();
			}
			public boolean isCellEditable(int row, int column)
			{
				return false;
			}
		};
		
		table = new JTable(tm);
		table.setToolTipText("Display Query Result");
		table.setAutoResizeMode(table.AUTO_RESIZE_OFF);
		table.setCellSelectionEnabled(false);
		table.setShowHorizontalLines(true);
		table.setShowVerticalLines(true);
		scroll = new JScrollPane(table);
		scroll.setBounds(6,20,540,250);
		tablePanel.add(scroll);
		
		
	}

	
	void addButton_actionPerformed(ActionEvent e)
	{
		try{
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://47.101.198.61:3306/swing_wuye";
			connection = DriverManager.getConnection(url,"swing_wuye","swing_wuye");
			statement = connection.createStatement();
			String sql1= "insert into building_info(district_id,building_id,total_storey,total_area,height,type,status) values("+Integer.parseInt(districtid.getText())+","+Integer.parseInt(buildingid.getText())+","+Integer.parseInt(storey.getText())+","+Integer.parseInt(area.getText())+","+Integer.parseInt(height.getText())+","+Integer.parseInt(type.getText())+",'"+state.getText()+"')";
			statement.executeUpdate(sql1);
			
		}
		catch(Exception ex){
			JOptionPane.showMessageDialog(LouYuinfo.this,"������ݳ���","����",JOptionPane.ERROR_MESSAGE);
			ex.printStackTrace();
		}
		finally{
			try{
				if(statement != null){
					statement.close();
				}
				if(connection != null){
					connection.close();
				}
			}
			catch(SQLException ex){
				System.out.println("\nERROR:---------SQLException--------\n");
				System.out.println("Message: "+ ex.getMessage());
				System.out.println("SQLState: "+ ex.getSQLState());
				System.out.println("ErrorCode: "+ ex.getErrorCode());
			}
		}
		updated();			
	}
	
	void changeButton_actionPerformed(ActionEvent e)
	{
		try{
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://47.101.198.61:3306/swing_wuye";
			connection = DriverManager.getConnection(url,"swing_wuye","swing_wuye");
			statement = connection.createStatement();
			String sql1= "update building_info set diatrict_id="+Integer.parseInt(districtid.getText())+",buildingid="+Integer.parseInt(buildingid.getText())+",total_storey='"+Integer.parseInt(storey.getText())+",total_area="+Integer.parseInt(area.getText())+",height="+Integer.parseInt(height.getText())+",type="+Integer.parseInt(type.getText())+",status='"+state.getText()+"' WHERE district_id="+Integer.parseInt(districtid.getText())+" AND building_id="+Integer.parseInt(buildingid.getText());
			statement.executeUpdate(sql1);
			
		}
		catch(Exception ex){
			JOptionPane.showMessageDialog(LouYuinfo.this,"�޸����ݳ�����ע��С���ź�¥���Ƿ���ȷ��","����",JOptionPane.ERROR_MESSAGE);
			ex.printStackTrace();
		}
		finally{
			try{
				if(statement != null){
					statement.close();
				}
				if(connection != null){
					connection.close();
				}
			}
			catch(SQLException ex){
				System.out.println("\nERROR:---------SQLException--------\n");
				System.out.println("Message: "+ ex.getMessage());
				System.out.println("SQLState: "+ ex.getSQLState());
				System.out.println("ErrorCode: "+ ex.getErrorCode());
			}
		}
		updated();			
	}
	
	void deleteButton_actionPerformed(ActionEvent e)
	{
		try{
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://47.101.198.61:3306/swing_wuye";
			connection = DriverManager.getConnection(url,"swing_wuye","swing_wuye");
			statement = connection.createStatement();
			String sql2= "delete from building_info where district_id="+Integer.parseInt(districtid.getText())+"AND building_id="+Integer.parseInt(buildingid.getText());//+"area="+Integer.parseInt(area.getText())+"||oname="+ownername.getText()+"||sex="+sex.getText()+"||id_num="+idnum.getText()+"||address="+addr.getText()+"||phone="+Integer.parseInt(tetel.getText());
			statement.executeUpdate(sql2);
			
			}
		catch(Exception ex){
			JOptionPane.showMessageDialog(LouYuinfo.this,"��������������޷�ִ��ɾ����ע��С����ź�¥�����Ƿ���ȷ��","����",JOptionPane.ERROR_MESSAGE);
//			ex.printStackTrace();
		}
		finally{
			try{
				if(statement != null){
					statement.close();
				}
				if(connection != null){
					connection.close();
				}
			}
			catch(SQLException ex){
				System.out.println("\nERROR:---------SQLException--------\n");
				System.out.println("Message: "+ ex.getMessage());
				System.out.println("SQLState: "+ ex.getSQLState());
				System.out.println("ErrorCode: "+ ex.getErrorCode());
			}
		}
		updated();
	}
	
	void updateButton_actionPerformed(ActionEvent e)
	{
			try{
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://47.101.198.61:3306/swing_wuye";
			connection = DriverManager.getConnection(url,"swing_wuye","swing_wuye");
			statement = connection.createStatement();
			String sql3= "select * from building_info";
			rSet=statement.executeQuery(sql3);
			if(rSet.next()==false)
			{
				//JOptionPane msg= new JOptionPane();
				JOptionPane.showMessageDialog(LouYuinfo.this,"���ݿ�����Ӧ����","����",JOptionPane.ERROR_MESSAGE);
			}
			else
			{
				String sql= "select * from building_info";
				ResultSet rs=statement.executeQuery(sql);
				
				districtid.setText("");
				buildingid.setText("");
				storey.setText("");
				area.setText("");
				height.setText("");
				type.setText("");
				state.setText("");
						
				vector.removeAllElements();
				tm.fireTableStructureChanged();
			
				while(rs.next())
				{
					Vector rec_vector=new Vector();
					rec_vector.addElement(String.valueOf(rs.getInt(1)));
					rec_vector.addElement(String.valueOf(rs.getInt(2)));
					rec_vector.addElement(String.valueOf(rs.getInt(3)));
					rec_vector.addElement(String.valueOf(rs.getInt(4)));
					rec_vector.addElement(rs.getString(5));
					rec_vector.addElement(rs.getString(6));
					rec_vector.addElement(rs.getString(7));
					
					vector.addElement(rec_vector);
				}
				tm.fireTableStructureChanged();
			}
			
			
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		finally{
			try{
				if(statement != null){
					statement.close();
				}
				if(connection != null){
					connection.close();
				}
			}
			catch(SQLException ex){
				System.out.println("\nERROR:---------SQLException--------\n");
				System.out.println("Message: "+ ex.getMessage());
				System.out.println("SQLState: "+ ex.getSQLState());
				System.out.println("ErrorCode: "+ ex.getErrorCode());
			}
		}
	}
	
	void searchButton_actionPerformed(ActionEvent e)
	{
		try{
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://47.101.198.61:3306/swing_wuye";
			connection = DriverManager.getConnection(url,"swing_wuye","swing_wuye");
			statement = connection.createStatement();
		//	String sql4= "select * from room_info where district_id="+Integer.parseInt(districtid.getText())+"||building_id="+Integer.parseInt(buildingid.getText())+"||room_id="+Integer.parseInt(roomid.getText())+"area="+Integer.parseInt(area.getText())+"||oname='"+ownername.getText()+"'||sex='"+sex.getText()+"'||id_num="+idnum.getText()+"||address="+addr.getText()+"||phone="+Integer.parseInt(tetel.getText());
			String sql4= "select * from building_info where district_id="+Integer.parseInt(districtid.getText());
			rSet=statement.executeQuery(sql4);
			if(rSet.next()==false)
			{
				JOptionPane msg= new JOptionPane();
				JOptionPane.showMessageDialog(LouYuinfo.this,"���ݿ�����Ӧ����","����",JOptionPane.ERROR_MESSAGE);
				vector.removeAllElements();
				tm.fireTableStructureChanged();
			}
			else
			{
		//		String sqll= "select * from room_info where district_id="+Integer.parseInt(districtid.getText())+"||building_id="+Integer.parseInt(buildingid.getText())+"||room_id="+Integer.parseInt(roomid.getText())+"area="+Integer.parseInt(area.getText())+"||oname='"+ownername.getText()+"'||sex='"+sex.getText()+"'||id_num="+idnum.getText()+"||address="+addr.getText()+"||phone="+Integer.parseInt(tetel.getText());
				String sqll="select * from building_info where district_id="+Integer.parseInt(districtid.getText());
				ResultSet rs=statement.executeQuery(sqll);
					
					
				vector.removeAllElements();
				tm.fireTableStructureChanged();
			
				while(rs.next())
				{
					Vector rec_vector=new Vector();
					rec_vector.addElement(String.valueOf(rs.getInt(1)));
					rec_vector.addElement(String.valueOf(rs.getInt(2)));
					rec_vector.addElement(String.valueOf(rs.getInt(3)));
					rec_vector.addElement(String.valueOf(rs.getInt(4)));
					rec_vector.addElement(rs.getString(5));
					rec_vector.addElement(rs.getString(6));
					rec_vector.addElement(rs.getString(7));
					
					vector.addElement(rec_vector);
				}
				tm.fireTableStructureChanged();
			}	
		}	
		
		catch(Exception ex){
			ex.printStackTrace();
		}
		finally{
			try{
				if(statement != null){
					statement.close();
				}
				if(connection != null){
					connection.close();
				}
			}
			catch(SQLException ex){
				System.out.println("\nERROR:---------SQLException--------\n");
				System.out.println("Message: "+ ex.getMessage());
				System.out.println("SQLState: "+ ex.getSQLState());
				System.out.println("ErrorCode: "+ ex.getErrorCode());
			}
		}
	
		
	
	}
	
	void updated()
	{
			try{
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://47.101.198.61:3306/swing_wuye";
			connection = DriverManager.getConnection(url,"swing_wuye","swing_wuye");
			statement = connection.createStatement();
			String sql3= "select * from building_info";
			rSet=statement.executeQuery(sql3);
			if(rSet.next()== true)
			{
				String sql= "select * from building_info";
				ResultSet rs=statement.executeQuery(sql);
								
				
				vector.removeAllElements();
				tm.fireTableStructureChanged();
			
				while(rs.next())
				{
					Vector rec_vector=new Vector();
					rec_vector.addElement(String.valueOf(rs.getInt(1)));
					rec_vector.addElement(String.valueOf(rs.getInt(2)));
					rec_vector.addElement(String.valueOf(rs.getInt(3)));
					rec_vector.addElement(String.valueOf(rs.getInt(4)));
					rec_vector.addElement(rs.getString(5));
					rec_vector.addElement(rs.getString(6));
					rec_vector.addElement(rs.getString(7));
					
					vector.addElement(rec_vector);
				}
				tm.fireTableStructureChanged();
			}
			
			
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		finally{
			try{
				if(statement != null){
					statement.close();
				}
				if(connection != null){
					connection.close();
				}
			}
			catch(SQLException ex){
				System.out.println("\nERROR:---------SQLException--------\n");
				System.out.println("Message: "+ ex.getMessage());
				System.out.println("SQLState: "+ ex.getSQLState());
				System.out.println("ErrorCode: "+ ex.getErrorCode());
			}
		}
	}
	
	
	void renewButton_actionPerformed(ActionEvent e)
	{		
				districtid.setText("");
				buildingid.setText("");
				storey.setText("");
				area.setText("");
				height.setText("");
				type.setText("");
				state.setText("");
	}
}





