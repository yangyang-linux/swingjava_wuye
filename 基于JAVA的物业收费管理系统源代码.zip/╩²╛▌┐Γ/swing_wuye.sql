-- --------------------------------------------------------
-- 主机:                           47.101.198.61
-- Server version:               10.3.14-MariaDB - MariaDB Server
-- Server OS:                    Linux
-- HeidiSQL 版本:                  10.1.0.5464
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for swing_wuye
CREATE DATABASE IF NOT EXISTS `swing_wuye` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;
USE `swing_wuye`;

-- Dumping structure for table swing_wuye.building_elec_reading
DROP TABLE IF EXISTS `building_elec_reading`;
CREATE TABLE IF NOT EXISTS `building_elec_reading` (
  `district_id` double DEFAULT NULL,
  `building_id` double DEFAULT NULL,
  `date` double DEFAULT 0,
  `lift_ele_reading` double DEFAULT NULL,
  `lighting_reading` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table swing_wuye.building_elec_reading: ~15 rows (approximately)
/*!40000 ALTER TABLE `building_elec_reading` DISABLE KEYS */;
INSERT INTO `building_elec_reading` (`district_id`, `building_id`, `date`, `lift_ele_reading`, `lighting_reading`) VALUES
	(1, 1, 200505, 200504, 200504),
	(1, 2, 200505, 200504, 200504),
	(1, 3, 200505, 200504, 200504),
	(1, 4, 200505, 200504, 200504),
	(1, 5, 200505, 200504, 200504),
	(1, 1, 200506, 200505, 200505),
	(1, 2, 200506, 200505, 200505),
	(1, 3, 200506, 200505, 200505),
	(1, 4, 200506, 200505, 200505),
	(1, 5, 200506, 200505, 200505),
	(1, 1, 200507, 999999, 999999),
	(1, 2, 200507, 999999, 999999),
	(1, 3, 200507, 999999, 999999),
	(1, 4, 200507, 999999, 999999),
	(1, 5, 200507, 999999, 999999),
	(1, 1, 201901212, 354, 345),
	(1, 1, 201901212, 345, 345),
	(1, 2, 201901212, 345, 345),
	(1, 3, 201901212, 465, 345),
	(1, 4, 201901212, 465, 345),
	(1, 5, 201901212, 3645, 3456);
/*!40000 ALTER TABLE `building_elec_reading` ENABLE KEYS */;

-- Dumping structure for table swing_wuye.building_info
DROP TABLE IF EXISTS `building_info`;
CREATE TABLE IF NOT EXISTS `building_info` (
  `district_id` double DEFAULT NULL,
  `building_id` double DEFAULT NULL,
  `total_storey` double DEFAULT NULL,
  `total_area` double DEFAULT NULL,
  `height` double DEFAULT NULL,
  `type` double DEFAULT 1,
  `status` varchar(9) DEFAULT '"use"'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table swing_wuye.building_info: ~8 rows (approximately)
/*!40000 ALTER TABLE `building_info` DISABLE KEYS */;
INSERT INTO `building_info` (`district_id`, `building_id`, `total_storey`, `total_area`, `height`, `type`, `status`) VALUES
	(1, 1, 5, 20.3, 60, 1, 'use'),
	(1, 2, 5, 20.3, 60, 1, 'use'),
	(1, 3, 23, 40.3, 120, 1, 'use'),
	(1, 4, 5, 20.3, 60, 1, 'use'),
	(1, 5, 5, 20.3, 60, 1, 'use'),
	(2, 1, 5, 50, 60, 1, 'use'),
	(2, 2, 5, 50, 60, 1, 'use'),
	(2, 3, 5, 50, 60, 1, 'use');
/*!40000 ALTER TABLE `building_info` ENABLE KEYS */;

-- Dumping structure for table swing_wuye.district_info
DROP TABLE IF EXISTS `district_info`;
CREATE TABLE IF NOT EXISTS `district_info` (
  `district_id` double DEFAULT NULL,
  `district_name` varchar(12) DEFAULT NULL,
  `address` varchar(60) DEFAULT NULL,
  `floor_space` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table swing_wuye.district_info: ~2 rows (approximately)
/*!40000 ALTER TABLE `district_info` DISABLE KEYS */;
INSERT INTO `district_info` (`district_id`, `district_name`, `address`, `floor_space`) VALUES
	(1, '源码码头', '北京南路253号', 25369.5),
	(2, '江南小区', '北京市', 1299),
	(1234, '江南小区', '北京市', 1299);
/*!40000 ALTER TABLE `district_info` ENABLE KEYS */;

-- Dumping structure for table swing_wuye.district_reading
DROP TABLE IF EXISTS `district_reading`;
CREATE TABLE IF NOT EXISTS `district_reading` (
  `district_id` double DEFAULT NULL,
  `date` double DEFAULT 0,
  `tot_water_reading` double DEFAULT NULL,
  `tot_elec_reading` double DEFAULT NULL,
  `sec_supply_reading` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table swing_wuye.district_reading: ~3 rows (approximately)
/*!40000 ALTER TABLE `district_reading` DISABLE KEYS */;
INSERT INTO `district_reading` (`district_id`, `date`, `tot_water_reading`, `tot_elec_reading`, `sec_supply_reading`) VALUES
	(1, 200505, 200504, 200504, 200504),
	(1, 200506, 200505, 200505, 200505),
	(1, 200507, 999999, 999999, 999999),
	(1, 201901212, 354, 345, 4567);
/*!40000 ALTER TABLE `district_reading` ENABLE KEYS */;

-- Dumping structure for table swing_wuye.emp_info
DROP TABLE IF EXISTS `emp_info`;
CREATE TABLE IF NOT EXISTS `emp_info` (
  `uname` varchar(12) DEFAULT NULL,
  `ename` varchar(9) DEFAULT NULL,
  `dept` varchar(9) DEFAULT NULL,
  `duty` varchar(9) DEFAULT NULL,
  `office_phone` double DEFAULT NULL,
  `emp_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table swing_wuye.emp_info: ~2 rows (approximately)
/*!40000 ALTER TABLE `emp_info` DISABLE KEYS */;
INSERT INTO `emp_info` (`uname`, `ename`, `dept`, `duty`, `office_phone`, `emp_date`) VALUES
	('admin', '吴俊杰', '系统管理', '经理', 13959264312, '2019-09-01 00:00:00'),
	('pahran', '吴俊杰', '软件学院', '学生', 5922101227, '2019-09-02 00:00:00');
/*!40000 ALTER TABLE `emp_info` ENABLE KEYS */;

-- Dumping structure for table swing_wuye.login_info
DROP TABLE IF EXISTS `login_info`;
CREATE TABLE IF NOT EXISTS `login_info` (
  `uname` varchar(12) DEFAULT NULL,
  `paswrd` varchar(20) DEFAULT NULL,
  `purview` double DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table swing_wuye.login_info: ~2 rows (approximately)
/*!40000 ALTER TABLE `login_info` DISABLE KEYS */;
INSERT INTO `login_info` (`uname`, `paswrd`, `purview`) VALUES
	('admin', 'admin', 2),
	('yuanmamatou', '123456', 0);
/*!40000 ALTER TABLE `login_info` ENABLE KEYS */;

-- Dumping structure for table swing_wuye.paying_charge
DROP TABLE IF EXISTS `paying_charge`;
CREATE TABLE IF NOT EXISTS `paying_charge` (
  `district_id` double DEFAULT NULL,
  `building_id` double DEFAULT NULL,
  `room_id` double DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `deadline` datetime DEFAULT NULL,
  `totoal_fee` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table swing_wuye.paying_charge: ~0 rows (approximately)
/*!40000 ALTER TABLE `paying_charge` DISABLE KEYS */;
/*!40000 ALTER TABLE `paying_charge` ENABLE KEYS */;

-- Dumping structure for table swing_wuye.room_info
DROP TABLE IF EXISTS `room_info`;
CREATE TABLE IF NOT EXISTS `room_info` (
  `district_id` double DEFAULT NULL,
  `building_id` double DEFAULT NULL,
  `room_id` double DEFAULT NULL,
  `area` double DEFAULT NULL,
  `status` varchar(9) DEFAULT '"use"',
  `purpose` varchar(10) DEFAULT '"resident"',
  `oname` varchar(20) DEFAULT NULL,
  `sex` varchar(7) DEFAULT NULL,
  `id_num` varchar(18) DEFAULT NULL,
  `address` varchar(60) DEFAULT NULL,
  `phone` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table swing_wuye.room_info: ~6 rows (approximately)
/*!40000 ALTER TABLE `room_info` DISABLE KEYS */;
INSERT INTO `room_info` (`district_id`, `building_id`, `room_id`, `area`, `status`, `purpose`, `oname`, `sex`, `id_num`, `address`, `phone`) VALUES
	(1, 1, 101, 12, 'use', 'resident', 'qw', 'male', '12', 'qw', 123),
	(1, 1, 102, 12, 'use', 'resident', 'asd', 'male', '46', 'as', 456),
	(1, 1, 103, 12, 'use', 'resident', 'asa', 'male', '45', 'as', 123),
	(1, 1, 201, 25, 'use', 'resident', 'pahran', 'male', '12', 'dd', 21),
	(1, 1, 202, 55, 'use', 'resident', 'bery', 'female', '350204198401020195', '源码码头', 2180001),
	(1, 1, 203, 55, 'use', 'resident', 'pahran', 'male', '350204198401020195', '源码码头', 2180001);
/*!40000 ALTER TABLE `room_info` ENABLE KEYS */;

-- Dumping structure for table swing_wuye.unit_price_info
DROP TABLE IF EXISTS `unit_price_info`;
CREATE TABLE IF NOT EXISTS `unit_price_info` (
  `charge_id` double DEFAULT NULL,
  `charge_name` varchar(20) DEFAULT NULL,
  `unit_price` double DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table swing_wuye.unit_price_info: ~6 rows (approximately)
/*!40000 ALTER TABLE `unit_price_info` DISABLE KEYS */;
INSERT INTO `unit_price_info` (`charge_id`, `charge_name`, `unit_price`) VALUES
	(1, 'res_elec', 0.42),
	(2, 'res_water', 2.3),
	(3, 'res_gas', 3.2),
	(4, 'com_elec', 0.65),
	(5, 'com_water', 3.5),
	(6, 'com_gas', 4.5),
	(23, '23', 23);
/*!40000 ALTER TABLE `unit_price_info` ENABLE KEYS */;

-- Dumping structure for table swing_wuye.user_reading
DROP TABLE IF EXISTS `user_reading`;
CREATE TABLE IF NOT EXISTS `user_reading` (
  `district_id` double DEFAULT NULL,
  `building_id` double DEFAULT NULL,
  `room_id` double DEFAULT NULL,
  `date` double DEFAULT 0,
  `water_reading` double DEFAULT NULL,
  `elec_reading` double DEFAULT NULL,
  `gas_reading` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table swing_wuye.user_reading: ~15 rows (approximately)
/*!40000 ALTER TABLE `user_reading` DISABLE KEYS */;
INSERT INTO `user_reading` (`district_id`, `building_id`, `room_id`, `date`, `water_reading`, `elec_reading`, `gas_reading`) VALUES
	(1, 1, 101, date_format(NOW(), '%Y%m'), 12, 234, 132),
	(1, 1, 102, date_format(NOW(), '%Y%m'), 234, 234, 234),
	(1, 1, 103, date_format(NOW(), '%Y%m'), 5364, 234, 234),
	(1, 1, 201, date_format(NOW(), '%Y%m'), 234, 234, 243),
	(1, 1, 202, date_format(NOW(), '%Y%m'), 456, 4235, 345),
	(1, 1, 203, date_format(NOW(), '%Y%m'), 4567, 534, 345),
	(1, 1, 101, date_format(date_sub(NOW(), INTERVAL 1 MONTH), '%Y%m'), 234, 3245, 3465),
	(1, 1, 102, date_format(date_sub(NOW(), INTERVAL 1 MONTH), '%Y%m'), 435, 235, 2345),
	(1, 1, 103, date_format(date_sub(NOW(), INTERVAL 1 MONTH), '%Y%m'), 342, 6435, 2354),
	(1, 1, 201, date_format(date_sub(NOW(), INTERVAL 1 MONTH), '%Y%m'), 2345, 234, 2345),
	(1, 1, 202, date_format(date_sub(NOW(), INTERVAL 1 MONTH), '%Y%m'), 2345, 3645, 4365),
	(1, 1, 203, date_format(date_sub(NOW(), INTERVAL 1 MONTH), '%Y%m'), 7654, 234, 12435);
/*!40000 ALTER TABLE `user_reading` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
